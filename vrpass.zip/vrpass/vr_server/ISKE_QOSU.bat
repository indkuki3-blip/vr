@echo off
chcp 65001 >nul
cd /d "%~dp0"
title VR Hand Server
set PYTHONIOENCODING=utf-8

if exist "venv\Scripts\python.exe" goto run

echo.
echo  First run: installing libraries (needs internet, 3-5 min)...
echo  Birinshi ret: kitaphanalar ornatyluda (internet kerek, 3-5 min)...
echo.

rem MediaPipe eng zhana Python-da jumys istemeui mumkin: aldymen 3.12 / 3.11 / 3.10 izdeimiz
where py >nul 2>nul
if %errorlevel%==0 (
    py -3.12 -m venv venv 2>nul
    if not exist "venv\Scripts\python.exe" py -3.11 -m venv venv 2>nul
    if not exist "venv\Scripts\python.exe" py -3.10 -m venv venv 2>nul
    if not exist "venv\Scripts\python.exe" py -3 -m venv venv
) else (
    python -m venv venv
)
if not exist "venv\Scripts\python.exe" goto nopython

"venv\Scripts\python.exe" -m pip install --upgrade pip
"venv\Scripts\python.exe" -m pip install mediapipe opencv-python numpy
if errorlevel 1 goto pipfail

if not exist "vr_server.py" goto noscript

:run
if not exist "vr_server.py" goto noscript
"venv\Scripts\python.exe" vr_server.py
echo.
pause
exit /b

:nopython
echo.
echo  Python not found. Install it from python.org/downloads
echo  and tick "Add python.exe to PATH" during install.
echo  Python tabylmady: python.org saytynan ornat, "Add python.exe to PATH" belgisin qoi.
echo.
pause
exit /b

:pipfail
echo.
echo  Library install failed. Check internet and run this file again.
echo  Kitaphana ornatylmady: internetti tekserip, qaita ash.
rmdir /s /q venv
echo.
pause
exit /b

:noscript
echo.
echo  vr_server.py not found next to this file.
echo  vr_server.py tabylmady: ony osy .bat fayly turgan papkaga sal.
echo.
pause
exit /b
