# -*- coding: utf-8 -*-
"""
VR Көзілдірік — ноуттағы қол трекингі сервері.

Телефон камерадан кішкентай JPEG кадрды Wi-Fi (UDP) арқылы жібереді,
мұнда MediaPipe қолдарды табады да, 21 нүктенің координатасын қайтарады.
Видео мен рендер телефонда қалады — тек ең ауыр есептеу ноутқа келеді.

Хаттама (UDP, порт 47800):
  телефон → "VRD?"                      — серверді іздеу (broadcast)
  сервер  → "VRD!" + атауы              — жауап
  телефон → "VRF1" + seq(uint32) + JPEG — кадр
  сервер  → "VRL1" + seq(uint32) + n(uint8) + n × [белгі(uint8) + 63 × float32]
            белгі: 0 = Left, 1 = Right, 2 = белгісіз; нүктелер: x, y, z (21 рет)
"""
import os
import socket
import struct
import sys
import time
import urllib.request

PORT = 47800
HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "hand_landmarker.task")
MODEL_URL = ("https://storage.googleapis.com/mediapipe-models/hand_landmarker/"
             "hand_landmarker/float16/latest/hand_landmarker.task")


def say(msg):
    print(msg, flush=True)


def local_ips():
    """Ноуттың жергілікті желідегі IP адрестері (телефонға енгізу үшін)."""
    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))  # пакет жіберілмейді, тек маршрут таңдалады
        ips.append(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if ip not in ips and not ip.startswith("127."):
                ips.append(ip)
    except OSError:
        pass
    return ips or ["(табылмады)"]


class Detector:
    """MediaPipe Hand Landmarker (бейне режимі, 2 қол)."""

    def __init__(self):
        import mediapipe as mp
        from mediapipe.tasks.python import BaseOptions
        from mediapipe.tasks.python import vision

        if not os.path.exists(MODEL) or os.path.getsize(MODEL) < 100_000:
            say("Қол моделі жүктелуде (бір рет қана, ~8 МБ)...")
            urllib.request.urlretrieve(MODEL_URL, MODEL)
        options = vision.HandLandmarkerOptions(
            base_options=BaseOptions(model_asset_path=MODEL),
            running_mode=vision.RunningMode.VIDEO,
            num_hands=2,
            min_hand_detection_confidence=0.5,
            min_hand_presence_confidence=0.5,
            min_tracking_confidence=0.5,
        )
        self.mp = mp
        self.landmarker = vision.HandLandmarker.create_from_options(options)
        self.last_ts = 0

    def detect(self, rgb):
        ts = int(time.monotonic() * 1000)
        if ts <= self.last_ts:
            ts = self.last_ts + 1
        self.last_ts = ts
        image = self.mp.Image(image_format=self.mp.ImageFormat.SRGB, data=rgb)
        res = self.landmarker.detect_for_video(image, ts)
        hands = []
        for i, pts in enumerate(res.hand_landmarks or []):
            label = 2
            try:
                name = res.handedness[i][0].category_name
                label = 0 if name == "Left" else 1 if name == "Right" else 2
            except (IndexError, AttributeError, TypeError):
                pass
            coords = []
            for p in pts[:21]:
                coords += [float(p.x), float(p.y), float(p.z or 0.0)]
            if len(coords) == 63:
                hands.append((label, coords))
        return hands


class MockDetector:
    """Тексеру үшін: бір «қол» әрқашан кадр ортасында (VR_MOCK=1)."""

    def detect(self, rgb):
        coords = []
        for i in range(21):
            coords += [0.5 + (i % 5) * 0.02, 0.4 + (i // 5) * 0.05, -0.01 * i]
        return [(1, coords)]


def decode_jpeg(data):
    import cv2
    import numpy as np
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        return None
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)


def main():
    say("=" * 56)
    say("   VR Көзілдірік — қол трекингі сервері")
    say("=" * 56)
    mock = os.environ.get("VR_MOCK") == "1"
    try:
        detector = MockDetector() if mock else Detector()
    except Exception as e:  # noqa: BLE001
        say("ҚАТЕ: MediaPipe іске қосылмады: %r" % (e,))
        say("ISKE_QOSU.bat файлын қайта ашып көріңіз (кітапханалар қайта орнатылады).")
        return 1

    # OpenCV-ді алдын ала жүктеу (бірінші кадр кешікпесін)
    try:
        import numpy as np
        decode_jpeg(bytes(np.zeros(4, np.uint8)))
    except Exception:  # noqa: BLE001
        pass

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1 << 20)
    except OSError:
        pass
    sock.bind(("0.0.0.0", PORT))
    sock.settimeout(1.0)

    name = socket.gethostname().encode("utf-8")[:60]
    say("")
    say("Дайын! Телефон мен ноут бір Wi-Fi-да болсын.")
    say("Ноуттың IP адресі (қажет болса телефонға енгіз):")
    for ip in local_ips():
        say("      " + ip)
    say("")
    say("Windows «рұқсат беру» терезесін шығарса — «Разрешить / Allow» бас")
    say("(жеке де, қоғамдық та желілерге белгі қой).")
    say("Тоқтату: осы терезені жап.")
    say("")

    frames = 0
    busy = 0.0
    last_print = time.time()
    clients = set()

    while True:
        try:
            data, addr = sock.recvfrom(65535)
        except socket.timeout:
            data = None
        except OSError:
            # Windows: телефон кетіп қалса, UDP «connection reset» береді — елемейміз
            continue

        if data is not None:
            # Кезекте жиналып қалған ескі кадрларды тастап, ең соңғысын ғана өңдейміз
            sock.setblocking(False)
            try:
                while True:
                    d2, a2 = sock.recvfrom(65535)
                    if d2[:4] == b"VRD?":
                        sock.sendto(b"VRD!" + name, a2)
                    else:
                        data, addr = d2, a2
            except (BlockingIOError, OSError):
                pass
            sock.settimeout(1.0)

            head = data[:4]
            if head == b"VRD?":
                sock.sendto(b"VRD!" + name, addr)
            elif head == b"VRF1" and len(data) > 8:
                seq = struct.unpack(">I", data[4:8])[0]
                t0 = time.perf_counter()
                rgb = decode_jpeg(data[8:])
                try:
                    hands = detector.detect(rgb) if rgb is not None else []
                except Exception as e:  # noqa: BLE001
                    say("Кадр өңделмеді: %r" % (e,))
                    hands = []
                out = bytearray(b"VRL1")
                out += struct.pack(">IB", seq, len(hands))
                for label, coords in hands:
                    out += struct.pack(">B", label)
                    out += struct.pack(">63f", *coords)
                try:
                    sock.sendto(bytes(out), addr)
                except OSError:
                    pass
                busy += time.perf_counter() - t0
                frames += 1
                if addr[0] not in clients:
                    clients.add(addr[0])
                    say("Телефон қосылды: %s" % addr[0])

        now = time.time()
        if now - last_print >= 3.0:
            if frames:
                say("  %5.1f кадр/с · бір кадрға %4.1f мс"
                    % (frames / (now - last_print), busy * 1000.0 / frames))
            frames = 0
            busy = 0.0
            last_print = now


if __name__ == "__main__":
    try:
        sys.exit(main() or 0)
    except KeyboardInterrupt:
        pass
