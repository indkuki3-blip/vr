VR Kozildirik - noutpen esepteu (vr_server)

1. Python ornat: python.org/downloads (3.12 jaqsy), "Add python.exe to PATH" belgisin qoi.
2. Osy papkanyn ishinde ISKE_QOSU.bat pen vr_server.py qatar turuy kerek.
3. ISKE_QOSU.bat-ty ash. Birinshi ret kitaphanalar ornatylady (internet kerek, 3-5 min).
4. Windows ruqsat surasa - Allow (jeke jane qogamdyq jeliler).
5. Telefon men nout bir Wi-Fi-da. VR: Maziir -> Baptau -> Jyldamdyq -> "Noutpen esepteu: QOSULY".

Tekseru (telefonsyz): cmd-da  set VR_MOCK=1  sosyn  venv\Scripts\python.exe vr_server.py
