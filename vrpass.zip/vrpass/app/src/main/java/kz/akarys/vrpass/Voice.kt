package kz.akarys.vrpass

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log

/**
 * Дауыспен жазу (Android сөз тану қызметі). Нәтиже state.voiceFinal арқылы интерфейске барады.
 * Қазақ тілі үшін интернет керек; орыс/ағылшын — офлайн пакет жүктелсе, интернетсіз де.
 */
class Voice(private val activity: Activity, private val state: VrState) {

    private var recognizer: SpeechRecognizer? = null

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            state.voiceListening = true
        }

        override fun onBeginningOfSpeech() {}

        override fun onRmsChanged(rmsdB: Float) {
            state.voiceLevel = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            state.voiceListening = false
            state.voiceLevel = 0f
            state.voiceError = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Түсінбедім, қайта айт"
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Интернет жоқ (қазақ тіліне интернет керек)"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Микрофонға рұқсат жоқ"
                else -> "Дауыс тану қатесі ($error)"
            }
        }

        override fun onResults(results: Bundle?) {
            state.voiceListening = false
            state.voiceLevel = 0f
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!text.isNullOrBlank()) state.voiceFinal = text
            state.voicePartial = ""
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text != null) state.voicePartial = text
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    /** Негізгі ағында шақыру керек. */
    fun start() {
        try {
            if (!SpeechRecognizer.isRecognitionAvailable(activity)) {
                state.voiceError = "Бұл телефонда дауыс тану қызметі жоқ"
                return
            }
            if (activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                activity.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
                state.voiceError = "Микрофонға рұқсат беріп, 🎤 қайта бас"
                return
            }
            val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(activity).also {
                it.setRecognitionListener(listener)
                recognizer = it
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, state.voiceLang)
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            state.voicePartial = ""
            state.voiceListening = true
            r.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "start", e)
            state.voiceListening = false
            state.voiceError = "Дауыс тану ашылмады"
        }
    }

    fun stop() {
        try {
            recognizer?.stopListening()
        } catch (e: Exception) {
            Log.w(TAG, "stop", e)
        }
    }

    fun destroy() {
        recognizer?.destroy()
        recognizer = null
    }

    companion object {
        private const val TAG = "Voice"
        const val REQ_MIC = 3
    }
}
