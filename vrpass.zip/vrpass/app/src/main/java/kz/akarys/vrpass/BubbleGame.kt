package kz.akarys.vrpass

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Барлық мини-ойындардың ортақ интерфейсі. Координаталар 0..1 (HUD, сол-жоғарыдан). */
interface MiniGame {
    val id: String
    val title: String
    val finished: Boolean
    val score: Int
    fun start(now: Long)
    /** aspect = ен / биіктік (қашықтықты дұрыс есептеу үшін). */
    fun update(now: Long, hands: List<EyeHand>, aspect: Float)
    fun draw(c: Canvas, w: Int, h: Int, now: Long)
}

/** Ойындарға ортақ мәтін салу көмекшісі. */
object GameText {
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    fun draw(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int) {
        paint.textSize = size
        paint.color = color
        c.drawText(s, x, y, paint)
    }
}

/**
 * «Көпіршік жару»: көпіршіктер төменнен ұшады, екі қолдың кез келген сұқ саусағымен жарасың.
 * Көк +1, алтын +5, қызыл бомба −3. 45 секунд.
 */
class BubbleGame(private val sfx: Sfx) : MiniGame {

    private class Bubble(var x: Float, var y: Float, val r: Float, val vy: Float, val kind: Int, val phase: Float)
    private class Pop(val x: Float, val y: Float, val r: Float, val color: Int, val t0: Long, val label: String)

    override val id = "bubble"
    override val title = "Көпіршік"
    override var score = 0
        private set
    override var finished = false
        private set

    private val bubbles = ArrayList<Bubble>()
    private val pops = ArrayList<Pop>()
    private var running = false
    private var startT = 0L
    private var lastT = 0L
    private var nextSpawn = 0L

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    override fun start(now: Long) {
        bubbles.clear()
        pops.clear()
        score = 0
        running = true
        finished = false
        startT = now
        lastT = now
        nextSpawn = now
    }

    private fun timeLeftSec(now: Long): Int = max(0L, (DURATION_MS - (now - startT) + 999L) / 1000L).toInt()

    override fun update(now: Long, hands: List<EyeHand>, aspect: Float) {
        if (!running) return
        val dt = min(0.05f, (now - lastT) / 1000f)
        lastT = now
        val elapsed = (now - startT) / 1000f
        if (now - startT >= DURATION_MS) {
            running = false
            finished = true
            bubbles.clear()
            sfx.play("ding")
            return
        }

        if (now >= nextSpawn) {
            val roll = Random.nextFloat()
            val kind = when {
                roll < 0.10f -> GOLD
                roll < 0.24f -> BOMB
                else -> NORMAL
            }
            val r = 0.045f + Random.nextFloat() * 0.035f
            val speed = (0.12f + Random.nextFloat() * 0.10f) * (1f + elapsed / 45f)
            bubbles.add(Bubble(0.15f + Random.nextFloat() * 0.70f, 1.1f, r, speed, kind, Random.nextFloat() * 6.28f))
            nextSpawn = now + max(280L, 650L - (elapsed * 8f).toLong())
        }

        val it = bubbles.iterator()
        while (it.hasNext()) {
            val b = it.next()
            b.y -= b.vy * dt
            b.x += sin(elapsed * 2f + b.phase) * 0.02f * dt
            if (b.y < -0.12f) {
                it.remove()
                continue
            }
            var hit = false
            for (hd in hands) {
                if (hypot((b.x - hd.cx) * aspect, b.y - hd.cy) < b.r * 1.2f) {
                    hit = true
                    break
                }
            }
            if (hit) {
                val pts = when (b.kind) {
                    GOLD -> 5
                    BOMB -> -3
                    else -> 1
                }
                score = max(0, score + pts)
                pops.add(Pop(b.x, b.y, b.r, colorOf(b.kind), now, if (pts > 0) "+$pts" else "$pts"))
                if (b.kind == BOMB) {
                    sfx.play("boom", 0.7f)
                    sfx.vibrate(120)
                } else {
                    sfx.play("pop", 0.9f, if (b.kind == GOLD) 1.5f else 1f)
                }
                it.remove()
            }
        }
        pops.removeAll { now - it.t0 > POP_MS }
    }

    override fun draw(c: Canvas, w: Int, h: Int, now: Long) {
        val fw = w.toFloat()
        val fh = h.toFloat()
        for (b in bubbles) {
            val px = b.x * fw
            val py = b.y * fh
            val pr = b.r * fh
            fill.color = colorOf(b.kind)
            fill.alpha = 120
            c.drawCircle(px, py, pr, fill)
            stroke.color = Color.WHITE
            stroke.alpha = 220
            stroke.strokeWidth = fh * 0.006f
            c.drawCircle(px, py, pr, stroke)
            fill.color = Color.WHITE
            fill.alpha = 170
            c.drawCircle(px - pr * 0.35f, py - pr * 0.35f, pr * 0.18f, fill)
            if (b.kind == BOMB) GameText.draw(c, "!", px, py + pr * 0.38f, pr * 1.1f, Color.WHITE)
            if (b.kind == GOLD) GameText.draw(c, "★", px, py + pr * 0.32f, pr * 0.9f, Color.WHITE)
        }
        for (p in pops) {
            val t = ((now - p.t0) / POP_MS.toFloat()).coerceIn(0f, 1f)
            val a = ((1f - t) * 255f).toInt().coerceIn(0, 255)
            stroke.color = p.color
            stroke.alpha = a
            stroke.strokeWidth = fh * 0.008f
            c.drawCircle(p.x * fw, p.y * fh, p.r * fh * (1f + t * 1.2f), stroke)
            GameText.draw(c, p.label, p.x * fw, p.y * fh - t * fh * 0.06f, fh * 0.05f, p.color)
        }
        GameText.draw(c, "Ұпай: $score     ⏱ ${timeLeftSec(now)}", fw * 0.5f, fh * 0.17f, fh * 0.045f, Color.WHITE)
    }

    private fun colorOf(kind: Int): Int = when (kind) {
        GOLD -> Color.rgb(255, 200, 40)
        BOMB -> Color.rgb(235, 50, 50)
        else -> Color.rgb(60, 190, 255)
    }

    companion object {
        private const val DURATION_MS = 45_000L
        private const val POP_MS = 450L
        private const val NORMAL = 0
        private const val GOLD = 1
        private const val BOMB = 2
    }
}
