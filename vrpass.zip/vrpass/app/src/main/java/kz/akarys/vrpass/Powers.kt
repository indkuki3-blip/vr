package kz.akarys.vrpass

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Суперқабілеттер (AR): Расенган, Чидори, Расенсюрикен, От шары.
 * Эффект алақанға жабысады және қолға бейімделеді:
 *  - қолды жақындатсаң — үлкейеді, алыстатсаң — кішірейеді;
 *  - алақан қараған жаққа ығысады (алақан төмен — шар астына, жоғары — үстіне);
 *  - қолды бұрсаң — эффект те бұрылады (диск перспективамен қисаяды);
 *  - жұдырық — сөнеді, алақанды ашсаң — қайта жанады;
 *  - От шары мен Расенсюрикен: қолды тез сілтесең — ұшып кетеді.
 * Координаталар: x — ен үлесі, y — биіктік үлесі (0..1). Радиустар биіктік үлесімен.
 */
class Powers(private val sfx: Sfx) {

    enum class Kind(val title: String, val sound: String, val rate: Float) {
        RASENGAN("Расенган", "hum", 1f),
        CHIDORI("Чидори", "zap", 1f),
        SHURIKEN("Расенсюрикен", "whir", 1.3f),
        FIREBALL("От шары", "flame", 1f)
    }

    var kind = Kind.RASENGAN
        private set

    private class HandFx {
        var init = false
        var x = 0f
        var y = 0f
        var size = 0.12f
        var angle = 0f
        var nx = 0f
        var ny = 0f
        var nz = 1f
        var power = 0f
        var want = false
        var lastSeen = 0L
        var vx = 0f
        var vy = 0f
        var stream = 0
        var cooldownUntil = 0L
        val bolts = ArrayList<FloatArray>()
        var boltAt = 0L
    }

    private class Particle(
        var x: Float, var y: Float, var vx: Float, var vy: Float,
        var life: Float, val max: Float, var size: Float, val kind: Int
    )

    private class Shot(
        var x: Float, var y: Float, val vx: Float, val vy: Float,
        var size: Float, val t0: Long, val kind: Kind, val nx: Float, val ny: Float, val nz: Float
    )

    private val hands = arrayOf(HandFx(), HandFx())
    private val parts = ArrayList<Particle>()
    private val shots = ArrayList<Shot>()
    private var lastT = 0L
    private var aspect = 1.1f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val path = Path()
    private val oval = RectF()

    fun select(k: Kind) {
        stopSounds()
        kind = k
        parts.clear()
    }

    fun stopSounds() {
        for (h in hands) {
            sfx.stop(h.stream)
            h.stream = 0
        }
    }

    // ================================================================ жаңарту
    fun update(now: Long, eye: List<EyeHand>, aspectRatio: Float) {
        aspect = aspectRatio
        val dt = if (lastT == 0L) 0.033f else min(0.06f, (now - lastT) / 1000f)
        lastT = now
        val aPos = 1f - exp(-dt * 16f)
        val aSize = 1f - exp(-dt * 10f)
        val aDir = 1f - exp(-dt * 9f)

        for (slot in 0..1) {
            val f = hands[slot]
            val hd = eye.firstOrNull { it.slot == slot }
            if (hd != null) {
                if (!f.init) {
                    f.init = true
                    f.x = hd.palmX
                    f.y = hd.palmY
                    f.size = hd.size
                    f.angle = hd.angle
                    f.nx = hd.nx
                    f.ny = hd.ny
                    f.nz = hd.nz
                }
                val ox = f.x
                val oy = f.y
                f.x += (hd.palmX - f.x) * aPos
                f.y += (hd.palmY - f.y) * aPos
                f.size += (hd.size - f.size) * aSize
                f.angle += wrap(hd.angle - f.angle) * aDir
                f.nx += (hd.nx - f.nx) * aDir
                f.ny += (hd.ny - f.ny) * aDir
                f.nz += (abs(hd.nz) - f.nz) * aDir
                if (dt > 0f) {
                    f.vx += ((f.x - ox) / dt - f.vx) * 0.5f
                    f.vy += ((f.y - oy) / dt - f.vy) * 0.5f
                }
                f.want = !hd.fist
                f.lastSeen = now
            } else if (now - f.lastSeen > 300L) {
                f.want = false
                f.init = false
                f.vx = 0f
                f.vy = 0f
            }

            // Жану / сөну (тегіс)
            val target = if (f.want && now >= f.cooldownUntil) 1f else 0f
            f.power += (target - f.power) * min(1f, dt * if (target > f.power) 4f else 7f)

            // Дыбыс циклы
            if (f.power > 0.3f && f.stream == 0) f.stream = sfx.loop(kind.sound, 0.5f, kind.rate)
            if (f.power < 0.1f && f.stream != 0) {
                sfx.stop(f.stream)
                f.stream = 0
            }
            if (f.stream != 0) sfx.setVolume(f.stream, 0.15f + 0.45f * f.power)

            if (f.power > 0.05f) {
                // Лақтыру: қолды тез сілтеу
                val speed = hypot(f.vx * aspect, f.vy)
                if ((kind == Kind.FIREBALL || kind == Kind.SHURIKEN) && f.power > 0.85f && speed > 2.0f) {
                    val (cx, cy) = orb(f)
                    val k = 1.3f / speed.coerceAtLeast(0.01f)
                    shots.add(Shot(cx, cy, f.vx * k * 1.4f, f.vy * k * 1.4f, radius(f), now, kind, f.nx, f.ny, f.nz))
                    f.power = 0f
                    f.cooldownUntil = now + 700L
                    sfx.play("whoosh", 0.9f)
                    sfx.vibrate(30)
                } else {
                    spawn(f, now, dt)
                }
            }
        }

        // ---- ұшқан снарядтар
        val sit = shots.iterator()
        while (sit.hasNext()) {
            val s = sit.next()
            s.x += s.vx * dt
            s.y += s.vy * dt
            s.size *= (1f - dt * 1.1f)
            if (s.kind == Kind.FIREBALL) {
                repeat(3) { flame(s.x, s.y, s.size * 0.8f) }
            }
            if (now - s.t0 > 650L || s.x < -0.2f || s.x > 1.2f || s.y < -0.2f || s.y > 1.2f) {
                explode(s)
                sit.remove()
            }
        }

        // ---- бөлшектер
        val pit = parts.iterator()
        while (pit.hasNext()) {
            val p = pit.next()
            p.life -= dt
            if (p.life <= 0f) {
                pit.remove()
                continue
            }
            p.x += p.vx * dt
            p.y += p.vy * dt
            if (p.kind == P_FLAME) {
                p.vy -= dt * 0.25f
                p.size *= (1f + dt * 0.9f)
            } else if (p.kind == P_SPARK) {
                p.vx *= (1f - dt * 2f)
                p.vy = p.vy * (1f - dt * 2f) + dt * 0.3f
            }
        }
        while (parts.size > MAX_PARTS) parts.removeAt(0)
    }

    /** Эффект центрі: алақан + алақан қараған жаққа ығысу. */
    private fun orb(f: HandFx): Pair<Float, Float> {
        val off = when (kind) {
            Kind.CHIDORI -> 0.35f
            Kind.SHURIKEN -> 1.1f
            else -> 0.85f
        }
        return Pair(f.x + f.nx * f.size * off / aspect, f.y + f.ny * f.size * off)
    }

    private fun radius(f: HandFx): Float = f.size * when (kind) {
        Kind.RASENGAN -> 0.55f
        Kind.CHIDORI -> 0.5f
        Kind.SHURIKEN -> 0.4f
        Kind.FIREBALL -> 0.5f
    }

    private fun spawn(f: HandFx, now: Long, dt: Float) {
        val (cx, cy) = orb(f)
        val r = radius(f) * f.power
        when (kind) {
            Kind.RASENGAN -> repeat(2) {
                val a = Random.nextFloat() * 6.283f
                val d = r * (1.2f + Random.nextFloat() * 0.6f)
                parts.add(Particle(cx + cos(a) * d / aspect, cy + sin(a) * d, -cos(a) * r * 1.5f / aspect, -sin(a) * r * 1.5f, 0.35f, 0.35f, r * 0.08f, P_WIND))
            }
            Kind.CHIDORI -> {
                repeat(3) {
                    val a = Random.nextFloat() * 6.283f
                    val v = 0.3f + Random.nextFloat() * 0.6f
                    parts.add(Particle(cx, cy, cos(a) * v / aspect * r * 4f, sin(a) * v * r * 4f, 0.3f, 0.3f, r * 0.06f, P_SPARK))
                }
                if (now - f.boltAt > 55L) {
                    f.boltAt = now
                    f.bolts.clear()
                    repeat(7) { f.bolts.add(makeBolt(cx, cy, r)) }
                }
            }
            Kind.SHURIKEN -> if (Random.nextFloat() < 0.6f) {
                val a = Random.nextFloat() * 6.283f
                parts.add(Particle(cx, cy, cos(a) * r * 3f / aspect, sin(a) * r * 3f, 0.3f, 0.3f, r * 0.07f, P_WIND))
            }
            Kind.FIREBALL -> repeat(max(1, (dt * 150f).toInt())) { flame(cx, cy, r) }
        }
    }

    private fun flame(cx: Float, cy: Float, r: Float) {
        val a = Random.nextFloat() * 6.283f
        val d = Random.nextFloat() * r * 0.7f
        parts.add(
            Particle(
                cx + cos(a) * d / aspect, cy + sin(a) * d,
                (Random.nextFloat() - 0.5f) * r * 0.8f / aspect, -r * (1.2f + Random.nextFloat() * 1.2f),
                0.55f, 0.55f, r * (0.25f + Random.nextFloat() * 0.25f), P_FLAME
            )
        )
    }

    private fun explode(s: Shot) {
        repeat(45) {
            val a = Random.nextFloat() * 6.283f
            val v = 0.2f + Random.nextFloat() * 0.8f
            val k = if (s.kind == Kind.FIREBALL) P_FLAME else P_SPARK
            parts.add(Particle(s.x, s.y, cos(a) * v / aspect * 0.6f, sin(a) * v * 0.6f, 0.6f, 0.6f, s.size * 0.4f, k))
        }
        sfx.play("boom", 0.8f, if (s.kind == Kind.FIREBALL) 1f else 1.4f)
        sfx.vibrate(60)
    }

    /** Найзағай: центрден шығатын сынық сызық (x, y жұптары). */
    private fun makeBolt(cx: Float, cy: Float, r: Float): FloatArray {
        val segs = 6
        val pts = FloatArray((segs + 1) * 2)
        val a = Random.nextFloat() * 6.283f
        val len = r * (1.4f + Random.nextFloat() * 1.6f)
        val dx = cos(a)
        val dy = sin(a)
        for (i in 0..segs) {
            val t = i.toFloat() / segs
            val jitter = if (i == 0) 0f else (Random.nextFloat() - 0.5f) * r * 0.55f
            val px = dx * len * t - dy * jitter
            val py = dy * len * t + dx * jitter
            pts[i * 2] = cx + px / aspect
            pts[i * 2 + 1] = cy + py
        }
        return pts
    }

    // ================================================================ сурет салу
    fun draw(c: Canvas, w: Int, h: Int, now: Long) {
        val fw = w.toFloat()
        val fh = h.toFloat()
        val t = now / 1000f

        // Бөлшектер (артта)
        for (p in parts) drawParticle(c, p, fw, fh)

        for (f in hands) {
            if (f.power < 0.03f) continue
            val (cx, cy) = orb(f)
            val r = radius(f) * f.power * fh
            val x = cx * fw
            val y = cy * fh
            when (kind) {
                Kind.RASENGAN -> drawRasengan(c, x, y, r, f.angle, f.nx, f.ny, f.nz, t, 1f)
                Kind.CHIDORI -> drawChidori(c, f, x, y, r, fw, fh)
                Kind.SHURIKEN -> drawShuriken(c, x, y, r, f.nx, f.ny, f.nz, t)
                Kind.FIREBALL -> drawFireCore(c, x, y, r)
            }
        }

        for (s in shots) {
            val x = s.x * fw
            val y = s.y * fh
            val r = s.size * fh
            when (s.kind) {
                Kind.SHURIKEN -> drawShuriken(c, x, y, r, s.nx, s.ny, s.nz, t * 1.5f)
                else -> drawFireCore(c, x, y, r)
            }
        }
    }

    private fun drawParticle(c: Canvas, p: Particle, fw: Float, fh: Float) {
        val k = (p.life / p.max).coerceIn(0f, 1f)
        val x = p.x * fw
        val y = p.y * fh
        val s = max(1f, p.size * fh)
        when (p.kind) {
            P_FLAME -> {
                // Сары → қызғылт сары → қызыл → түтін
                val col = when {
                    k > 0.7f -> Color.argb((230 * k).toInt(), 255, 230, 120)
                    k > 0.4f -> Color.argb((210 * k).toInt(), 255, 140, 30)
                    k > 0.2f -> Color.argb((190 * k).toInt(), 220, 50, 20)
                    else -> Color.argb((160 * k).toInt(), 70, 60, 60)
                }
                fill.color = col
                c.drawCircle(x, y, s, fill)
            }
            P_SPARK -> {
                fill.color = Color.argb((255 * k).toInt(), 200, 230, 255)
                c.drawCircle(x, y, s, fill)
            }
            else -> {
                fill.color = Color.argb((200 * k).toInt(), 180, 235, 255)
                c.drawCircle(x, y, s, fill)
            }
        }
    }

    /**
     * Перспективадағы диск: алақан нормаліне перпендикуляр.
     * Канвасты дисктің үлкен осіне бұрамыз, кіші осі = |nz| есе қысылған.
     */
    private fun diskFrame(c: Canvas, x: Float, y: Float, nx: Float, ny: Float, fallbackAngle: Float): Float {
        val nlen = sqrt(nx * nx + ny * ny)
        val ang = if (nlen > 0.15f) atan2(ny, nx) + 1.5708f else fallbackAngle + 1.5708f
        c.save()
        c.translate(x, y)
        c.rotate(Math.toDegrees(ang.toDouble()).toFloat(), 0f, 0f)
        return nlen
    }

    private fun glow(c: Canvas, x: Float, y: Float, r: Float, inner: Int, outer: Int) {
        if (r < 1f) return
        fill.shader = RadialGradient(x, y, r, intArrayOf(inner, outer, Color.argb(0, 0, 0, 0)), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, fill)
        fill.shader = null
    }

    private fun drawRasengan(c: Canvas, x: Float, y: Float, r: Float, angle: Float, nx: Float, ny: Float, nz: Float, t: Float, alpha: Float) {
        if (r < 2f) return
        glow(c, x, y, r * 2.3f, Color.argb((110 * alpha).toInt(), 120, 200, 255), Color.argb((40 * alpha).toInt(), 60, 140, 255))
        // Ядро
        fill.shader = RadialGradient(
            x, y, r,
            intArrayOf(Color.argb(255, 255, 255, 255), Color.argb(235, 170, 230, 255), Color.argb(150, 60, 150, 255), Color.argb(0, 40, 100, 255)),
            floatArrayOf(0f, 0.35f, 0.75f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(x, y, r, fill)
        fill.shader = null

        // Айналған құйындар — диск жазықтығында
        val flat = abs(nz).coerceIn(0.3f, 1f)
        diskFrame(c, x, y, nx, ny, angle)
        stroke.color = Color.argb(200, 255, 255, 255)
        for (i in 0 until 3) {
            val rr = r * (0.55f + i * 0.17f)
            oval.set(-rr, -rr * flat, rr, rr * flat)
            stroke.strokeWidth = max(1.5f, r * 0.07f)
            val start = (t * (720f + i * 160f)) % 360f + i * 120f
            c.drawArc(oval, start, 150f, false, stroke)
        }
        stroke.color = Color.argb(150, 160, 220, 255)
        for (i in 0 until 2) {
            val rr = r * (0.8f + i * 0.12f)
            oval.set(-rr * flat, -rr, rr * flat, rr)
            stroke.strokeWidth = max(1f, r * 0.05f)
            c.drawArc(oval, -(t * 600f) % 360f + i * 180f, 120f, false, stroke)
        }
        c.restore()
    }

    private fun drawChidori(c: Canvas, f: HandFx, x: Float, y: Float, r: Float, fw: Float, fh: Float) {
        if (r < 2f) return
        glow(c, x, y, r * 2.6f, Color.argb(130, 140, 200, 255), Color.argb(50, 60, 120, 255))
        glow(c, x, y, r * 0.9f, Color.argb(255, 255, 255, 255), Color.argb(200, 180, 220, 255))
        for (b in f.bolts) {
            path.reset()
            path.moveTo(b[0] * fw, b[1] * fh)
            var i = 2
            while (i < b.size) {
                path.lineTo(b[i] * fw, b[i + 1] * fh)
                i += 2
            }
            stroke.color = Color.argb(140, 90, 160, 255)
            stroke.strokeWidth = max(2f, r * 0.16f)
            c.drawPath(path, stroke)
            stroke.color = Color.argb(255, 235, 245, 255)
            stroke.strokeWidth = max(1f, r * 0.05f)
            c.drawPath(path, stroke)
        }
    }

    private fun drawShuriken(c: Canvas, x: Float, y: Float, r: Float, nx: Float, ny: Float, nz: Float, t: Float) {
        if (r < 2f) return
        val flat = abs(nz).coerceIn(0.25f, 1f)
        // Сыртқы жарқыл мен сақина
        glow(c, x, y, r * 3.2f, Color.argb(90, 200, 230, 255), Color.argb(40, 120, 180, 255))
        diskFrame(c, x, y, nx, ny, 0f)
        stroke.color = Color.argb(90, 230, 245, 255)
        stroke.strokeWidth = r * 0.5f
        oval.set(-r * 2.1f, -r * 2.1f * flat, r * 2.1f, r * 2.1f * flat)
        c.drawOval(oval, stroke)
        // 4 жүз (айналады)
        val spin = t * 14f
        for (k in 0 until 4) {
            val a0 = spin + k * 1.5708f
            path.reset()
            val inR = r * 0.7f
            val outR = r * 3.0f
            path.moveTo(cos(a0 - 0.32f) * inR, sin(a0 - 0.32f) * inR * flat)
            path.quadTo(cos(a0 + 0.1f) * outR * 0.65f, sin(a0 + 0.1f) * outR * 0.65f * flat, cos(a0 + 0.45f) * outR, sin(a0 + 0.45f) * outR * flat)
            path.quadTo(cos(a0 + 0.3f) * outR * 0.55f, sin(a0 + 0.3f) * outR * 0.55f * flat, cos(a0 + 0.32f) * inR, sin(a0 + 0.32f) * inR * flat)
            path.close()
            fill.color = Color.argb(215, 240, 250, 255)
            c.drawPath(path, fill)
            stroke.color = Color.argb(180, 120, 190, 255)
            stroke.strokeWidth = max(1f, r * 0.06f)
            c.drawPath(path, stroke)
        }
        c.restore()
        // Ортасында Расенган
        drawRasengan(c, x, y, r * 0.9f, 0f, nx, ny, nz, t, 1f)
    }

    private fun drawFireCore(c: Canvas, x: Float, y: Float, r: Float) {
        if (r < 2f) return
        glow(c, x, y, r * 2.4f, Color.argb(120, 255, 150, 40), Color.argb(50, 255, 80, 20))
        fill.shader = RadialGradient(
            x, y, r,
            intArrayOf(Color.argb(255, 255, 250, 210), Color.argb(240, 255, 200, 60), Color.argb(200, 255, 110, 20), Color.argb(0, 200, 40, 10)),
            floatArrayOf(0f, 0.3f, 0.7f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(x, y, r, fill)
        fill.shader = null
    }

    private fun wrap(a: Float): Float {
        var v = a
        while (v > 3.14159f) v -= 6.28318f
        while (v < -3.14159f) v += 6.28318f
        return v
    }

    companion object {
        private const val P_WIND = 0
        private const val P_SPARK = 1
        private const val P_FLAME = 2
        private const val MAX_PARTS = 260
    }
}
