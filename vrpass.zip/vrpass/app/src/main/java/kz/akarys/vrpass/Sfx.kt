package kz.akarys.vrpass

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Ойын дыбыстары: бәрі код арқылы синтезделеді (файл жүктеудің қажеті жоқ),
 * WAV болып кэшке жазылып, SoundPool арқылы жылдам ойналады. Сонымен қатар діріл.
 */
class Sfx(private val ctx: Context) {

    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(12)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()
    private val ids = ConcurrentHashMap<String, Int>()
    private val vibrator: Vibrator? = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    private val rnd = Random(7)

    init {
        Thread { generateAll() }.start()
    }

    fun play(name: String, volume: Float = 1f, rate: Float = 1f) {
        val id = ids[name] ?: return
        pool.play(id, volume, volume, 1, 0, rate)
    }

    fun note(index: Int) = play("note$index", 0.9f)

    /** Үздіксіз (цикл) дыбыс. Қайтарады: ағын нөмірі (тоқтату үшін), 0 — ойналмады. */
    fun loop(name: String, volume: Float, rate: Float = 1f): Int {
        val id = ids[name] ?: return 0
        return pool.play(id, volume, volume, 1, -1, rate)
    }

    fun stop(stream: Int) {
        if (stream != 0) pool.stop(stream)
    }

    fun setVolume(stream: Int, volume: Float) {
        if (stream != 0) pool.setVolume(stream, volume, volume)
    }

    /** Басқанда қысқа «шырт» + жеңіл діріл. */
    fun click() {
        play("tick", 0.6f)
        vibrate(12)
    }

    fun vibrate(ms: Long) {
        val v = vibrator ?: return
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(ms)
            }
        } catch (e: Exception) {
            Log.w(TAG, "vibrate", e)
        }
    }

    fun release() {
        pool.release()
    }

    // ================================================================ синтез
    private fun generateAll() {
        try {
            val dir = File(ctx.cacheDir, "sfx")
            dir.mkdirs()
            val freqs = doubleArrayOf(261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25, 587.33, 659.25)
            for (i in freqs.indices) save(dir, "note$i", piano(freqs[i]))
            save(dir, "pop", pop())
            save(dir, "shot", shot())
            save(dir, "boom", boom())
            save(dir, "crash", crash())
            save(dir, "ding", ding())
            save(dir, "beat", heartbeat())
            save(dir, "scream", scream())
            save(dir, "tick", tick())
            save(dir, "whoosh", whoosh())
            save(dir, "hum", hum())
            save(dir, "zap", zap())
            save(dir, "whir", whir())
            save(dir, "flame", flameLoop())
        } catch (t: Throwable) {
            Log.e(TAG, "generate", t)
        }
    }

    private fun save(dir: File, name: String, pcm: FloatArray) {
        val f = File(dir, "$name.wav")
        writeWav(f, pcm)
        ids[name] = pool.load(f.path, 1)
    }

    private fun buf(seconds: Double) = FloatArray((seconds * SR).toInt())

    private fun piano(f: Double): FloatArray {
        val out = buf(1.4)
        for (i in out.indices) {
            val t = i.toDouble() / SR
            val env = if (t < 0.006) t / 0.006 else exp(-3.0 * t)
            val w = 2 * PI * f * t
            val s = sin(w) + 0.5 * sin(2 * w) * exp(-1.5 * t) + 0.25 * sin(3 * w) * exp(-2.5 * t) +
                0.1 * sin(4 * w) * exp(-4.0 * t)
            out[i] = (s * env * 0.38).toFloat()
        }
        return out
    }

    private fun pop(): FloatArray {
        val out = buf(0.12)
        var phase = 0.0
        for (i in out.indices) {
            val t = i.toDouble() / SR
            val f = 900.0 - 3500.0 * t
            phase += 2 * PI * f / SR
            out[i] = (sin(phase) * exp(-30.0 * t) * 0.7).toFloat()
        }
        return out
    }

    private fun shot(): FloatArray {
        val out = buf(0.3)
        for (i in out.indices) {
            val t = i.toDouble() / SR
            val noise = rnd.nextDouble() * 2 - 1
            out[i] = (noise * exp(-22.0 * t) * 0.8 + sin(2 * PI * 110 * t) * exp(-18.0 * t) * 0.6).toFloat()
        }
        return out
    }

    private fun boom(): FloatArray {
        val out = buf(0.8)
        var lp = 0.0
        for (i in out.indices) {
            val t = i.toDouble() / SR
            lp += ((rnd.nextDouble() * 2 - 1) - lp) * 0.08
            out[i] = ((lp * 3.0 * exp(-4.5 * t)) + sin(2 * PI * 55 * t) * exp(-4.0 * t) * 0.7).toFloat()
        }
        return out
    }

    private fun crash(): FloatArray {
        val out = buf(0.9)
        for (i in out.indices) {
            val t = i.toDouble() / SR
            val noise = rnd.nextDouble() * 2 - 1
            out[i] = (noise * exp(-4.0 * t) * 0.7 + sin(2 * PI * 820 * t) * exp(-9.0 * t) * 0.3 +
                sin(2 * PI * 60 * t) * exp(-5.0 * t) * 0.5).toFloat()
        }
        return out
    }

    private fun ding(): FloatArray {
        val out = buf(0.4)
        for (i in out.indices) {
            val t = i.toDouble() / SR
            out[i] = ((sin(2 * PI * 1320 * t) + 0.6 * sin(2 * PI * 1760 * t)) * exp(-8.0 * t) * 0.35).toFloat()
        }
        return out
    }

    private fun heartbeat(): FloatArray {
        val out = buf(0.55)
        for (i in out.indices) {
            val t = i.toDouble() / SR
            var s = 0.0
            for (start in doubleArrayOf(0.0, 0.2)) {
                val tt = t - start
                if (tt >= 0) s += sin(2 * PI * 48 * tt) * exp(-28.0 * tt)
            }
            out[i] = (s * 0.9).toFloat()
        }
        return out
    }

    private fun scream(): FloatArray {
        val out = buf(1.4)
        var phase = 0.0
        for (i in out.indices) {
            val t = i.toDouble() / SR
            val f = 1250.0 - 600.0 * t / 1.4 + 60.0 * sin(2 * PI * 9 * t)
            phase += f / SR
            val saw = 2.0 * (phase - Math.floor(phase + 0.5))
            val env = if (t < 0.02) t / 0.02 else exp(-1.1 * (t - 0.02))
            val noise = rnd.nextDouble() * 2 - 1
            out[i] = ((saw * 0.7 + noise * 0.35) * env * 0.9).toFloat()
        }
        return out
    }

    private fun tick(): FloatArray {
        val out = buf(0.04)
        for (i in out.indices) {
            val t = i.toDouble() / SR
            out[i] = (sin(2 * PI * 2200 * t) * exp(-120.0 * t) * 0.6).toFloat()
        }
        return out
    }

    private fun whoosh(): FloatArray {
        val out = buf(0.5)
        var lp = 0.0
        for (i in out.indices) {
            val t = i.toDouble() / SR
            val k = 0.05 + 0.4 * (t / 0.5)
            lp += ((rnd.nextDouble() * 2 - 1) - lp) * k
            val env = sin(PI * t / 0.5)
            out[i] = (lp * env * 1.2).toFloat()
        }
        return out
    }

    // Циклдар 1 секунд, жиіліктер бүтін сан — шегінде «шырт» болмайды
    private fun hum(): FloatArray {
        val out = buf(1.0)
        var lp = 0.0
        for (i in out.indices) {
            val t = i.toDouble() / SR
            lp += ((rnd.nextDouble() * 2 - 1) - lp) * 0.02
            val mod = 0.7 + 0.3 * sin(2 * PI * 6 * t)
            val s = sin(2 * PI * 110 * t) * 0.5 + sin(2 * PI * 220 * t) * 0.3 + sin(2 * PI * 330 * t) * 0.15
            out[i] = ((s * mod + lp * 2.0) * 0.45).toFloat()
        }
        return out
    }

    private fun zap(): FloatArray {
        val out = buf(1.0)
        var burst = 0.0
        for (i in out.indices) {
            val t = i.toDouble() / SR
            if (rnd.nextDouble() < 0.0025) burst = 1.0
            burst *= 0.9985
            val noise = rnd.nextDouble() * 2 - 1
            val chirp = sin(2 * PI * (2400 + 600 * sin(2 * PI * 13 * t)) * t) * 0.15
            out[i] = ((noise * (0.12 + burst * 0.7)) + chirp).toFloat() * 0.6f
        }
        return out
    }

    private fun whir(): FloatArray {
        val out = buf(1.0)
        var phase = 0.0
        for (i in out.indices) {
            val t = i.toDouble() / SR
            phase += 320.0 / SR
            val saw = 2.0 * (phase - Math.floor(phase + 0.5))
            val noise = rnd.nextDouble() * 2 - 1
            out[i] = ((saw * 0.25 + noise * 0.25) * (0.75 + 0.25 * sin(2 * PI * 20 * t))).toFloat()
        }
        return out
    }

    private fun flameLoop(): FloatArray {
        val out = buf(1.0)
        var lp = 0.0
        for (i in out.indices) {
            val t = i.toDouble() / SR
            lp += ((rnd.nextDouble() * 2 - 1) - lp) * 0.06
            val crackle = if (rnd.nextDouble() < 0.0015) rnd.nextDouble() - 0.5 else 0.0
            out[i] = ((lp * 1.6 + crackle * 1.5 + sin(2 * PI * 60 * t) * 0.15) * 0.6).toFloat()
        }
        return out
    }

    private fun writeWav(file: File, pcm: FloatArray) {
        val dataLen = pcm.size * 2
        val bb = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray(Charsets.US_ASCII))
        bb.putInt(36 + dataLen)
        bb.put("WAVE".toByteArray(Charsets.US_ASCII))
        bb.put("fmt ".toByteArray(Charsets.US_ASCII))
        bb.putInt(16)
        bb.putShort(1.toShort())
        bb.putShort(1.toShort())
        bb.putInt(SR)
        bb.putInt(SR * 2)
        bb.putShort(2.toShort())
        bb.putShort(16.toShort())
        bb.put("data".toByteArray(Charsets.US_ASCII))
        bb.putInt(dataLen)
        for (s in pcm) {
            val v = (s.coerceIn(-1f, 1f) * 32767f).toInt()
            bb.putShort(v.toShort())
        }
        FileOutputStream(file).use { it.write(bb.array()) }
    }

    companion object {
        private const val TAG = "Sfx"
        private const val SR = 22050
    }
}
