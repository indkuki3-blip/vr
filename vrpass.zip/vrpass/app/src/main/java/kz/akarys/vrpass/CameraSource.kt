package kz.akarys.vrpass

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.util.Size
import android.view.Surface
import kotlin.math.abs

/**
 * Артқы камераны ашады. Екі ағын:
 *  1) SurfaceTexture — экранға шығатын видео (OpenGL);
 *  2) ImageReader (YUV, кішкене) — қол трекингіне.
 */
class CameraSource(
    private val ctx: Context,
    private val state: VrState,
    private val tracker: HandTracker
) {
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    private var previewSurface: Surface? = null
    private var camThread: HandlerThread? = null
    private var camHandler: Handler? = null
    private var handThread: HandlerThread? = null
    private var active = false
    private var generation = 0
    private var fpsRange: android.util.Range<Int>? = null

    @SuppressLint("MissingPermission")
    fun start(st: SurfaceTexture) {
        if (active) return
        active = true
        val gen = ++generation
        try {
            val ct = HandlerThread("camera").also { it.start() }
            camThread = ct
            val ch = Handler(ct.looper)
            camHandler = ch
            // Қол трекингі — фондық басымдықта (экранға салу бірінші тұрсын)
            val ht = HandlerThread("hands", android.os.Process.THREAD_PRIORITY_BACKGROUND).also { it.start() }
            handThread = ht
            val hh = Handler(ht.looper)

            val manager = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val ids = manager.cameraIdList
            val id = ids.firstOrNull {
                manager.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) ==
                    CameraCharacteristics.LENS_FACING_BACK
            } ?: ids.first()
            val chars = manager.getCameraCharacteristics(id)
            state.sensorOrientation = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?: throw IllegalStateException("stream map жоқ")

            // 960×540 жеткілікті: линза арқылы айырмашылық білінбейді, ал GPU жүгі азаяды
            val pSize = choose(map.getOutputSizes(SurfaceTexture::class.java), 960, 16f / 9f)
            st.setDefaultBufferSize(pSize.width, pSize.height)
            state.camW = pSize.width
            state.camH = pSize.height
            val aspect = pSize.width.toFloat() / pSize.height

            // Камераның көру бұрышы (FOV): кеңістікке бекітілген мәзір камера суретімен бірге жылжуы үшін
            try {
                val focal = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
                val phys = chars.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
                if (focal != null && phys != null && focal > 0f) {
                    val tw = phys.width / (2f * focal)
                    state.camTanW = tw
                    state.camTanH = tw / aspect
                }
            } catch (e: Exception) {
                Log.w(TAG, "fov", e)
            }

            val aSize = choose(map.getOutputSizes(ImageFormat.YUV_420_888), 640, aspect)
            val r = ImageReader.newInstance(aSize.width, aSize.height, ImageFormat.YUV_420_888, 2)
            r.setOnImageAvailableListener({ rd ->
                val image = try {
                    rd.acquireLatestImage()
                } catch (e: Exception) {
                    null
                }
                if (image != null) {
                    try {
                        tracker.process(image)
                    } catch (t: Throwable) {
                        Log.w(TAG, "hand process", t)
                    } finally {
                        image.close()
                    }
                }
            }, hh)
            reader = r

            val ps = Surface(st)
            previewSurface = ps

            // Тұрақты 30 кадр/с (видео секірмесін)
            fpsRange = try {
                chars.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                    ?.filter { it.upper == 30 }
                    ?.maxByOrNull { it.lower }
            } catch (e: Exception) {
                null
            }

            manager.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    if (!active || gen != generation) {
                        camera.close()
                        return
                    }
                    device = camera
                    createSession(camera, ps, r.surface, gen)
                }

                override fun onDisconnected(camera: CameraDevice) {
                    camera.close()
                    if (device === camera) device = null
                }

                override fun onError(camera: CameraDevice, error: Int) {
                    camera.close()
                    if (device === camera) device = null
                    state.cameraStatus = "Камера қатесі ($error). Қосымшаны қайта ашыңыз"
                }
            }, ch)
        } catch (t: Throwable) {
            Log.e(TAG, "start", t)
            state.cameraStatus = "Камера ашылмады: ${t.message ?: t.javaClass.simpleName}"
            stop()
        }
    }

    @Suppress("DEPRECATION")
    private fun createSession(camera: CameraDevice, preview: Surface, analysis: Surface?, gen: Int) {
        val targets = if (analysis != null) listOf(preview, analysis) else listOf(preview)
        try {
            camera.createCaptureSession(targets, object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (!active || gen != generation) {
                        s.close()
                        return
                    }
                    session = s
                    try {
                        val req = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                        for (t in targets) req.addTarget(t)
                        req.set(
                            CaptureRequest.CONTROL_AF_MODE,
                            CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO
                        )
                        fpsRange?.let { req.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
                        s.setRepeatingRequest(req.build(), null, camHandler)
                    } catch (e: Exception) {
                        Log.e(TAG, "repeating", e)
                    }
                }

                override fun onConfigureFailed(s: CameraCaptureSession) {
                    if (analysis != null && active && gen == generation) {
                        // Кейбір камералар екі ағынды бірге бермейді — тек видеомен жалғастырамыз
                        state.trackerStatus = "Бұл камерада қол трекингі жұмыс істемейді"
                        createSession(camera, preview, null, gen)
                    } else {
                        state.cameraStatus = "Камера сессиясы ашылмады"
                    }
                }
            }, camHandler)
        } catch (e: Exception) {
            Log.e(TAG, "session", e)
            state.cameraStatus = "Камера сессиясы ашылмады"
        }
    }

    fun stop() {
        active = false
        generation++
        try {
            session?.close()
        } catch (e: Exception) {
            Log.w(TAG, "session close", e)
        }
        session = null
        try {
            device?.close()
        } catch (e: Exception) {
            Log.w(TAG, "device close", e)
        }
        device = null
        handThread?.quitSafely()
        handThread = null
        try {
            reader?.close()
        } catch (e: Exception) {
            Log.w(TAG, "reader close", e)
        }
        reader = null
        previewSurface?.release()
        previewSurface = null
        camThread?.quitSafely()
        camThread = null
        camHandler = null
    }

    /** Берілген пропорциядағы, енi targetW-ға ең жақын өлшем. */
    private fun choose(sizes: Array<Size>?, targetW: Int, aspect: Float): Size {
        val list = sizes?.toList().orEmpty()
        if (list.isEmpty()) return Size(targetW, (targetW / aspect).toInt())
        val same = list.filter { abs(it.width.toFloat() / it.height - aspect) < 0.02f }
        val pool = if (same.isNotEmpty()) same else list
        return pool.minByOrNull { abs(it.width - targetW) } ?: list[0]
    }

    companion object {
        private const val TAG = "CameraSource"
    }
}
