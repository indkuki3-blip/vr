package kz.akarys.vrpass

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.asin
import kotlin.math.atan2

/**
 * Бастың бұрылысы (3DoF) — телефонның айналу сенсорынан.
 * Телефонның артқы жағы (камера) қараған бағыт = көз қараған бағыт.
 * Компассыз «ойын» сенсоры қолданылады: магниттен секірмейді.
 */
class HeadTracker(ctx: Context, private val state: VrState) : SensorEventListener {

    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val sensor: Sensor? = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
        ?: sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val rot = FloatArray(9)

    fun start() {
        val s = sensor ?: return
        sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stop() {
        sm.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(rot, event.values)
        // Әлем координатасындағы «алға» векторы = −Z (телефонның артқы жағы)
        val fx = -rot[2]
        val fy = -rot[5]
        val fz = -rot[8]
        state.headYaw = -atan2(fy, fx)
        state.headPitch = asin(fz.coerceIn(-1f, 1f))
        state.headValid = true
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
