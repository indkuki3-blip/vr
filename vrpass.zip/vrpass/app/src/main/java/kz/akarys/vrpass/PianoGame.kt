package kz.akarys.vrpass

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF

/**
 * Ауадағы пианино: 10 перне, екі қолдың 10 саусағы да жұмыс істейді.
 * Саусақ ұшы сызықтан төмен түссе — нота ойналады. Саусақты пернеден пернеге жүргізуге болады.
 */
class PianoGame(private val sfx: Sfx) : MiniGame {

    override val id = "piano"
    override val title = "Пианино"
    override val finished = false
    override var score = 0
        private set

    private val names = arrayOf("До", "Ре", "Ми", "Фа", "Соль", "Ля", "Си", "До", "Ре", "Ми")
    private val keyCount = names.size
    private val tips = intArrayOf(4, 8, 12, 16, 20)
    private val fingerDown = BooleanArray(10)
    private val fingerKey = IntArray(10) { -1 }
    private val keyFlash = LongArray(keyCount)
    private val keyHeld = BooleanArray(keyCount)
    private val dots = ArrayList<FloatArray>()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()

    override fun start(now: Long) {
        score = 0
        fingerDown.fill(false)
        fingerKey.fill(-1)
        keyFlash.fill(0L)
    }

    override fun update(now: Long, hands: List<EyeHand>, aspect: Float) {
        val seen = BooleanArray(10)
        dots.clear()
        keyHeld.fill(false)
        for (hd in hands) {
            for (fi in tips.indices) {
                val fid = hd.slot * 5 + fi
                if (fid !in 0..9) continue
                seen[fid] = true
                val x = hd.x(tips[fi])
                val y = hd.y(tips[fi])
                val k = keyAt(x)
                if (!fingerDown[fid]) {
                    if (y > PRESS_Y && y < BOTTOM + 0.08f && k >= 0) press(fid, k, now)
                } else {
                    if (y < RELEASE_Y || k < 0) {
                        fingerDown[fid] = false
                        fingerKey[fid] = -1
                    } else if (k != fingerKey[fid]) {
                        press(fid, k, now)
                    }
                }
                if (fingerDown[fid] && fingerKey[fid] >= 0) keyHeld[fingerKey[fid]] = true
                dots.add(floatArrayOf(x, y, if (fingerDown[fid]) 1f else 0f))
            }
        }
        for (i in 0 until 10) {
            if (!seen[i]) {
                fingerDown[i] = false
                fingerKey[i] = -1
            }
        }
    }

    private fun press(fid: Int, k: Int, now: Long) {
        fingerDown[fid] = true
        fingerKey[fid] = k
        keyFlash[k] = now
        sfx.note(k)
        score++
    }

    private fun keyAt(x: Float): Int {
        if (x < LEFT || x >= RIGHT) return -1
        return ((x - LEFT) / (RIGHT - LEFT) * keyCount).toInt().coerceIn(0, keyCount - 1)
    }

    override fun draw(c: Canvas, w: Int, h: Int, now: Long) {
        val fw = w.toFloat()
        val fh = h.toFloat()
        val kw = (RIGHT - LEFT) / keyCount

        // Пернелер астындағы фон
        fill.color = Color.argb(150, 10, 12, 20)
        rect.set((LEFT - 0.02f) * fw, (TOP - 0.03f) * fh, (RIGHT + 0.02f) * fw, (BOTTOM + 0.03f) * fh)
        c.drawRoundRect(rect, fh * 0.02f, fh * 0.02f, fill)

        for (k in 0 until keyCount) {
            val l = (LEFT + k * kw) * fw
            val r = (LEFT + (k + 1) * kw) * fw
            val flash = (1f - (now - keyFlash[k]) / 350f).coerceIn(0f, 1f)
            fill.color = when {
                keyHeld[k] -> Color.rgb(120, 200, 255)
                flash > 0f -> Color.rgb((255 - 120 * flash).toInt(), (255 - 40 * flash).toInt(), 255)
                else -> Color.argb(235, 245, 245, 245)
            }
            rect.set(l + fh * 0.004f, TOP * fh, r - fh * 0.004f, BOTTOM * fh)
            c.drawRoundRect(rect, fh * 0.01f, fh * 0.01f, fill)
            GameText.draw(c, names[k], (l + r) / 2f, BOTTOM * fh - fh * 0.03f, fh * 0.03f, Color.rgb(40, 50, 70))
        }
        // Басу сызығы
        line.color = Color.argb(200, 255, 210, 80)
        line.strokeWidth = fh * 0.005f
        c.drawLine(LEFT * fw, PRESS_Y * fh, RIGHT * fw, PRESS_Y * fh, line)

        // Саусақ ұштары
        for (d in dots) {
            fill.color = if (d[2] > 0.5f) Color.rgb(255, 210, 60) else Color.argb(220, 120, 220, 255)
            c.drawCircle(d[0] * fw, d[1] * fh, fh * 0.014f, fill)
        }

        GameText.draw(c, "ПИАНИНО — саусақты сары сызықтан төмен түсір", fw * 0.5f, fh * 0.2f, fh * 0.036f, Color.WHITE)
        GameText.draw(c, "Ноталар: $score", fw * 0.5f, fh * 0.26f, fh * 0.032f, Color.rgb(140, 200, 255))
    }

    companion object {
        private const val LEFT = 0.10f
        private const val RIGHT = 0.90f
        private const val TOP = 0.52f
        private const val BOTTOM = 0.86f
        private const val PRESS_Y = 0.58f
        private const val RELEASE_Y = 0.54f
    }
}
