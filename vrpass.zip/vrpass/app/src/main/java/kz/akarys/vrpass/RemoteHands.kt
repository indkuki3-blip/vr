package kz.akarys.vrpass

import android.graphics.Bitmap
import android.os.SystemClock
import android.util.Log
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.NetworkInterface
import java.nio.ByteBuffer

/**
 * Ноутпен байланыс (UDP, порт 47800): кадрды JPEG қылып жібереді, қол нүктелерін қабылдайды.
 * Сервер IP-і бос болса — желіден өзі іздейді (broadcast «VRD?»).
 * Хаттама ноуттағы vr_server.py файлының басында сипатталған.
 */
class RemoteHands(
    private val state: VrState,
    private val onHands: (List<HandTracker.Detected>, Float) -> Unit
) {
    @Volatile private var socket: DatagramSocket? = null
    @Volatile private var server: InetAddress? = null
    @Volatile private var lastReply = 0L
    @Volatile private var aspect = 16f / 9f
    private var receiver: Thread? = null
    private var seq = 0
    private var lastSeqIn = 0
    private val sentAt = LongArray(64)
    private var lastDiscovery = 0L
    private var manualIp = ""
    private val jpeg = ByteArrayOutputStream(32_000)
    private var latencyAvg = 0f

    /** Сервер соңғы 1.5 секундта жауап берді ме. */
    fun connected(): Boolean = server != null && SystemClock.uptimeMillis() - lastReply < 1500L

    /** Талдау ағынынан шақырылады. */
    fun send(bmp: Bitmap) {
        val s = ensureSocket() ?: return
        val now = SystemClock.uptimeMillis()
        try {
            val ip = state.remoteIp.trim()
            if (ip != manualIp) {
                manualIp = ip
                server = null
            }
            if (ip.isNotEmpty() && server == null) {
                server = InetAddress.getByName(ip)
            } else if (ip.isEmpty() && !connected() && now - lastDiscovery > 1000L) {
                lastDiscovery = now
                discover(s)
            }
            updateStatus(now)
            val srv = server ?: return

            jpeg.reset()
            bmp.compress(Bitmap.CompressFormat.JPEG, 60, jpeg)
            seq++
            val body = jpeg.toByteArray()
            val data = ByteArray(8 + body.size)
            data[0] = 'V'.code.toByte()
            data[1] = 'R'.code.toByte()
            data[2] = 'F'.code.toByte()
            data[3] = '1'.code.toByte()
            ByteBuffer.wrap(data, 4, 4).putInt(seq)
            System.arraycopy(body, 0, data, 8, body.size)
            aspect = bmp.width.toFloat() / bmp.height
            sentAt[seq and 63] = now
            s.send(DatagramPacket(data, data.size, srv, PORT))
        } catch (t: Throwable) {
            Log.w(TAG, "send", t)
        }
    }

    private fun updateStatus(now: Long) {
        val srv = server
        state.remoteStatus = when {
            srv != null && now - lastReply < 1500L ->
                "Қосылды: ${srv.hostAddress} · ${latencyAvg.toInt()} мс"
            srv != null && lastReply > 0L -> "Ноут жауап бермейді — телефонда есептеп тұр"
            manualIp.isNotEmpty() -> "Қосылуда: $manualIp…"
            else -> "Ноут іздеуде… (ноутта ISKE_QOSU.bat ашық па?)"
        }
    }

    /** Желінің барлық broadcast адрестеріне «VRD?» жіберу. */
    private fun discover(s: DatagramSocket) {
        val msg = "VRD?".toByteArray()
        val targets = ArrayList<InetAddress>()
        try {
            targets.add(InetAddress.getByName("255.255.255.255"))
            val ifs = NetworkInterface.getNetworkInterfaces()
            if (ifs != null) {
                for (ni in ifs.toList()) {
                    if (!ni.isUp || ni.isLoopback) continue
                    for (ia in ni.interfaceAddresses) {
                        val b = ia.broadcast ?: continue
                        targets.add(b)
                    }
                }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "ifaces", t)
        }
        for (t in targets) {
            try {
                s.send(DatagramPacket(msg, msg.size, t, PORT))
            } catch (e: Throwable) {
                Log.w(TAG, "discover $t", e)
            }
        }
    }

    @Synchronized
    private fun ensureSocket(): DatagramSocket? {
        socket?.let { return it }
        return try {
            val s = DatagramSocket()
            s.broadcast = true
            socket = s
            val th = Thread({ receiveLoop(s) }, "vr-remote")
            th.isDaemon = true
            th.start()
            receiver = th
            s
        } catch (t: Throwable) {
            Log.e(TAG, "socket", t)
            null
        }
    }

    private fun receiveLoop(s: DatagramSocket) {
        val buf = ByteArray(4096)
        while (!s.isClosed) {
            try {
                val p = DatagramPacket(buf, buf.size)
                s.receive(p)
                handle(p)
            } catch (t: Throwable) {
                if (s.isClosed) return
                Log.w(TAG, "receive", t)
            }
        }
    }

    private fun handle(p: DatagramPacket) {
        val d = p.data
        val len = p.length
        if (len < 4 || d[0] != 'V'.code.toByte() || d[1] != 'R'.code.toByte()) return
        val now = SystemClock.uptimeMillis()
        if (d[2] == 'D'.code.toByte() && d[3] == '!'.code.toByte()) {
            if (manualIp.isEmpty()) server = p.address
            lastReply = now
            return
        }
        if (d[2] != 'L'.code.toByte() || d[3] != '1'.code.toByte() || len < 9) return
        val bb = ByteBuffer.wrap(d, 0, len)
        val sq = bb.getInt(4)
        // Ескі (кешіккен) жауапты тастаймыз
        if (sq <= lastSeqIn && lastSeqIn - sq < 1000) return
        lastSeqIn = sq
        lastReply = now
        val lat = (now - sentAt[sq and 63]).toFloat()
        if (lat in 0f..2000f) latencyAvg = if (latencyAvg == 0f) lat else latencyAvg * 0.9f + lat * 0.1f
        val n = (d[8].toInt() and 0xff).coerceAtMost(2)
        val list = ArrayList<HandTracker.Detected>(n)
        var off = 9
        for (h in 0 until n) {
            if (off + 1 + 252 > len) break
            val label = when (d[off].toInt()) {
                0 -> "Left"
                1 -> "Right"
                else -> ""
            }
            off += 1
            val xs = FloatArray(21)
            val ys = FloatArray(21)
            val zs = FloatArray(21)
            for (i in 0 until 21) {
                xs[i] = bb.getFloat(off)
                ys[i] = bb.getFloat(off + 4)
                zs[i] = bb.getFloat(off + 8)
                off += 12
            }
            list.add(HandTracker.Detected(xs, ys, zs, label))
        }
        onHands(list, aspect)
    }

    fun close() {
        try {
            socket?.close()
        } catch (t: Throwable) {
            Log.w(TAG, "close", t)
        }
        socket = null
        server = null
    }

    companion object {
        private const val TAG = "RemoteHands"
        const val PORT = 47800
    }
}
