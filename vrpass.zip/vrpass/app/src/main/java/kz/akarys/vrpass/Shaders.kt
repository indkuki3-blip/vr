package kz.akarys.vrpass

/** OpenGL ES 2.0 шейдерлері: линза бұрмалауы, эффектілер, интерфейсті қосу. */
object Shaders {

    const val VERTEX = """
attribute vec2 aPos;
varying vec2 vUv;
void main() {
    vUv = aPos * 0.5 + 0.5;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""

    const val FRAGMENT = """#extension GL_OES_EGL_image_external : require
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vUv;
uniform samplerExternalOES uTex;
uniform samplerExternalOES uWeb;
uniform mat4 uWebMatrix;
uniform vec4 uPanel;
uniform float uWebOn;
uniform sampler2D uHud;
uniform mat4 uTexMatrix;
uniform vec2 uCrop;
uniform vec2 uTexel;
uniform float uCenter;
uniform float uAspect;
uniform float uK1;
uniform float uK2;
uniform float uRot;
uniform float uTime;
uniform int uEffect;

vec3 cam(vec2 uv) {
    return texture2D(uTex, (uTexMatrix * vec4(uv, 0.0, 1.0)).xy).rgb;
}

vec2 rotQ(vec2 v, float k) {
    if (k > 2.5) return vec2(-v.y, v.x);
    if (k > 1.5) return -v;
    if (k > 0.5) return vec2(v.y, -v.x);
    return v;
}

float luma(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

vec3 thermal(float t) {
    vec3 c0 = vec3(0.0, 0.0, 0.3);
    vec3 c1 = vec3(0.5, 0.0, 0.7);
    vec3 c2 = vec3(1.0, 0.2, 0.0);
    vec3 c3 = vec3(1.0, 0.9, 0.0);
    vec3 c4 = vec3(1.0, 1.0, 1.0);
    if (t < 0.25) return mix(c0, c1, t / 0.25);
    if (t < 0.5) return mix(c1, c2, (t - 0.25) / 0.25);
    if (t < 0.75) return mix(c2, c3, (t - 0.5) / 0.25);
    return mix(c3, c4, (t - 0.75) / 0.25);
}

float sobel(vec2 uv) {
    vec2 d = uTexel;
    float tl = luma(cam(uv + vec2(-d.x, d.y)));
    float tc = luma(cam(uv + vec2(0.0, d.y)));
    float tr = luma(cam(uv + vec2(d.x, d.y)));
    float ml = luma(cam(uv + vec2(-d.x, 0.0)));
    float mr = luma(cam(uv + vec2(d.x, 0.0)));
    float bl = luma(cam(uv + vec2(-d.x, -d.y)));
    float bc = luma(cam(uv + vec2(0.0, -d.y)));
    float br = luma(cam(uv + vec2(d.x, -d.y)));
    float gx = -tl - 2.0 * ml - bl + tr + 2.0 * mr + br;
    float gy = -tl - 2.0 * tc - tr + bl + 2.0 * bc + br;
    return sqrt(gx * gx + gy * gy);
}

vec3 applyEffect(vec2 uv, vec2 screen) {
    vec3 c = cam(uv);
    if (uEffect == 1) {
        return vec3(luma(c));
    }
    if (uEffect == 2) {
        float l = pow(clamp(luma(c) * 1.8, 0.0, 1.0), 0.8);
        float n = hash(screen * 400.0 + vec2(uTime, uTime * 1.3)) * 0.18;
        float scan = 0.92 + 0.08 * sin(screen.y * 900.0);
        float vig = clamp(1.0 - 0.6 * dot(screen, screen), 0.0, 1.0);
        return vec3(0.15, 1.0, 0.25) * (l + n) * scan * vig;
    }
    if (uEffect == 3) {
        return thermal(clamp(luma(c), 0.0, 1.0));
    }
    if (uEffect == 4) {
        float e = clamp(sobel(uv) * 2.5, 0.0, 1.0);
        vec3 neon = mix(vec3(0.0, 0.9, 1.0), vec3(1.0, 0.1, 0.9), 0.5 + 0.5 * sin(uTime + uv.y * 6.0));
        return c * 0.15 + neon * e;
    }
    if (uEffect == 5) {
        vec3 p = floor(c * 5.0 + 0.5) / 5.0;
        float e = smoothstep(0.25, 0.5, sobel(uv));
        return p * (1.0 - e);
    }
    return c;
}

void main() {
    // Көз координатасы (-1..1), центрі — линзаның центрі
    vec2 p = vUv * 2.0 - 1.0;
    p.x -= uCenter;
    vec2 q = vec2(p.x * uAspect, p.y);
    float r2 = dot(q, q);
    vec2 pd = p * (1.0 + uK1 * r2 + uK2 * r2 * r2);

    vec3 col = vec3(0.0);
    vec2 img = 0.5 + pd * 0.5 * uCrop;
    if (img.x >= 0.0 && img.x <= 1.0 && img.y >= 0.0 && img.y <= 1.0) {
        // Экран координатасын камера сенсорының координатасына бұру
        vec2 s = 0.5 + rotQ(img - 0.5, uRot);
        col = applyEffect(s, pd);
    }

    vec2 huv = pd * 0.5 + 0.5;
    // HUD координатасы, сол-жоғарыдан (интерфейс суретімен бірдей)
    vec2 tp = vec2(huv.x, 1.0 - huv.y);
    if (uWebOn > 0.5 && tp.x >= uPanel.x && tp.x <= uPanel.z && tp.y >= uPanel.y && tp.y <= uPanel.w) {
        // Веб-панель (YouTube / TikTok)
        vec2 pu = vec2((tp.x - uPanel.x) / (uPanel.z - uPanel.x),
                       1.0 - (tp.y - uPanel.y) / (uPanel.w - uPanel.y));
        col = texture2D(uWeb, (uWebMatrix * vec4(pu, 0.0, 1.0)).xy).rgb;
    }
    if (huv.x >= 0.0 && huv.x <= 1.0 && huv.y >= 0.0 && huv.y <= 1.0) {
        vec4 hud = texture2D(uHud, tp);
        col = col * (1.0 - hud.a) + hud.rgb;
    }
    // Линза шетін жұмсақ қараңғылату (ортадағы түйісу сызығы көрінбесін)
    col *= smoothstep(1.08, 0.9, length(q));
    gl_FragColor = vec4(col, 1.0);
}
"""
}
