package kz.akarys.vrpass

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.atomic.AtomicBoolean
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Стерео рендер: экранды екі көзге бөледі, әр көзде
 * камера видеосы (эффектімен) + интерфейс (HUD), линза бұрмалауымен.
 */
class VRView(
    context: Context,
    private val state: VrState,
    private val ui: VrUi,
    private val onGlReady: (SurfaceTexture) -> Unit
) : GLSurfaceView(context) {

    private val frameAvailable = AtomicBoolean(false)

    init {
        setEGLContextClientVersion(2)
        setRenderer(StereoRenderer())
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    private inner class StereoRenderer : Renderer {
        private var surfaceTexture: SurfaceTexture? = null
        private var camTex = 0
        private var hudTex = 0
        private var program = 0
        private var hud: Bitmap? = null
        private var hudCanvas: Canvas? = null
        private var viewW = 1
        private var viewH = 1
        private val texMatrix = FloatArray(16)
        private val startNs = System.nanoTime()

        private var aPos = 0
        private var uTex = 0
        private var uHud = 0
        private var uTexMatrix = 0
        private var uCrop = 0
        private var uTexel = 0
        private var uCenter = 0
        private var uAspect = 0
        private var uK1 = 0
        private var uK2 = 0
        private var uFlip = 0
        private var uTime = 0
        private var uEffect = 0

        private val quad: FloatBuffer = ByteBuffer.allocateDirect(8 * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
                put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
                position(0)
            }

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            GLES20.glClearColor(0f, 0f, 0f, 1f)
            Matrix.setIdentityM(texMatrix, 0)
            program = buildProgram(Shaders.VERTEX, Shaders.FRAGMENT)
            aPos = GLES20.glGetAttribLocation(program, "aPos")
            uTex = GLES20.glGetUniformLocation(program, "uTex")
            uHud = GLES20.glGetUniformLocation(program, "uHud")
            uTexMatrix = GLES20.glGetUniformLocation(program, "uTexMatrix")
            uCrop = GLES20.glGetUniformLocation(program, "uCrop")
            uTexel = GLES20.glGetUniformLocation(program, "uTexel")
            uCenter = GLES20.glGetUniformLocation(program, "uCenter")
            uAspect = GLES20.glGetUniformLocation(program, "uAspect")
            uK1 = GLES20.glGetUniformLocation(program, "uK1")
            uK2 = GLES20.glGetUniformLocation(program, "uK2")
            uFlip = GLES20.glGetUniformLocation(program, "uFlip")
            uTime = GLES20.glGetUniformLocation(program, "uTime")
            uEffect = GLES20.glGetUniformLocation(program, "uEffect")

            val tex = IntArray(2)
            GLES20.glGenTextures(2, tex, 0)
            camTex = tex[0]
            hudTex = tex[1]
            setupTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex)
            setupTexture(GLES20.GL_TEXTURE_2D, hudTex)
            hud = null

            val st = SurfaceTexture(camTex)
            st.setOnFrameAvailableListener { frameAvailable.set(true) }
            surfaceTexture = st
            post { onGlReady(st) }
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            viewW = width
            viewH = height
            val eyeAspect = (width / 2f) / height
            val hh = 600
            val hw = (hh * eyeAspect).toInt().coerceAtLeast(16)
            if (hud?.width != hw || hud?.height != hh) {
                val bmp = Bitmap.createBitmap(hw, hh, Bitmap.Config.ARGB_8888)
                hud = bmp
                hudCanvas = Canvas(bmp)
                GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, hudTex)
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
            }
        }

        override fun onDrawFrame(gl: GL10?) {
            val st = surfaceTexture
            if (st != null && frameAvailable.getAndSet(false)) {
                try {
                    st.updateTexImage()
                    st.getTransformMatrix(texMatrix)
                } catch (e: Exception) {
                    Log.w(TAG, "updateTexImage", e)
                }
            }

            // ---- интерфейсті салу және текстураға жүктеу
            val bmp = hud
            val cv = hudCanvas
            if (bmp != null && cv != null) {
                try {
                    ui.draw(cv, bmp.width, bmp.height)
                } catch (e: Exception) {
                    Log.e(TAG, "ui.draw", e)
                }
                GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, hudTex)
                GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, bmp)
            }

            // ---- камера кадрын көз пропорциясына қырқу
            val eyeW = viewW / 2f
            val eyeAspect = eyeW / viewH
            val camAspect = state.camW.toFloat() / state.camH
            val cropU: Float
            val cropV: Float
            if (eyeAspect < camAspect) {
                cropU = eyeAspect / camAspect
                cropV = 1f
            } else {
                cropU = 1f
                cropV = camAspect / eyeAspect
            }
            state.cropU = cropU
            state.cropV = cropV
            val zoom = state.zoom

            // ---- линза центрі: көз аралығы (мм) → пиксель → көз координатасы
            val ipdPx = state.ipdMm / 25.4f * state.xdpi
            val center = (1f - ipdPx / eyeW).coerceIn(-0.5f, 0.7f)

            val k = state.distortion
            val time = ((System.nanoTime() - startNs) / 1_000_000_000.0 % 1000.0).toFloat()

            GLES20.glViewport(0, 0, viewW, viewH)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glUseProgram(program)

            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex)
            GLES20.glUniform1i(uTex, 0)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, hudTex)
            GLES20.glUniform1i(uHud, 1)

            GLES20.glUniformMatrix4fv(uTexMatrix, 1, false, texMatrix, 0)
            GLES20.glUniform2f(uCrop, cropU / zoom, cropV / zoom)
            GLES20.glUniform2f(uTexel, 1.5f / state.camW, 1.5f / state.camH)
            GLES20.glUniform1f(uAspect, eyeAspect)
            GLES20.glUniform1f(uK1, k)
            GLES20.glUniform1f(uK2, k * 0.5f)
            GLES20.glUniform1f(uFlip, if (state.flip) 1f else 0f)
            GLES20.glUniform1f(uTime, time)
            GLES20.glUniform1i(uEffect, state.effect)

            GLES20.glEnableVertexAttribArray(aPos)
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, quad)

            val half = viewW / 2
            // Сол көз: линза центрі оңға қарай (+center)
            GLES20.glViewport(0, 0, half, viewH)
            GLES20.glUniform1f(uCenter, center)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            // Оң көз: линза центрі солға қарай (−center)
            GLES20.glViewport(half, 0, viewW - half, viewH)
            GLES20.glUniform1f(uCenter, -center)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

            GLES20.glDisableVertexAttribArray(aPos)
        }

        private fun setupTexture(target: Int, id: Int) {
            GLES20.glBindTexture(target, id)
            GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        }

        private fun buildProgram(vs: String, fs: String): Int {
            val v = compile(GLES20.GL_VERTEX_SHADER, vs)
            val f = compile(GLES20.GL_FRAGMENT_SHADER, fs)
            val p = GLES20.glCreateProgram()
            GLES20.glAttachShader(p, v)
            GLES20.glAttachShader(p, f)
            GLES20.glLinkProgram(p)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
            if (ok[0] == 0) Log.e(TAG, "link: " + GLES20.glGetProgramInfoLog(p))
            return p
        }

        private fun compile(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) Log.e(TAG, "shader: " + GLES20.glGetShaderInfoLog(s))
            return s
        }
    }

    companion object {
        private const val TAG = "VRView"
    }
}
