package kz.akarys.vrpass

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.atomic.AtomicBoolean
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLDisplay
import javax.microedition.khronos.opengles.GL10

/**
 * Стерео рендер: экранды екі көзге бөледі, әр көзде камера (эффектімен) + веб-панель + интерфейс,
 * линза бұрмалауымен. Тұрақты 30 FPS, экран 0.75 ажыратымдылықта.
 * Видео жазу: әр кадрда бір көздің суреті (16:9, бұрмалаусыз) кодерге қосымша салынады.
 */
class VRView(
    context: Context,
    private val state: VrState,
    private val ui: VrUi,
    private val onGlReady: (camera: SurfaceTexture, web: SurfaceTexture) -> Unit
) : GLSurfaceView(context) {

    private val camFrame = AtomicBoolean(false)
    private val webFrame = AtomicBoolean(false)
    private var ticking = false
    private val renderer = StereoRenderer()

    private val ticker = object : Runnable {
        override fun run() {
            if (!ticking) return
            requestRender()
            postDelayed(this, FRAME_MS)
        }
    }

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(RecordableChooser())
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    fun startTicker() {
        ticking = true
        removeCallbacks(ticker)
        post(ticker)
    }

    fun stopTicker() {
        ticking = false
        removeCallbacks(ticker)
    }

    /** Видео жазу: кодердің Surface-ін GL ағынына беру. */
    fun startRecording(target: Surface) {
        queueEvent { renderer.setRecordTarget(target) }
    }

    /** Жазуды тоқтату: GL ағыны Surface-ті босатады, сосын done (негізгі ағында). */
    fun stopRecording(done: () -> Unit) {
        queueEvent {
            renderer.setRecordTarget(null)
            post { done() }
        }
    }

    /** Келесі кадрдан скриншот (бір көздің суреті 1280×720). */
    fun takeScreenshot(cb: (Bitmap) -> Unit) {
        queueEvent { renderer.screenshotCb = cb }
    }

    /** Бейне кодерге жарайтын EGL конфигі (болмаса — кәдімгісі). */
    private class RecordableChooser : EGLConfigChooser {
        override fun chooseConfig(egl: EGL10, display: EGLDisplay): EGLConfig? {
            val base = intArrayOf(
                EGL10.EGL_RED_SIZE, 8, EGL10.EGL_GREEN_SIZE, 8, EGL10.EGL_BLUE_SIZE, 8,
                EGL10.EGL_RENDERABLE_TYPE, 4
            )
            for (recordable in booleanArrayOf(true, false)) {
                val attrs = if (recordable) base + intArrayOf(EGL_RECORDABLE_ANDROID, 1, EGL10.EGL_NONE)
                else base + intArrayOf(EGL10.EGL_NONE)
                val out = arrayOfNulls<EGLConfig>(1)
                val num = IntArray(1)
                if (egl.eglChooseConfig(display, attrs, out, 1, num) && num[0] > 0 && out[0] != null) return out[0]
            }
            return null
        }
    }

    private inner class StereoRenderer : Renderer {
        private var camST: SurfaceTexture? = null
        private var webST: SurfaceTexture? = null
        private var camTex = 0
        private var webTex = 0
        private var hudTex = 0
        private var program = 0
        private var hud: Bitmap? = null
        private var hudCanvas: Canvas? = null
        private var viewW = 1
        private var viewH = 1
        private val camMatrix = FloatArray(16)
        private val webMatrix = FloatArray(16)
        private val startNs = System.nanoTime()

        private var recTarget: Surface? = null
        private var recEgl: EGLSurface? = null
        @Volatile var screenshotCb: ((Bitmap) -> Unit)? = null
        private var fbo = 0
        private var fboTex = 0

        private var aPos = 0
        private val u = HashMap<String, Int>()

        private val quad: FloatBuffer = ByteBuffer.allocateDirect(8 * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
                put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
                position(0)
            }

        private fun loc(name: String): Int = u[name] ?: GLES20.glGetUniformLocation(program, name).also { u[name] = it }

        fun setRecordTarget(s: Surface?) {
            releaseRecEgl()
            recTarget = s
        }

        private fun releaseRecEgl() {
            val e = recEgl ?: return
            try {
                EGL14.eglDestroySurface(EGL14.eglGetCurrentDisplay(), e)
            } catch (t: Throwable) {
                Log.w(TAG, "destroy rec surface", t)
            }
            recEgl = null
        }

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            GLES20.glClearColor(0f, 0f, 0f, 1f)
            // Камера үшін тұрақты матрица: тек вертикаль аудару (бұруды шейдер жасайды)
            Matrix.setIdentityM(camMatrix, 0)
            camMatrix[5] = -1f
            camMatrix[13] = 1f
            Matrix.setIdentityM(webMatrix, 0)
            webMatrix[5] = -1f
            webMatrix[13] = 1f

            u.clear()
            program = buildProgram(Shaders.VERTEX, Shaders.FRAGMENT)
            aPos = GLES20.glGetAttribLocation(program, "aPos")

            val tex = IntArray(3)
            GLES20.glGenTextures(3, tex, 0)
            camTex = tex[0]
            webTex = tex[1]
            hudTex = tex[2]
            setupTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex)
            setupTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, webTex)
            setupTexture(GLES20.GL_TEXTURE_2D, hudTex)
            hud = null
            fbo = 0
            fboTex = 0
            recEgl = null // ескі контекстпен бірге жойылды

            val cst = SurfaceTexture(camTex)
            cst.setOnFrameAvailableListener { camFrame.set(true) }
            camST = cst
            val wst = SurfaceTexture(webTex)
            wst.setOnFrameAvailableListener { webFrame.set(true) }
            webST = wst
            post { onGlReady(cst, wst) }
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            viewW = width
            viewH = height
            val eyeAspect = (width / 2f) / height
            val hh = HUD_H
            val hw = (hh * eyeAspect).toInt().coerceAtLeast(16)
            if (hud?.width != hw || hud?.height != hh) {
                val bmp = Bitmap.createBitmap(hw, hh, Bitmap.Config.ARGB_8888)
                hud = bmp
                hudCanvas = Canvas(bmp)
                GLES20.glActiveTexture(GLES20.GL_TEXTURE2)
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, hudTex)
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
            }
        }

        override fun onDrawFrame(gl: GL10?) {
            val cst = camST
            if (cst != null && camFrame.getAndSet(false)) {
                try {
                    cst.updateTexImage()
                } catch (e: Exception) {
                    Log.w(TAG, "camera updateTexImage", e)
                }
            }
            val wst = webST
            if (wst != null && webFrame.getAndSet(false)) {
                try {
                    wst.updateTexImage()
                    wst.getTransformMatrix(webMatrix)
                } catch (e: Exception) {
                    Log.w(TAG, "web updateTexImage", e)
                }
            }

            // ---- интерфейсті салу және текстураға жүктеу
            val bmp = hud
            val cv = hudCanvas
            if (bmp != null && cv != null) {
                try {
                    ui.draw(cv, bmp.width, bmp.height)
                } catch (e: Exception) {
                    Log.e(TAG, "ui.draw", e)
                }
                GLES20.glActiveTexture(GLES20.GL_TEXTURE2)
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, hudTex)
                GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, bmp)
            }

            // ---- камера кадрын көз пропорциясына қырқу
            val eyeW = viewW / 2f
            val eyeAspect = eyeW / viewH
            val turns = state.camQuarterTurns()
            val camAspect = if (turns % 2 == 1) state.camH.toFloat() / state.camW
            else state.camW.toFloat() / state.camH
            val cropU: Float
            val cropV: Float
            if (eyeAspect < camAspect) {
                cropU = eyeAspect / camAspect
                cropV = 1f
            } else {
                cropU = 1f
                cropV = camAspect / eyeAspect
            }
            state.cropU = cropU
            state.cropV = cropV
            val zoom = state.zoom

            // ---- линза центрі: көз аралығы (мм) → физикалық пиксель → көз координатасы
            val ipdPx = state.ipdMm / 25.4f * state.xdpi
            val physHalf = if (state.screenW > 0) state.screenW / 2f else eyeW
            val center = (1f - ipdPx / physHalf).coerceIn(-0.5f, 0.7f)
            val k = state.distortion

            setupCommon(turns)

            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            GLES20.glViewport(0, 0, viewW, viewH)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glUniform2f(loc("uCrop"), cropU / zoom, cropV / zoom)
            GLES20.glUniform2f(loc("uHudScale"), 1f, 1f)
            GLES20.glUniform1f(loc("uVignette"), 1f)
            GLES20.glUniform1f(loc("uAspect"), eyeAspect)
            GLES20.glUniform1f(loc("uK1"), k)
            GLES20.glUniform1f(loc("uK2"), k * 0.5f)

            val half = viewW / 2
            // Сол көз: линза центрі оңға қарай (+center)
            GLES20.glViewport(0, 0, half, viewH)
            GLES20.glUniform1f(loc("uCenter"), center)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            // Оң көз: линза центрі солға қарай (−center)
            GLES20.glViewport(half, 0, viewW - half, viewH)
            GLES20.glUniform1f(loc("uCenter"), -center)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

            // ---- видео жазу / скриншот: бір көз, 16:9, бұрмалаусыз
            if (recTarget != null) drawToRecorder(cropU, cropV, zoom, eyeAspect)
            val cb = screenshotCb
            if (cb != null) {
                screenshotCb = null
                val shot = drawToBitmap(cropU, cropV, zoom, eyeAspect)
                if (shot != null) post { cb(shot) }
            }

            GLES20.glDisableVertexAttribArray(aPos)
        }

        private fun setupCommon(turns: Int) {
            val time = ((System.nanoTime() - startNs) / 1_000_000_000.0 % 1000.0).toFloat()
            GLES20.glUseProgram(program)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex)
            GLES20.glUniform1i(loc("uTex"), 0)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, webTex)
            GLES20.glUniform1i(loc("uWeb"), 1)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE2)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, hudTex)
            GLES20.glUniform1i(loc("uHud"), 2)
            GLES20.glUniformMatrix4fv(loc("uTexMatrix"), 1, false, camMatrix, 0)
            GLES20.glUniformMatrix4fv(loc("uWebMatrix"), 1, false, webMatrix, 0)
            GLES20.glUniform4f(loc("uPanel"), state.panelL, state.panelT, state.panelR, state.panelB)
            GLES20.glUniform1f(loc("uWebOn"), if (state.webOn) 1f else 0f)
            GLES20.glUniform2f(loc("uTexel"), 1.5f / state.camW, 1.5f / state.camH)
            GLES20.glUniform1f(loc("uRot"), turns.toFloat())
            GLES20.glUniform1f(loc("uTime"), time)
            GLES20.glUniform1i(loc("uEffect"), state.effect)
            GLES20.glEnableVertexAttribArray(aPos)
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, quad)
        }

        /** Бір көздің суреті, 16:9: камера кеңірек көрінеді, интерфейс ортада сол пропорциямен. */
        private fun drawMono(w: Int, h: Int, cropU: Float, cropV: Float, zoom: Float, eyeAspect: Float) {
            val va = w.toFloat() / h
            val s = va / eyeAspect
            GLES20.glViewport(0, 0, w, h)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glUniform2f(loc("uCrop"), cropU * s / zoom, cropV / zoom)
            GLES20.glUniform2f(loc("uHudScale"), s, 1f)
            GLES20.glUniform1f(loc("uVignette"), 0f)
            GLES20.glUniform1f(loc("uAspect"), va)
            GLES20.glUniform1f(loc("uK1"), 0f)
            GLES20.glUniform1f(loc("uK2"), 0f)
            GLES20.glUniform1f(loc("uCenter"), 0f)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        }

        private fun drawToRecorder(cropU: Float, cropV: Float, zoom: Float, eyeAspect: Float) {
            val target = recTarget ?: return
            try {
                val dpy = EGL14.eglGetCurrentDisplay()
                val ctx = EGL14.eglGetCurrentContext()
                if (recEgl == null) {
                    val id = IntArray(1)
                    EGL14.eglQueryContext(dpy, ctx, EGL14.EGL_CONFIG_ID, id, 0)
                    val cfgs = arrayOfNulls<android.opengl.EGLConfig>(1)
                    val num = IntArray(1)
                    EGL14.eglChooseConfig(dpy, intArrayOf(EGL14.EGL_CONFIG_ID, id[0], EGL14.EGL_NONE), 0, cfgs, 0, 1, num, 0)
                    val surf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], target, intArrayOf(EGL14.EGL_NONE), 0)
                    if (surf == null || surf == EGL14.EGL_NO_SURFACE) {
                        Log.e(TAG, "rec surface failed")
                        recTarget = null
                        state.notice = "Жазу бұл телефонда істемеді"
                        return
                    }
                    recEgl = surf
                }
                val rs = recEgl ?: return
                val draw = EGL14.eglGetCurrentSurface(EGL14.EGL_DRAW)
                val read = EGL14.eglGetCurrentSurface(EGL14.EGL_READ)
                EGL14.eglMakeCurrent(dpy, rs, rs, ctx)
                drawMono(Recorder.W, Recorder.H, cropU, cropV, zoom, eyeAspect)
                EGLExt.eglPresentationTimeANDROID(dpy, rs, System.nanoTime())
                EGL14.eglSwapBuffers(dpy, rs)
                EGL14.eglMakeCurrent(dpy, draw, read, ctx)
            } catch (t: Throwable) {
                Log.e(TAG, "record frame", t)
            }
        }

        private fun drawToBitmap(cropU: Float, cropV: Float, zoom: Float, eyeAspect: Float): Bitmap? {
            return try {
                val w = Recorder.W
                val h = Recorder.H
                if (fbo == 0) {
                    val t = IntArray(1)
                    GLES20.glGenTextures(1, t, 0)
                    fboTex = t[0]
                    GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, fboTex)
                    GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
                    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
                    val f = IntArray(1)
                    GLES20.glGenFramebuffers(1, f, 0)
                    fbo = f[0]
                    GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo)
                    GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, fboTex, 0)
                    // HUD текстурасын қайта байлау (жоғарыда текстура ауысты)
                    GLES20.glActiveTexture(GLES20.GL_TEXTURE2)
                    GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, hudTex)
                }
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo)
                drawMono(w, h, cropU, cropV, zoom, eyeAspect)
                val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
                GLES20.glReadPixels(0, 0, w, h, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
                val raw = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                buf.rewind()
                raw.copyPixelsFromBuffer(buf)
                val m = android.graphics.Matrix()
                m.preScale(1f, -1f)
                Bitmap.createBitmap(raw, 0, 0, w, h, m, false)
            } catch (t: Throwable) {
                Log.e(TAG, "screenshot", t)
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
                null
            }
        }

        private fun setupTexture(target: Int, id: Int) {
            GLES20.glBindTexture(target, id)
            GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        }

        private fun buildProgram(vs: String, fs: String): Int {
            val v = compile(GLES20.GL_VERTEX_SHADER, vs)
            val f = compile(GLES20.GL_FRAGMENT_SHADER, fs)
            val p = GLES20.glCreateProgram()
            GLES20.glAttachShader(p, v)
            GLES20.glAttachShader(p, f)
            GLES20.glLinkProgram(p)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
            if (ok[0] == 0) Log.e(TAG, "link: " + GLES20.glGetProgramInfoLog(p))
            return p
        }

        private fun compile(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) Log.e(TAG, "shader: " + GLES20.glGetShaderInfoLog(s))
            return s
        }
    }

    companion object {
        private const val TAG = "VRView"
        private const val FRAME_MS = 33L
        private const val HUD_H = 540
        private const val EGL_RECORDABLE_ANDROID = 0x3142
    }
}
