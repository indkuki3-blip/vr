package kz.akarys.vrpass

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import java.util.concurrent.atomic.AtomicBoolean
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLDisplay
import javax.microedition.khronos.opengles.GL10

/**
 * Стерео рендер: экранды екі көзге бөледі, әр көзде камера (эффектімен) + веб-панель + интерфейс,
 * линза бұрмалауымен. Тұрақты 30 FPS, экран 0.75 ажыратымдылықта.
 * Видео жазу: әр кадрда бір көздің суреті (16:9, бұрмалаусыз) кодерге қосымша салынады.
 */
class VRView(
    context: Context,
    private val state: VrState,
    private val ui: VrUi,
    private val onGlReady: (camera: SurfaceTexture, web: SurfaceTexture) -> Unit
) : GLSurfaceView(context) {

    private val camFrame = AtomicBoolean(false)
    private val webFrame = AtomicBoolean(false)
    private var ticking = false
    private val renderer = StereoRenderer()

    private val ticker = object : Runnable {
        override fun run() {
            if (!ticking) return
            requestRender()
            postDelayed(this, FRAME_MS)
        }
    }

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(RecordableChooser())
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    fun startTicker() {
        ticking = true
        removeCallbacks(ticker)
        post(ticker)
    }

    fun stopTicker() {
        ticking = false
        removeCallbacks(ticker)
    }

    /** Видео жазу: кодердің Surface-ін GL ағынына беру. */
    fun startRecording(target: Surface) {
        queueEvent { renderer.setRecordTarget(target) }
    }

    /** Жазуды тоқтату: GL ағыны Surface-ті босатады, сосын done (негізгі ағында). */
    fun stopRecording(done: () -> Unit) {
        queueEvent {
            renderer.setRecordTarget(null)
            post { done() }
        }
    }

    /** Келесі кадрдан скриншот (бір көздің суреті 1280×720). */
    fun takeScreenshot(cb: (Bitmap) -> Unit) {
        queueEvent { renderer.screenshotCb = cb }
    }

    /** Бейне кодерге жарайтын EGL конфигі (болмаса — кәдімгісі). */
    private class RecordableChooser : EGLConfigChooser {
        override fun chooseConfig(egl: EGL10, display: EGLDisplay): EGLConfig? {
            val base = intArrayOf(
                EGL10.EGL_RED_SIZE, 8, EGL10.EGL_GREEN_SIZE, 8, EGL10.EGL_BLUE_SIZE, 8,
                EGL10.EGL_RENDERABLE_TYPE, 4
            )
            for (recordable in booleanArrayOf(true, false)) {
                val attrs = if (recordable) base + intArrayOf(EGL_RECORDABLE_ANDROID, 1, EGL10.EGL_NONE)
                else base + intArrayOf(EGL10.EGL_NONE)
                val out = arrayOfNulls<EGLConfig>(1)
                val num = IntArray(1)
                if (egl.eglChooseConfig(display, attrs, out, 1, num) && num[0] > 0 && out[0] != null) return out[0]
            }
            return null
        }
    }

    private inner class StereoRenderer : Renderer {
        private var camST: SurfaceTexture? = null
        private var webST: SurfaceTexture? = null
        private var camTex = 0
        private var webTex = 0
        private var hudTex = 0
        private var hud: Bitmap? = null
        private var hudCanvas: Canvas? = null
        private var viewW = 1
        private var viewH = 1
        private val camMatrix = FloatArray(16)
        private val webMatrix = FloatArray(16)
        private val startNs = System.nanoTime()

        private var recTarget: Surface? = null
        private var recEgl: EGLSurface? = null
        @Volatile var screenshotCb: ((Bitmap) -> Unit)? = null
        private var fbo = 0
        private var fboTex = 0

        /** Әр эффектінің жеке шейдер бағдарламасы (бірінші таңдалғанда жиналады). */
        private inner class Prog(val id: Int) {
            val aPos = GLES20.glGetAttribLocation(id, "aPos")
            val aPd = GLES20.glGetAttribLocation(id, "aPd")
            val aQ = GLES20.glGetAttribLocation(id, "aQ")
            val u = HashMap<String, Int>()
        }

        private val programs = HashMap<Int, Prog>()
        private var cur: Prog? = null

        // ---- Линза торы: әр көзге алдын ала есептелген бұрмалау (x, y, pdx, pdy, q)
        private val meshL: FloatBuffer = ByteBuffer.allocateDirect(MESH_V * 5 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        private val meshR: FloatBuffer = ByteBuffer.allocateDirect(MESH_V * 5 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        private val meshMono: FloatBuffer = ByteBuffer.allocateDirect(MESH_V * 5 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        private val indices: ShortBuffer = buildIndices()
        private var meshKey = ""
        private var monoBuilt = false

        // ---- FPS
        private var fpsFrames = 0
        private var fpsStart = 0L
        private var workNs = 0L

        private fun loc(name: String): Int {
            val p = cur ?: return -1
            return p.u[name] ?: GLES20.glGetUniformLocation(p.id, name).also { p.u[name] = it }
        }

        private fun buildIndices(): ShortBuffer {
            val n = MESH_N
            val arr = ShortArray(n * n * 6)
            var k = 0
            for (j in 0 until n) for (i in 0 until n) {
                val a = (j * (n + 1) + i).toShort()
                val b = (j * (n + 1) + i + 1).toShort()
                val c = ((j + 1) * (n + 1) + i).toShort()
                val d = ((j + 1) * (n + 1) + i + 1).toShort()
                arr[k++] = a; arr[k++] = b; arr[k++] = c
                arr[k++] = b; arr[k++] = d; arr[k++] = c
            }
            val sb = ByteBuffer.allocateDirect(arr.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
            sb.put(arr)
            sb.position(0)
            return sb
        }

        /** Бір көздің торы: экран нүктесі p → бұрмаланған pd (линза центрі мен күшіне қарай). */
        private fun fillMesh(buf: FloatBuffer, center: Float, k1: Float, k2: Float, aspect: Float) {
            buf.position(0)
            val n = MESH_N
            for (j in 0..n) for (i in 0..n) {
                val x = -1f + 2f * i / n
                val y = -1f + 2f * j / n
                val px = x - center
                val qx = px * aspect
                val r2 = qx * qx + y * y
                val f = 1f + k1 * r2 + k2 * r2 * r2
                buf.put(x)
                buf.put(y)
                buf.put(px * f)
                buf.put(y * f)
                buf.put(kotlin.math.sqrt(r2))
            }
            buf.position(0)
        }

        private fun useProgram(effect: Int) {
            val p = programs[effect] ?: Prog(buildProgram(Shaders.VERTEX, Shaders.fragment(effect))).also { programs[effect] = it }
            cur = p
            GLES20.glUseProgram(p.id)
        }

        private fun drawMesh(buf: FloatBuffer) {
            val p = cur ?: return
            buf.position(0)
            GLES20.glVertexAttribPointer(p.aPos, 2, GLES20.GL_FLOAT, false, 20, buf)
            GLES20.glEnableVertexAttribArray(p.aPos)
            buf.position(2)
            GLES20.glVertexAttribPointer(p.aPd, 2, GLES20.GL_FLOAT, false, 20, buf)
            GLES20.glEnableVertexAttribArray(p.aPd)
            if (p.aQ >= 0) {
                buf.position(4)
                GLES20.glVertexAttribPointer(p.aQ, 1, GLES20.GL_FLOAT, false, 20, buf)
                GLES20.glEnableVertexAttribArray(p.aQ)
            }
            indices.position(0)
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, MESH_N * MESH_N * 6, GLES20.GL_UNSIGNED_SHORT, indices)
        }

        fun setRecordTarget(s: Surface?) {
            releaseRecEgl()
            recTarget = s
        }

        private fun releaseRecEgl() {
            val e = recEgl ?: return
            try {
                EGL14.eglDestroySurface(EGL14.eglGetCurrentDisplay(), e)
            } catch (t: Throwable) {
                Log.w(TAG, "destroy rec surface", t)
            }
            recEgl = null
        }

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            GLES20.glClearColor(0f, 0f, 0f, 1f)
            // Камера үшін тұрақты матрица: тек вертикаль аудару (бұруды шейдер жасайды)
            Matrix.setIdentityM(camMatrix, 0)
            camMatrix[5] = -1f
            camMatrix[13] = 1f
            Matrix.setIdentityM(webMatrix, 0)
            webMatrix[5] = -1f
            webMatrix[13] = 1f

            programs.clear()
            cur = null
            meshKey = ""
            try {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DISPLAY)
            } catch (t: Throwable) {
                Log.w(TAG, "priority", t)
            }

            val tex = IntArray(3)
            GLES20.glGenTextures(3, tex, 0)
            camTex = tex[0]
            webTex = tex[1]
            hudTex = tex[2]
            setupTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex)
            setupTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, webTex)
            setupTexture(GLES20.GL_TEXTURE_2D, hudTex)
            hud = null
            fbo = 0
            fboTex = 0
            recEgl = null // ескі контекстпен бірге жойылды

            val cst = SurfaceTexture(camTex)
            cst.setOnFrameAvailableListener { camFrame.set(true) }
            camST = cst
            val wst = SurfaceTexture(webTex)
            wst.setOnFrameAvailableListener { webFrame.set(true) }
            webST = wst
            post { onGlReady(cst, wst) }
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            viewW = width
            viewH = height
            val eyeAspect = (width / 2f) / height
            val hh = HUD_H
            val hw = (hh * eyeAspect).toInt().coerceAtLeast(16)
            if (hud?.width != hw || hud?.height != hh) {
                val bmp = Bitmap.createBitmap(hw, hh, Bitmap.Config.ARGB_8888)
                hud = bmp
                hudCanvas = Canvas(bmp)
                GLES20.glActiveTexture(GLES20.GL_TEXTURE2)
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, hudTex)
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
            }
        }

        override fun onDrawFrame(gl: GL10?) {
            val cst = camST
            if (cst != null && camFrame.getAndSet(false)) {
                try {
                    cst.updateTexImage()
                } catch (e: Exception) {
                    Log.w(TAG, "camera updateTexImage", e)
                }
            }
            val wst = webST
            if (wst != null && webFrame.getAndSet(false)) {
                try {
                    wst.updateTexImage()
                    wst.getTransformMatrix(webMatrix)
                } catch (e: Exception) {
                    Log.w(TAG, "web updateTexImage", e)
                }
            }

            // ---- интерфейсті салу және текстураға жүктеу
            val t0 = System.nanoTime()
            val bmp = hud
            val cv = hudCanvas
            if (bmp != null && cv != null) {
                val changed = try {
                    ui.draw(cv, bmp.width, bmp.height)
                } catch (e: Exception) {
                    Log.e(TAG, "ui.draw", e)
                    true
                }
                // Интерфейс өзгермесе — текстураны қайта жүктемейміз (ең қымбат операциялардың бірі)
                if (changed) {
                    GLES20.glActiveTexture(GLES20.GL_TEXTURE2)
                    GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, hudTex)
                    GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, bmp)
                }
            }

            // ---- камера кадрын көз пропорциясына қырқу
            val eyeW = viewW / 2f
            val eyeAspect = eyeW / viewH
            val turns = state.camQuarterTurns()
            val camAspect = if (turns % 2 == 1) state.camH.toFloat() / state.camW
            else state.camW.toFloat() / state.camH
            val cropU: Float
            val cropV: Float
            if (eyeAspect < camAspect) {
                cropU = eyeAspect / camAspect
                cropV = 1f
            } else {
                cropU = 1f
                cropV = camAspect / eyeAspect
            }
            state.cropU = cropU
            state.cropV = cropV
            val zoom = state.zoom

            // ---- линза центрі: көз аралығы (мм) → физикалық пиксель → көз координатасы
            val ipdPx = state.ipdMm / 25.4f * state.xdpi
            val physHalf = if (state.screenW > 0) state.screenW / 2f else eyeW
            val center = (1f - ipdPx / physHalf).coerceIn(-0.5f, 0.7f)
            val k = state.distortion

            // Тор параметрлері өзгерсе ғана қайта есептейміз
            val key = "$center|$k|$eyeAspect"
            if (key != meshKey) {
                meshKey = key
                fillMesh(meshL, center, k, k * 0.5f, eyeAspect)
                fillMesh(meshR, -center, k, k * 0.5f, eyeAspect)
            }

            setupCommon(turns)

            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            GLES20.glViewport(0, 0, viewW, viewH)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glUniform2f(loc("uCrop"), cropU / zoom, cropV / zoom)
            GLES20.glUniform2f(loc("uHudScale"), 1f, 1f)
            GLES20.glUniform1f(loc("uVignette"), 1f)

            val half = viewW / 2
            GLES20.glViewport(0, 0, half, viewH)
            drawMesh(meshL)
            GLES20.glViewport(half, 0, viewW - half, viewH)
            drawMesh(meshR)

            // ---- видео жазу / скриншот: бір көз, 16:9, бұрмалаусыз
            if (recTarget != null) drawToRecorder(cropU, cropV, zoom, eyeAspect)
            val cb = screenshotCb
            if (cb != null) {
                screenshotCb = null
                val shot = drawToBitmap(cropU, cropV, zoom, eyeAspect)
                if (shot != null) post { cb(shot) }
            }

            // ---- FPS өлшеу
            workNs += System.nanoTime() - t0
            fpsFrames++
            val nowMs = android.os.SystemClock.uptimeMillis()
            if (fpsStart == 0L) fpsStart = nowMs
            if (nowMs - fpsStart >= 1000L) {
                state.fps = fpsFrames * 1000f / (nowMs - fpsStart)
                state.frameMs = workNs / 1_000_000f / fpsFrames
                fpsFrames = 0
                workNs = 0L
                fpsStart = nowMs
            }
        }

        private fun setupCommon(turns: Int) {
            val time = ((System.nanoTime() - startNs) / 1_000_000_000.0 % 1000.0).toFloat()
            useProgram(state.effect)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex)
            GLES20.glUniform1i(loc("uTex"), 0)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, webTex)
            GLES20.glUniform1i(loc("uWeb"), 1)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE2)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, hudTex)
            GLES20.glUniform1i(loc("uHud"), 2)
            GLES20.glUniformMatrix4fv(loc("uTexMatrix"), 1, false, camMatrix, 0)
            GLES20.glUniformMatrix4fv(loc("uWebMatrix"), 1, false, webMatrix, 0)
            GLES20.glUniform4f(loc("uPanel"), state.panelL, state.panelT, state.panelR, state.panelB)
            GLES20.glUniform1f(loc("uWebOn"), if (state.webOn) 1f else 0f)
            GLES20.glUniform2f(loc("uTexel"), 1.5f / state.camW, 1.5f / state.camH)
            GLES20.glUniform1f(loc("uRot"), turns.toFloat())
            GLES20.glUniform1f(loc("uTime"), time)
        }

        /** Бір көздің суреті, 16:9: камера кеңірек көрінеді, интерфейс ортада сол пропорциямен. */
        private fun drawMono(w: Int, h: Int, cropU: Float, cropV: Float, zoom: Float, eyeAspect: Float) {
            val va = w.toFloat() / h
            val s = va / eyeAspect
            GLES20.glViewport(0, 0, w, h)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glUniform2f(loc("uCrop"), cropU * s / zoom, cropV / zoom)
            GLES20.glUniform2f(loc("uHudScale"), s, 1f)
            GLES20.glUniform1f(loc("uVignette"), 0f)
            if (!monoBuilt) {
                monoBuilt = true
                fillMesh(meshMono, 0f, 0f, 0f, 1f)
            }
            drawMesh(meshMono)
        }

        private fun drawToRecorder(cropU: Float, cropV: Float, zoom: Float, eyeAspect: Float) {
            val target = recTarget ?: return
            try {
                val dpy = EGL14.eglGetCurrentDisplay()
                val ctx = EGL14.eglGetCurrentContext()
                if (recEgl == null) {
                    val id = IntArray(1)
                    EGL14.eglQueryContext(dpy, ctx, EGL14.EGL_CONFIG_ID, id, 0)
                    val cfgs = arrayOfNulls<android.opengl.EGLConfig>(1)
                    val num = IntArray(1)
                    EGL14.eglChooseConfig(dpy, intArrayOf(EGL14.EGL_CONFIG_ID, id[0], EGL14.EGL_NONE), 0, cfgs, 0, 1, num, 0)
                    val surf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], target, intArrayOf(EGL14.EGL_NONE), 0)
                    if (surf == null || surf == EGL14.EGL_NO_SURFACE) {
                        Log.e(TAG, "rec surface failed")
                        recTarget = null
                        state.notice = "Жазу бұл телефонда істемеді"
                        return
                    }
                    recEgl = surf
                }
                val rs = recEgl ?: return
                val draw = EGL14.eglGetCurrentSurface(EGL14.EGL_DRAW)
                val read = EGL14.eglGetCurrentSurface(EGL14.EGL_READ)
                EGL14.eglMakeCurrent(dpy, rs, rs, ctx)
                drawMono(Recorder.W, Recorder.H, cropU, cropV, zoom, eyeAspect)
                EGLExt.eglPresentationTimeANDROID(dpy, rs, System.nanoTime())
                EGL14.eglSwapBuffers(dpy, rs)
                EGL14.eglMakeCurrent(dpy, draw, read, ctx)
            } catch (t: Throwable) {
                Log.e(TAG, "record frame", t)
            }
        }

        private fun drawToBitmap(cropU: Float, cropV: Float, zoom: Float, eyeAspect: Float): Bitmap? {
            return try {
                val w = SHOT_W
                val h = SHOT_H
                if (fbo == 0) {
                    val t = IntArray(1)
                    GLES20.glGenTextures(1, t, 0)
                    fboTex = t[0]
                    GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, fboTex)
                    GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
                    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
                    val f = IntArray(1)
                    GLES20.glGenFramebuffers(1, f, 0)
                    fbo = f[0]
                    GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo)
                    GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, fboTex, 0)
                    // HUD текстурасын қайта байлау (жоғарыда текстура ауысты)
                    GLES20.glActiveTexture(GLES20.GL_TEXTURE2)
                    GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, hudTex)
                }
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo)
                drawMono(w, h, cropU, cropV, zoom, eyeAspect)
                val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
                GLES20.glReadPixels(0, 0, w, h, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
                val raw = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                buf.rewind()
                raw.copyPixelsFromBuffer(buf)
                val m = android.graphics.Matrix()
                m.preScale(1f, -1f)
                Bitmap.createBitmap(raw, 0, 0, w, h, m, false)
            } catch (t: Throwable) {
                Log.e(TAG, "screenshot", t)
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
                null
            }
        }

        private fun setupTexture(target: Int, id: Int) {
            GLES20.glBindTexture(target, id)
            GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        }

        private fun buildProgram(vs: String, fs: String): Int {
            val v = compile(GLES20.GL_VERTEX_SHADER, vs)
            val f = compile(GLES20.GL_FRAGMENT_SHADER, fs)
            val p = GLES20.glCreateProgram()
            GLES20.glAttachShader(p, v)
            GLES20.glAttachShader(p, f)
            GLES20.glLinkProgram(p)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
            if (ok[0] == 0) Log.e(TAG, "link: " + GLES20.glGetProgramInfoLog(p))
            return p
        }

        private fun compile(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) Log.e(TAG, "shader: " + GLES20.glGetShaderInfoLog(s))
            return s
        }
    }

    companion object {
        private const val TAG = "VRView"
        private const val FRAME_MS = 33L
        private const val HUD_H = 540
        private const val EGL_RECORDABLE_ANDROID = 0x3142
        private const val MESH_N = 32
        private const val SHOT_W = 1280
        private const val SHOT_H = 720
        private const val MESH_V = (MESH_N + 1) * (MESH_N + 1)
    }
}
