package kz.akarys.vrpass

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Қорқынышты ойын (AR): бөлме қараңғы, қолың — қол шам. Қараңғыдан аруақтар жақындайды.
 * Аруақты жарықпен 1 секунд ұстасаң — жоғалады. Жақындап жетсе — ... (скример).
 */
class HorrorGame(private val sfx: Sfx) : MiniGame {

    private class Ghost(var x: Float, var y: Float, var size: Float, var lit: Float, var fade: Float, val phase: Float)

    override val id = "horror"
    override val title = "Қорқынышты"
    override var score = 0
        private set
    override var finished = false
        private set

    private val ghosts = ArrayList<Ghost>()
    private val torches = ArrayList<FloatArray>()
    private var startT = 0L
    private var lastT = 0L
    private var nextSpawn = 0L
    private var lastBeat = 0L
    private var scareT = 0L
    private var flicker = 1f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hole = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    }
    private val path = Path()
    private val oval = RectF()

    override fun start(now: Long) {
        ghosts.clear()
        score = 0
        finished = false
        startT = now
        lastT = now
        nextSpawn = now + 1500L
        lastBeat = now
        scareT = 0L
    }

    override fun update(now: Long, hands: List<EyeHand>, aspect: Float) {
        val dt = min(0.05f, (now - lastT) / 1000f)
        lastT = now
        if (finished) return
        if (scareT > 0L) {
            if (now - scareT > 1800L) finished = true
            return
        }
        val elapsed = (now - startT) / 1000f

        // Шам жыпылықтайды
        flicker = if (Random.nextFloat() < 0.03f) 0.55f else 0.92f + 0.08f * sin(now * 0.02f)

        torches.clear()
        for (hd in hands) torches.add(floatArrayOf(hd.x(9) * 0.4f + hd.cx * 0.6f, hd.y(9) * 0.4f + hd.cy * 0.6f))
        val radius = TORCH_R * flicker

        val maxGhosts = min(4, 1 + (elapsed / 18f).toInt())
        if (ghosts.size < maxGhosts && now >= nextSpawn) {
            ghosts.add(Ghost(0.15f + Random.nextFloat() * 0.7f, 0.25f + Random.nextFloat() * 0.45f, 0.05f, 0f, -1f, Random.nextFloat() * 6.28f))
            nextSpawn = now + max(1200L, 4000L - (elapsed * 40f).toLong())
        }

        var biggest = 0f
        val it = ghosts.iterator()
        while (it.hasNext()) {
            val g = it.next()
            if (g.fade >= 0f) {
                g.fade += dt
                if (g.fade > 0.7f) it.remove()
                continue
            }
            var inLight = false
            for (t in torches) {
                if (hypot((g.x - t[0]) * aspect, g.y - t[1]) < radius + g.size * 0.4f) {
                    inLight = true
                    break
                }
            }
            if (inLight) {
                g.lit += dt
                g.size = max(0.04f, g.size - dt * 0.012f)
                if (g.lit > 1.0f) {
                    g.fade = 0f
                    score++
                    sfx.play("ding", 0.6f, 0.6f)
                }
            } else {
                g.lit = max(0f, g.lit - dt * 0.5f)
                g.size += dt * (0.011f + elapsed * 0.0003f)
                g.x += (0.5f - g.x) * dt * 0.05f + sin(elapsed * 1.5f + g.phase) * dt * 0.03f
            }
            biggest = max(biggest, g.size)
            if (g.size > 0.30f) {
                scareT = now
                sfx.play("scream", 1f)
                sfx.vibrate(900)
                return
            }
        }

        // Жүрек соғысы: аруақ жақындаған сайын жиілейді
        val interval = (1400f - biggest / 0.30f * 1050f).toLong().coerceAtLeast(330L)
        if (now - lastBeat > interval) {
            lastBeat = now
            sfx.play("beat", 0.35f + biggest * 2f)
        }
    }

    override fun draw(c: Canvas, w: Int, h: Int, now: Long) {
        val fw = w.toFloat()
        val fh = h.toFloat()

        if (scareT > 0L) {
            drawScare(c, fw, fh)
            return
        }

        // Аруақтар (қараңғылық астында — тек жарықта көрінеді)
        for (g in ghosts) drawGhost(c, g, fw, fh, now)

        // Қараңғылық + шамдардың жарығы
        c.saveLayer(0f, 0f, fw, fh, null)
        c.drawColor(Color.argb(250, 0, 0, 0))
        val r = TORCH_R * flicker * fh * 1.25f
        for (t in torches) {
            val x = t[0] * fw
            val y = t[1] * fh
            hole.shader = RadialGradient(
                x, y, r,
                intArrayOf(Color.argb(255, 0, 0, 0), Color.argb(230, 0, 0, 0), Color.argb(0, 0, 0, 0)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
            c.drawCircle(x, y, r, hole)
        }
        c.restore()

        // Қараңғыда жылтыраған көздер
        for (g in ghosts) {
            if (g.fade >= 0f) continue
            val x = g.x * fw
            val y = g.y * fh
            val s = g.size * fh
            fill.color = Color.argb(90, 255, 40, 40)
            c.drawCircle(x - s * 0.18f, y - s * 0.15f, s * 0.05f, fill)
            c.drawCircle(x + s * 0.18f, y - s * 0.15f, s * 0.05f, fill)
        }

        GameText.draw(c, "Қуылды: $score", fw * 0.5f, fh * 0.12f, fh * 0.036f, Color.rgb(150, 150, 160))
        if (torches.isEmpty()) {
            GameText.draw(c, "Қолыңды көрсет — ол шам болады…", fw * 0.5f, fh * 0.9f, fh * 0.034f, Color.rgb(180, 60, 60))
        }
    }

    private fun drawGhost(c: Canvas, g: Ghost, fw: Float, fh: Float, now: Long) {
        val x = g.x * fw
        val y = g.y * fh + sin(now * 0.003f + g.phase) * fh * 0.01f
        val s = g.size * fh
        val alpha = if (g.fade >= 0f) (1f - g.fade / 0.7f).coerceIn(0f, 1f) else 1f
        // Дене
        path.reset()
        path.moveTo(x - s * 0.45f, y + s * 0.6f)
        path.lineTo(x - s * 0.45f, y - s * 0.1f)
        oval.set(x - s * 0.45f, y - s * 0.55f, x + s * 0.45f, y + s * 0.35f)
        path.arcTo(oval, 180f, 180f)
        path.lineTo(x + s * 0.45f, y + s * 0.6f)
        val waves = 5
        for (i in 0 until waves) {
            val x1 = x + s * 0.45f - (i + 0.5f) * s * 0.9f / waves
            val x2 = x + s * 0.45f - (i + 1) * s * 0.9f / waves
            val dy = if (i % 2 == 0) s * 0.12f else -s * 0.04f
            path.quadTo(x1, y + s * 0.6f + dy, x2, y + s * 0.6f)
        }
        path.close()
        fill.color = Color.argb((215 * alpha).toInt(), 220, 228, 240)
        c.drawPath(path, fill)
        // Көздер мен ауыз
        fill.color = Color.argb((255 * alpha).toInt(), 10, 10, 14)
        oval.set(x - s * 0.28f, y - s * 0.3f, x - s * 0.08f, y - s * 0.02f)
        c.drawOval(oval, fill)
        oval.set(x + s * 0.08f, y - s * 0.3f, x + s * 0.28f, y - s * 0.02f)
        c.drawOval(oval, fill)
        oval.set(x - s * 0.1f, y + s * 0.08f, x + s * 0.1f, y + s * 0.32f)
        c.drawOval(oval, fill)
    }

    private fun drawScare(c: Canvas, fw: Float, fh: Float) {
        val shake = fh * 0.02f
        c.save()
        c.translate((Random.nextFloat() - 0.5f) * shake * 2f, (Random.nextFloat() - 0.5f) * shake * 2f)
        fill.color = Color.rgb(40, 0, 0)
        c.drawRect(-shake, -shake, fw + shake, fh + shake, fill)
        val cx = fw * 0.5f
        val cy = fh * 0.5f
        val s = fh * 0.95f
        // Бет
        fill.color = Color.rgb(205, 200, 190)
        oval.set(cx - s * 0.36f, cy - s * 0.5f, cx + s * 0.36f, cy + s * 0.5f)
        c.drawOval(oval, fill)
        // Көздер
        fill.color = Color.BLACK
        oval.set(cx - s * 0.27f, cy - s * 0.25f, cx - s * 0.06f, cy - s * 0.02f)
        c.drawOval(oval, fill)
        oval.set(cx + s * 0.06f, cy - s * 0.25f, cx + s * 0.27f, cy - s * 0.02f)
        c.drawOval(oval, fill)
        fill.color = Color.rgb(255, 20, 20)
        c.drawCircle(cx - s * 0.165f, cy - s * 0.13f, s * 0.025f, fill)
        c.drawCircle(cx + s * 0.165f, cy - s * 0.13f, s * 0.025f, fill)
        // Ауыз
        fill.color = Color.BLACK
        oval.set(cx - s * 0.14f, cy + s * 0.08f, cx + s * 0.14f, cy + s * 0.45f)
        c.drawOval(oval, fill)
        fill.color = Color.rgb(230, 225, 210)
        for (i in 0 until 6) {
            val tx = cx - s * 0.12f + i * s * 0.048f
            path.reset()
            path.moveTo(tx, cy + s * 0.12f)
            path.lineTo(tx + s * 0.024f, cy + s * 0.2f)
            path.lineTo(tx + s * 0.048f, cy + s * 0.12f)
            path.close()
            c.drawPath(path, fill)
        }
        c.restore()
    }

    companion object {
        private const val TORCH_R = 0.17f
    }
}
