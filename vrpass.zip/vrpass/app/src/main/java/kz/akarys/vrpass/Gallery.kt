package kz.akarys.vrpass

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import java.util.concurrent.Executors

/** Телефондағы суреттерді VR ішінде көрсетуге жүктейді. */
class Gallery(private val ctx: Context) {

    @Volatile
    var uris: List<Uri> = emptyList()
        private set

    @Volatile
    var index = 0
        private set

    @Volatile
    var current: Bitmap? = null
        private set

    @Volatile
    var loaded = false
        private set

    @Volatile
    var loading = false
        private set

    @Volatile
    var permitted = false
        private set

    private val exec = Executors.newSingleThreadExecutor()

    fun permissionName(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun checkPermission(): Boolean {
        if (ctx.checkSelfPermission(permissionName()) == PackageManager.PERMISSION_GRANTED) return true
        // Android 14: «тек таңдалған суреттер» рұқсаты
        return Build.VERSION.SDK_INT >= 34 &&
            ctx.checkSelfPermission("android.permission.READ_MEDIA_VISUAL_USER_SELECTED") ==
            PackageManager.PERMISSION_GRANTED
    }

    fun refreshPermission() {
        val was = permitted
        permitted = checkPermission()
        if (permitted && !was) {
            loaded = false
        }
    }

    fun load() {
        if (loading) return
        loading = true
        exec.execute {
            val list = ArrayList<Uri>()
            try {
                val coll = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                val proj = arrayOf(MediaStore.Images.Media._ID)
                val order = MediaStore.Images.Media.DATE_ADDED + " DESC"
                ctx.contentResolver.query(coll, proj, null, null, order)?.use { c ->
                    val col = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    while (c.moveToNext() && list.size < 300) {
                        list.add(ContentUris.withAppendedId(coll, c.getLong(col)))
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "query", e)
            }
            uris = list
            index = 0
            current = null
            loaded = true
            loading = false
            if (list.isNotEmpty()) decode(0)
        }
    }

    fun step(delta: Int) {
        val n = uris.size
        if (n == 0) return
        index = ((index + delta) % n + n) % n
        current = null
        decode(index)
    }

    private fun decode(i: Int) {
        val uri = uris.getOrNull(i) ?: return
        exec.execute {
            if (i != index) return@execute
            try {
                val bounds = BitmapFactory.Options()
                bounds.inJustDecodeBounds = true
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= 1024 || bounds.outHeight / (sample * 2) >= 1024) {
                    sample *= 2
                }
                val opts = BitmapFactory.Options()
                opts.inSampleSize = sample
                var bmp: Bitmap = ctx.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, opts)
                } ?: return@execute

                val orientation = try {
                    ctx.contentResolver.openInputStream(uri)?.use {
                        ExifInterface(it).getAttributeInt(
                            ExifInterface.TAG_ORIENTATION,
                            ExifInterface.ORIENTATION_NORMAL
                        )
                    } ?: ExifInterface.ORIENTATION_NORMAL
                } catch (e: Exception) {
                    ExifInterface.ORIENTATION_NORMAL
                }
                val degrees = when (orientation) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
                if (degrees != 0f) {
                    val m = Matrix()
                    m.postRotate(degrees)
                    bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                }
                if (i == index) current = bmp
            } catch (t: Throwable) {
                Log.e(TAG, "decode", t)
            }
        }
    }

    companion object {
        private const val TAG = "Gallery"
    }
}
