package kz.akarys.vrpass

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import android.view.Surface
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Видео жазу (көргеніңді — бір көздің суреті, эффектілер, ойындар, қабілеттер + микрофон)
 * және скриншот. Файлдар галереяға түседі: Movies/VR және Pictures/VR.
 */
class Recorder(private val activity: Activity, private val state: VrState) {

    private var recorder: MediaRecorder? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null

    /** Жазуды бастайды. Қайтарады: кадр жіберетін Surface (сәтсіз болса — null). */
    fun start(): Surface? {
        if (recorder != null) return null
        return try {
            val withAudio = activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(activity) else @Suppress("DEPRECATION") MediaRecorder()
            if (withAudio) r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            val name = "VR_" + stamp() + ".mp4"
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues()
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                values.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/VR")
                values.put(MediaStore.MediaColumns.IS_PENDING, 1)
                val u = activity.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("MediaStore")
                uri = u
                val fd = activity.contentResolver.openFileDescriptor(u, "w") ?: throw IllegalStateException("fd")
                pfd = fd
                r.setOutputFile(fd.fileDescriptor)
            } else {
                val dir = activity.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: activity.filesDir
                r.setOutputFile(File(dir, name).path)
            }
            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (withAudio) {
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setAudioEncodingBitRate(128_000)
                r.setAudioSamplingRate(44_100)
            }
            r.setVideoSize(W, H)
            r.setVideoFrameRate(30)
            r.setVideoEncodingBitRate(4_000_000)
            r.prepare()
            val s = r.surface
            r.start()
            recorder = r
            state.recording = true
            state.recordStart = SystemClock.uptimeMillis()
            s
        } catch (t: Throwable) {
            Log.e(TAG, "start", t)
            cleanup(false)
            state.notice = "Жазу басталмады"
            null
        }
    }

    /** Жазуды тоқтатады (GL ағыны Surface-ті босатқаннан кейін шақыру керек). */
    fun stop() {
        val r = recorder ?: return
        var ok = true
        try {
            r.stop()
        } catch (t: Throwable) {
            Log.e(TAG, "stop", t)
            ok = false
        }
        cleanup(ok)
        state.notice = if (ok) "Видео сақталды: Movies/VR" else "Видео тым қысқа — сақталмады"
    }

    private fun cleanup(ok: Boolean) {
        try {
            recorder?.release()
        } catch (t: Throwable) {
            Log.w(TAG, "release", t)
        }
        recorder = null
        try {
            pfd?.close()
        } catch (t: Throwable) {
            Log.w(TAG, "pfd", t)
        }
        pfd = null
        val u = uri
        if (u != null && Build.VERSION.SDK_INT >= 29) {
            try {
                if (ok) {
                    val v = ContentValues()
                    v.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    activity.contentResolver.update(u, v, null, null)
                } else {
                    activity.contentResolver.delete(u, null, null)
                }
            } catch (t: Throwable) {
                Log.w(TAG, "finish", t)
            }
        }
        uri = null
        state.recording = false
    }

    /** Скриншотты галереяға сақтау (фондық ағында). */
    fun saveScreenshot(bmp: Bitmap) {
        Thread {
            try {
                val name = "VR_" + stamp() + ".jpg"
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues()
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    values.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/VR")
                    val u = activity.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("MediaStore")
                    activity.contentResolver.openOutputStream(u)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                } else {
                    val dir = activity.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: activity.filesDir
                    FileOutputStream(File(dir, name)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                }
                state.notice = "Сурет сақталды: Pictures/VR"
            } catch (t: Throwable) {
                Log.e(TAG, "screenshot", t)
                state.notice = "Сурет сақталмады"
            }
        }.start()
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    companion object {
        private const val TAG = "Recorder"
        const val W = 960
        const val H = 540
    }
}
