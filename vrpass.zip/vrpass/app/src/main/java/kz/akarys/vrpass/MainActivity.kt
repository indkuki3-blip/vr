package kz.akarys.vrpass

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Point
import android.graphics.SurfaceTexture
import android.os.BatteryManager
import android.os.PowerManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.Surface
import android.view.View
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity(), VrHost {

    private lateinit var state: VrState
    private lateinit var gallery: Gallery
    private lateinit var tracker: HandTracker
    private lateinit var camera: CameraSource
    private lateinit var sfx: Sfx
    private lateinit var web: WebPanel
    private lateinit var head: HeadTracker
    private lateinit var voice: Voice
    private lateinit var recorder: Recorder
    private lateinit var ui: VrUi
    private lateinit var glView: VRView
    private var camTexture: SurfaceTexture? = null
    private var webTexture: SurfaceTexture? = null
    private var isResumedNow = false
    private var batteryRegistered = false
    private var micAsked = false
    private var micAskedBefore = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level >= 0 && scale > 0) state.battery = level * 100 / scale
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        if (Build.VERSION.SDK_INT >= 28) {
            // Камера тесігінің (punch-hole) астына да салу — екі көз симметриялы болсын
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }

        state = VrState(this)
        val real = realScreenSize()
        state.screenW = real.x

        gallery = Gallery(this)
        tracker = HandTracker(applicationContext, state)
        Thread { tracker.init() }.start()
        camera = CameraSource(this, state, tracker)
        sfx = Sfx(applicationContext)
        web = WebPanel(this, state)
        head = HeadTracker(this, state)
        voice = Voice(this, state)
        recorder = Recorder(this, state)
        ui = VrUi(state, this, gallery, sfx)
        glView = VRView(this, state, ui) { cam, webSt -> onGlReady(cam, webSt) }
        realSize = real
        applyQuality(if (state.quality == 0) 1 else state.quality - 1)
        setContentView(glView)

        // Тұрақты өнімділік режимі (телефон қолдаса): жиілік секірмейді, қызу баяу
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isSustainedPerformanceModeSupported) window.setSustainedPerformanceMode(true)
            if (Build.VERSION.SDK_INT >= 29) {
                pm.addThermalStatusListener { status -> onThermal(status) }
            }
        } catch (e: Exception) {
            Log.w(TAG, "power", e)
        }

        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.CAMERA)
        }
        if (!gallery.checkPermission()) need.add(gallery.permissionName())
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), REQ_START)
    }

    // ---------------------------------------------------------------- сапа (ажыратымдылық)
    private var realSize = Point(1920, 1080)
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private var slowSec = 0
    private var fastSec = 0
    private var lastDowngrade = 0L

    /** 0 — жоғары, 1 — орта, 2 — төмен: экран ажыратымдылығы мен қол трекингінің жиілігі. */
    private fun applyQuality(level: Int) {
        val lv = level.coerceIn(0, 2)
        state.qualityLevel = lv
        val scale = SCALES[lv]
        state.trackFps = intArrayOf(20, 15, 10)[lv]
        glView.holder.setFixedSize((realSize.x * scale).toInt() and 1.inv(), (realSize.y * scale).toInt() and 1.inv())
    }

    /** Әр секунд: Авто режимде FPS-ке қарай сапаны өзгерту. */
    private val qualityLoop = object : Runnable {
        override fun run() {
            val q = state.quality
            if (q != 0) {
                if (state.qualityLevel != q - 1) applyQuality(q - 1)
            } else if (state.fps > 0f) {
                val now = android.os.SystemClock.uptimeMillis()
                if (state.fps < 24f) {
                    slowSec++
                    fastSec = 0
                } else if (state.fps >= 28.5f) {
                    fastSec++
                    slowSec = 0
                } else {
                    slowSec = 0
                    fastSec = 0
                }
                if (slowSec >= 3 && state.qualityLevel < 2) {
                    applyQuality(state.qualityLevel + 1)
                    slowSec = 0
                    lastDowngrade = now
                } else if (fastSec >= 20 && state.qualityLevel > 0 && !state.hot && now - lastDowngrade > 60_000L) {
                    applyQuality(state.qualityLevel - 1)
                    fastSec = 0
                }
            }
            main.postDelayed(this, 1000L)
        }
    }

    private fun onThermal(status: Int) {
        val hot = status >= PowerManager.THERMAL_STATUS_MODERATE
        if (hot && !state.hot) {
            state.notice = "🌡 Телефон қызды — сапа азайтылды"
            if (state.quality == 0) applyQuality(2)
        }
        state.hot = hot
    }

    /** Экранның нақты өлшемі, көлденең (ені > биіктігі). */
    @Suppress("DEPRECATION")
    private fun realScreenSize(): Point {
        val p = Point()
        windowManager.defaultDisplay.getRealSize(p)
        return Point(max(p.x, p.y), min(p.x, p.y))
    }

    private fun onGlReady(cam: SurfaceTexture, webSt: SurfaceTexture) {
        camera.stop()
        camTexture = cam
        webTexture = webSt
        web.setSurfaceTexture(webSt)
        startCameraIfPossible()
    }

    private fun startCameraIfPossible() {
        val st = camTexture ?: return
        if (!isResumedNow) return
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            state.cameraStatus = "Камераға рұқсат беріңіз (Баптаулар → Қосымшалар)"
            return
        }
        state.cameraStatus = ""
        camera.start(st)
    }

    override fun onResume() {
        super.onResume()
        isResumedNow = true
        hideSystemUi()
        updateDisplayRotation()
        glView.onResume()
        glView.startTicker()
        head.start()
        main.removeCallbacks(qualityLoop)
        main.postDelayed(qualityLoop, 1000L)
        web.onResume()
        gallery.refreshPermission()
        try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(batteryReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(batteryReceiver, filter)
            }
            batteryRegistered = true
        } catch (e: Exception) {
            Log.w(TAG, "battery", e)
        }
        startCameraIfPossible()
    }

    override fun onPause() {
        isResumedNow = false
        main.removeCallbacks(qualityLoop)
        head.stop()
        voice.stop()
        if (state.recording) glView.stopRecording { recorder.stop() }
        glView.stopTicker()
        glView.onPause()
        camera.stop()
        web.onPause()
        web.setSurfaceTexture(null)
        camTexture?.release()
        camTexture = null
        webTexture?.release()
        webTexture = null
        if (batteryRegistered) {
            try {
                unregisterReceiver(batteryReceiver)
            } catch (e: Exception) {
                Log.w(TAG, "battery", e)
            }
            batteryRegistered = false
        }
        super.onPause()
    }

    override fun onDestroy() {
        web.destroy()
        voice.destroy()
        tracker.close()
        sfx.release()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        gallery.refreshPermission()
        startCameraIfPossible()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> {
                ui.post(VrUi.EV_NEXT)
                return true
            }
            KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_BUTTON_A,
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                ui.post(VrUi.EV_MENU)
                return true
            }
            KeyEvent.KEYCODE_BACK -> {
                if (ui.screen != VrUi.Screen.HOME) {
                    ui.post(VrUi.EV_BACK)
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------------------------------------------------------------- VrHost
    override fun requestGalleryPermission() {
        runOnUiThread { requestPermissions(arrayOf(gallery.permissionName()), REQ_GALLERY) }
    }

    override fun exitApp() {
        runOnUiThread { finish() }
    }

    override fun webOpen(url: String): Boolean {
        runOnUiThread {
            if (!web.open(url)) state.notice = "Веб-панель ашылмады"
        }
        return true
    }

    override fun webNavigate(text: String) {
        runOnUiThread { web.navigate(text) }
    }

    override fun webBack() {
        runOnUiThread { web.back() }
    }

    override fun webReload() {
        runOnUiThread { web.reload() }
    }

    override fun webClose() {
        runOnUiThread { web.close() }
    }

    override fun webTouch(action: Int, nx: Float, ny: Float) {
        web.touch(action, nx, ny)
    }

    override fun webScroll(dir: Int) {
        runOnUiThread { web.scroll(dir) }
    }

    override fun webInsert(text: String, submit: Boolean) {
        web.insertText(text, submit)
    }

    override fun webSetLandscape(on: Boolean) {
        runOnUiThread { web.setLandscape(on) }
    }

    override fun voiceStart() {
        runOnUiThread { voice.start() }
    }

    override fun voiceStop() {
        runOnUiThread { voice.stop() }
    }

    override fun recordToggle() {
        runOnUiThread {
            if (state.recording) {
                glView.stopRecording { recorder.stop() }
            } else {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC_REC)
                    state.notice = "Микрофонға рұқсат беріп, қайта бас (дыбыссыз да жазуға болады)"
                    micAsked = true
                    if (!micAskedBefore) {
                        micAskedBefore = true
                        return@runOnUiThread
                    }
                }
                val s = recorder.start()
                if (s != null) {
                    glView.startRecording(s)
                    state.notice = "● Жазу басталды"
                }
            }
        }
    }

    override fun screenshot() {
        glView.takeScreenshot { bmp -> recorder.saveScreenshot(bmp) }
    }

    @Suppress("DEPRECATION")
    private fun updateDisplayRotation() {
        state.displayRotation = when (windowManager.defaultDisplay.rotation) {
            Surface.ROTATION_0 -> 0
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 270
            else -> 90
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateDisplayRotation()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
    }

    companion object {
        private const val TAG = "MainActivity"
        private const val REQ_START = 1
        private const val REQ_GALLERY = 2
        private const val REQ_MIC_REC = 4
        private val SCALES = floatArrayOf(0.85f, 0.68f, 0.52f)
    }
}
