package kz.akarys.vrpass

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.SurfaceTexture
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.content.res.Configuration
import android.view.KeyEvent
import android.view.Surface
import android.view.View
import android.view.WindowManager

class MainActivity : Activity(), VrHost {

    private lateinit var state: VrState
    private lateinit var gallery: Gallery
    private lateinit var tracker: HandTracker
    private lateinit var camera: CameraSource
    private lateinit var ui: VrUi
    private lateinit var glView: VRView
    private var surfaceTexture: SurfaceTexture? = null
    private var isResumedNow = false
    private var batteryRegistered = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level >= 0 && scale > 0) state.battery = level * 100 / scale
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        if (Build.VERSION.SDK_INT >= 28) {
            // Камера тесігінің (punch-hole) астына да салу — екі көз симметриялы болсын
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }

        state = VrState(this)
        gallery = Gallery(this)
        tracker = HandTracker(applicationContext, state)
        Thread { tracker.init() }.start()
        camera = CameraSource(this, state, tracker)
        ui = VrUi(state, this, gallery)
        glView = VRView(this, state, ui) { st -> onGlReady(st) }
        setContentView(glView)

        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.CAMERA)
        }
        if (!gallery.checkPermission()) need.add(gallery.permissionName())
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), REQ_START)
    }

    private fun onGlReady(st: SurfaceTexture) {
        camera.stop()
        surfaceTexture = st
        startCameraIfPossible()
    }

    private fun startCameraIfPossible() {
        val st = surfaceTexture ?: return
        if (!isResumedNow) return
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            state.cameraStatus = "Камераға рұқсат беріңіз (Баптаулар → Қосымшалар)"
            return
        }
        state.cameraStatus = ""
        camera.start(st)
    }

    override fun onResume() {
        super.onResume()
        isResumedNow = true
        hideSystemUi()
        updateDisplayRotation()
        glView.onResume()
        gallery.refreshPermission()
        try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(batteryReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(batteryReceiver, filter)
            }
            batteryRegistered = true
        } catch (e: Exception) {
            Log.w(TAG, "battery", e)
        }
        startCameraIfPossible()
    }

    override fun onPause() {
        isResumedNow = false
        glView.onPause()
        camera.stop()
        surfaceTexture?.release()
        surfaceTexture = null
        if (batteryRegistered) {
            try {
                unregisterReceiver(batteryReceiver)
            } catch (e: Exception) {
                Log.w(TAG, "battery", e)
            }
            batteryRegistered = false
        }
        super.onPause()
    }

    override fun onDestroy() {
        tracker.close()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        gallery.refreshPermission()
        startCameraIfPossible()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> {
                ui.post(VrUi.EV_NEXT)
                return true
            }
            KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_BUTTON_A,
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                ui.post(VrUi.EV_MENU)
                return true
            }
            KeyEvent.KEYCODE_BACK -> {
                if (ui.screen != VrUi.Screen.HOME) {
                    ui.post(VrUi.EV_BACK)
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------------------------------------------------------------- VrHost
    override fun launchApp(packages: List<String>): Boolean {
        for (pkg in packages) {
            val intent = packageManager.getLaunchIntentForPackage(pkg) ?: continue
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runOnUiThread {
                try {
                    startActivity(intent)
                } catch (e: Exception) {
                    Log.e(TAG, "launch $pkg", e)
                }
            }
            return true
        }
        return false
    }

    override fun requestGalleryPermission() {
        runOnUiThread { requestPermissions(arrayOf(gallery.permissionName()), REQ_GALLERY) }
    }

    override fun exitApp() {
        runOnUiThread { finish() }
    }

    @Suppress("DEPRECATION")
    private fun updateDisplayRotation() {
        state.displayRotation = when (windowManager.defaultDisplay.rotation) {
            Surface.ROTATION_0 -> 0
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 270
            else -> 90
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateDisplayRotation()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
    }

    companion object {
        private const val TAG = "MainActivity"
        private const val REQ_START = 1
        private const val REQ_GALLERY = 2
    }
}
