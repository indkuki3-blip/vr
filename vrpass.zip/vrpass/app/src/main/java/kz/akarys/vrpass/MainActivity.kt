package kz.akarys.vrpass

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Point
import android.graphics.SurfaceTexture
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.Surface
import android.view.View
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity(), VrHost {

    private lateinit var state: VrState
    private lateinit var gallery: Gallery
    private lateinit var tracker: HandTracker
    private lateinit var camera: CameraSource
    private lateinit var sfx: Sfx
    private lateinit var web: WebPanel
    private lateinit var ui: VrUi
    private lateinit var glView: VRView
    private var camTexture: SurfaceTexture? = null
    private var webTexture: SurfaceTexture? = null
    private var isResumedNow = false
    private var batteryRegistered = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level >= 0 && scale > 0) state.battery = level * 100 / scale
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        if (Build.VERSION.SDK_INT >= 28) {
            // Камера тесігінің (punch-hole) астына да салу — екі көз симметриялы болсын
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }

        state = VrState(this)
        val real = realScreenSize()
        state.screenW = real.x

        gallery = Gallery(this)
        tracker = HandTracker(applicationContext, state)
        Thread { tracker.init() }.start()
        camera = CameraSource(this, state, tracker)
        sfx = Sfx(applicationContext)
        web = WebPanel(this, state)
        ui = VrUi(state, this, gallery, sfx)
        glView = VRView(this, state, ui) { cam, webSt -> onGlReady(cam, webSt) }
        // Оптимизация: экранды 75% ажыратымдылықта саламыз, жүйе өзі созады
        glView.holder.setFixedSize((real.x * RENDER_SCALE).toInt() and 1.inv(), (real.y * RENDER_SCALE).toInt() and 1.inv())
        setContentView(glView)

        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.CAMERA)
        }
        if (!gallery.checkPermission()) need.add(gallery.permissionName())
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), REQ_START)
    }

    /** Экранның нақты өлшемі, көлденең (ені > биіктігі). */
    @Suppress("DEPRECATION")
    private fun realScreenSize(): Point {
        val p = Point()
        windowManager.defaultDisplay.getRealSize(p)
        return Point(max(p.x, p.y), min(p.x, p.y))
    }

    private fun onGlReady(cam: SurfaceTexture, webSt: SurfaceTexture) {
        camera.stop()
        camTexture = cam
        webTexture = webSt
        web.setSurfaceTexture(webSt)
        startCameraIfPossible()
    }

    private fun startCameraIfPossible() {
        val st = camTexture ?: return
        if (!isResumedNow) return
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            state.cameraStatus = "Камераға рұқсат беріңіз (Баптаулар → Қосымшалар)"
            return
        }
        state.cameraStatus = ""
        camera.start(st)
    }

    override fun onResume() {
        super.onResume()
        isResumedNow = true
        hideSystemUi()
        updateDisplayRotation()
        glView.onResume()
        glView.startTicker()
        web.onResume()
        gallery.refreshPermission()
        try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(batteryReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(batteryReceiver, filter)
            }
            batteryRegistered = true
        } catch (e: Exception) {
            Log.w(TAG, "battery", e)
        }
        startCameraIfPossible()
    }

    override fun onPause() {
        isResumedNow = false
        glView.stopTicker()
        glView.onPause()
        camera.stop()
        web.onPause()
        web.setSurfaceTexture(null)
        camTexture?.release()
        camTexture = null
        webTexture?.release()
        webTexture = null
        if (batteryRegistered) {
            try {
                unregisterReceiver(batteryReceiver)
            } catch (e: Exception) {
                Log.w(TAG, "battery", e)
            }
            batteryRegistered = false
        }
        super.onPause()
    }

    override fun onDestroy() {
        web.destroy()
        tracker.close()
        sfx.release()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        gallery.refreshPermission()
        startCameraIfPossible()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> {
                ui.post(VrUi.EV_NEXT)
                return true
            }
            KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_BUTTON_A,
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                ui.post(VrUi.EV_MENU)
                return true
            }
            KeyEvent.KEYCODE_BACK -> {
                if (ui.screen != VrUi.Screen.HOME) {
                    ui.post(VrUi.EV_BACK)
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------------------------------------------------------------- VrHost
    override fun launchApp(packages: List<String>): Boolean {
        for (pkg in packages) {
            val intent = packageManager.getLaunchIntentForPackage(pkg) ?: continue
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runOnUiThread {
                try {
                    startActivity(intent)
                } catch (e: Exception) {
                    Log.e(TAG, "launch $pkg", e)
                }
            }
            return true
        }
        return false
    }

    override fun requestGalleryPermission() {
        runOnUiThread { requestPermissions(arrayOf(gallery.permissionName()), REQ_GALLERY) }
    }

    override fun exitApp() {
        runOnUiThread { finish() }
    }

    override fun webOpen(url: String): Boolean {
        runOnUiThread {
            if (!web.open(url)) Log.e(TAG, "web open failed")
        }
        return true
    }

    override fun webBack() {
        runOnUiThread { web.back() }
    }

    override fun webReload() {
        runOnUiThread { web.reload() }
    }

    override fun webClose() {
        runOnUiThread { web.close() }
    }

    override fun webTouch(action: Int, nx: Float, ny: Float) {
        web.touch(action, nx, ny)
    }

    @Suppress("DEPRECATION")
    private fun updateDisplayRotation() {
        state.displayRotation = when (windowManager.defaultDisplay.rotation) {
            Surface.ROTATION_0 -> 0
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 270
            else -> 90
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateDisplayRotation()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
    }

    companion object {
        private const val TAG = "MainActivity"
        private const val REQ_START = 1
        private const val REQ_GALLERY = 2
        private const val RENDER_SCALE = 0.75f
    }
}
