package kz.akarys.vrpass

import android.content.Context
import android.graphics.Bitmap
import android.media.Image
import android.os.SystemClock
import android.util.Log
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import kotlin.math.hypot

/**
 * Камера кадрынан қолды табады (MediaPipe Hand Landmarker).
 * Нәтиже: сұқ саусақ ұшының орны және «шымшу» (бас бармақ + сұқ саусақ түйіседі).
 */
class HandTracker(private val ctx: Context, private val state: VrState) {

    @Volatile
    private var landmarker: HandLandmarker? = null
    private var bitmap: Bitmap? = null
    private var pixels = IntArray(0)
    private var lastTs = 0L
    private var smoothX = 0.5f
    private var smoothY = 0.5f
    private var hadHand = false

    /** Модельді жүктеу (жеке ағында шақырылады). */
    fun init() {
        try {
            val base = BaseOptions.builder()
                .setModelAssetPath("hand_landmarker.task")
                .setDelegate(Delegate.CPU)
                .build()
            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.VIDEO)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .build()
            landmarker = HandLandmarker.createFromOptions(ctx, options)
            state.trackerReady = true
            state.trackerStatus = ""
        } catch (t: Throwable) {
            Log.e(TAG, "init", t)
            state.trackerReady = false
            state.trackerStatus = "Қол трекингі қосылмады. Батырмалар: дыбыс +/−"
        }
    }

    /** Камераның YUV кадрын өңдеу (талдау ағынында). */
    fun process(img: Image) {
        val lm = landmarker ?: return
        val bmp = toBitmap(img)
        var ts = SystemClock.uptimeMillis()
        if (ts <= lastTs) ts = lastTs + 1
        lastTs = ts

        val result = try {
            lm.detectForVideo(BitmapImageBuilder(bmp).build(), ts)
        } catch (t: Throwable) {
            Log.w(TAG, "detect", t)
            return
        }

        val hands = result.landmarks()
        if (hands.isEmpty()) {
            hadHand = false
            state.pinch = false
            return
        }
        val p = hands[0]
        val wrist = p[0]
        val thumb = p[4]
        val tip = p[8]
        val middle = p[9]

        val aspect = bmp.width.toFloat() / bmp.height
        val scale = hypot((wrist.x() - middle.x()) * aspect, wrist.y() - middle.y()).coerceAtLeast(0.001f)
        val pinchDist = hypot((tip.x() - thumb.x()) * aspect, tip.y() - thumb.y()) / scale
        // Гистерезис: басу мен жіберудің шегі әр түрлі, сонда дірілдемейді
        val pinchNow = if (state.pinch) pinchDist < 0.45f else pinchDist < 0.28f

        val tx = tip.x()
        val ty = tip.y()
        if (!hadHand) {
            smoothX = tx
            smoothY = ty
        } else {
            smoothX += (tx - smoothX) * SMOOTH
            smoothY += (ty - smoothY) * SMOOTH
        }
        hadHand = true

        state.handX = smoothX
        state.handY = smoothY
        state.pinch = pinchNow
        state.handTime = SystemClock.uptimeMillis()
    }

    fun close() {
        try {
            landmarker?.close()
        } catch (t: Throwable) {
            Log.w(TAG, "close", t)
        }
        landmarker = null
    }

    /** YUV_420_888 → ARGB Bitmap, бір мезгілде ~320 px енге кішірейтеді. */
    private fun toBitmap(img: Image): Bitmap {
        val step = if (img.width >= 960) 3 else 2
        val w = img.width / step
        val h = img.height / step
        var out = bitmap
        if (out == null || out.width != w || out.height != h) {
            out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bitmap = out
            pixels = IntArray(w * h)
        }

        val planes = img.planes
        val yBuf = planes[0].buffer
        val uBuf = planes[1].buffer
        val vBuf = planes[2].buffer
        val yRow = planes[0].rowStride
        val yPix = planes[0].pixelStride
        val uRow = planes[1].rowStride
        val uPix = planes[1].pixelStride
        val vRow = planes[2].rowStride
        val vPix = planes[2].pixelStride

        var i = 0
        for (oy in 0 until h) {
            val y = oy * step
            val yBase = y * yRow
            val uBase = (y shr 1) * uRow
            val vBase = (y shr 1) * vRow
            for (ox in 0 until w) {
                val x = ox * step
                val yy = yBuf.get(yBase + x * yPix).toInt() and 0xff
                val u = (uBuf.get(uBase + (x shr 1) * uPix).toInt() and 0xff) - 128
                val v = (vBuf.get(vBase + (x shr 1) * vPix).toInt() and 0xff) - 128
                var r = yy + ((359 * v) shr 8)
                var g = yy - ((88 * u + 183 * v) shr 8)
                var b = yy + ((454 * u) shr 8)
                if (r < 0) r = 0 else if (r > 255) r = 255
                if (g < 0) g = 0 else if (g > 255) g = 255
                if (b < 0) b = 0 else if (b > 255) b = 255
                pixels[i++] = (0xff shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        out.setPixels(pixels, 0, w, 0, 0, w, h)
        return out
    }

    companion object {
        private const val TAG = "HandTracker"
        private const val SMOOTH = 0.55f
    }
}
