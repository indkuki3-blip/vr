package kz.akarys.vrpass

import android.content.Context
import android.graphics.Bitmap
import android.media.Image
import android.os.SystemClock
import android.util.Log
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Екі қолға дейін табады. Екі көз:
 *  - ноут (RemoteHands, Wi-Fi) — қосулы әрі жауап беріп тұрса, телефон тек кадр жібереді;
 *  - телефонның өзі (MediaPipe) — ноут болмаса автоматты түрде.
 * Әр қол үшін: 21 нүкте, тегістелген курсор, шымшу, жұдырық, алақан нормалі.
 */
class HandTracker(private val ctx: Context, private val state: VrState) {

    /** Бір табылған қол (кез келген көзден). label: «Left», «Right» немесе бос. */
    class Detected(val xs: FloatArray, val ys: FloatArray, val zs: FloatArray, val label: String)

    @Volatile
    private var landmarker: HandLandmarker? = null
    private var bitmap: Bitmap? = null
    private var pixels = IntArray(0)
    private var yArr = ByteArray(0)
    private var uArr = ByteArray(0)
    private var vArr = ByteArray(0)
    private var lastTs = 0L
    private var lastLocal = 0L
    private var lastSend = 0L

    private val remote = RemoteHands(state) { list, aspect -> publish(list, aspect) }

    // Әр «слот» (0, 1) бойынша алдыңғы кадрдың мәндері
    private val prevValid = BooleanArray(2)
    private val prevWristX = FloatArray(2)
    private val prevWristY = FloatArray(2)
    private val smoothX = FloatArray(2)
    private val smoothY = FloatArray(2)
    private val pinchState = BooleanArray(2)
    private val fistState = BooleanArray(2)

    /** Модельді жүктеу (жеке ағында шақырылады). */
    fun init() {
        try {
            val base = BaseOptions.builder()
                .setModelAssetPath("hand_landmarker.task")
                .setDelegate(Delegate.CPU)
                .build()
            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.VIDEO)
                .setNumHands(2)
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .build()
            landmarker = HandLandmarker.createFromOptions(ctx, options)
            state.trackerReady = true
            state.trackerStatus = ""
        } catch (t: Throwable) {
            Log.e(TAG, "init", t)
            state.trackerReady = state.remoteOn
            state.trackerStatus = "Телефондағы қол трекингі қосылмады"
        }
    }

    /** Камераның YUV кадрын өңдеу (талдау ағынында). */
    fun process(img: Image) {
        val now = SystemClock.uptimeMillis()
        val useRemote = state.remoteOn
        val remoteLive = useRemote && remote.connected()
        // Ноутқа — жиірек (телефонға жеңіл), телефонда — баптаудағы шекпен
        val gap = if (remoteLive) 1000L / REMOTE_FPS else 1000L / state.trackFps.coerceIn(5, 30)
        if (now - (if (remoteLive) lastSend else lastLocal) < gap) return

        val bmp = toBitmap(img)
        val aspect = bmp.width.toFloat() / bmp.height
        if (useRemote) {
            state.trackerReady = true
            if (now - lastSend >= 1000L / REMOTE_FPS) {
                lastSend = now
                remote.send(bmp)
            }
            if (remoteLive) return
        }
        // Ноут жоқ немесе жауап бермейді → телефонның өзі
        val lm = landmarker ?: return
        lastLocal = now
        var ts = now
        if (ts <= lastTs) ts = lastTs + 1
        lastTs = ts
        val result = try {
            lm.detectForVideo(BitmapImageBuilder(bmp).build(), ts)
        } catch (t: Throwable) {
            Log.w(TAG, "detect", t)
            return
        }
        val found = result.landmarks()
        val list = ArrayList<Detected>(2)
        for (h in 0 until min(found.size, 2)) {
            val p = found[h]
            if (p.size < 21) continue
            val xs = FloatArray(21)
            val ys = FloatArray(21)
            val zs = FloatArray(21)
            for (i in 0 until 21) {
                xs[i] = p[i].x()
                ys[i] = p[i].y()
                zs[i] = p[i].z()
            }
            list.add(Detected(xs, ys, zs, handLabel(result, h)))
        }
        publish(list, aspect)
    }

    /** «Left» / «Right» белгісі (болмаса бос жол). */
    @Suppress("DEPRECATION")
    private fun handLabel(result: HandLandmarkerResult, index: Int): String = try {
        result.handednesses().getOrNull(index)?.firstOrNull()?.categoryName() ?: ""
    } catch (t: Throwable) {
        ""
    }

    /**
     * Табылған қолдарды өңдеп, интерфейске жариялау (екі көзге ортақ).
     * Ноуттан келген жауап басқа ағыннан шақырылады, сондықтан synchronized.
     */
    @Synchronized
    fun publish(found: List<Detected>, aspect: Float) {
        val used = BooleanArray(2)
        val newValid = BooleanArray(2)
        val list = ArrayList<RawHand>(2)

        for (d in found) {
            val xs = d.xs
            val ys = d.ys
            val zs = d.zs
            val wx = xs[0]
            val wy = ys[0]

            // Слот таңдау: алдыңғы кадрдағы ең жақын білек
            var slot = -1
            var bestD = 0.3f
            for (s in 0..1) {
                if (!used[s] && prevValid[s]) {
                    val dd = hypot(wx - prevWristX[s], wy - prevWristY[s])
                    if (dd < bestD) {
                        bestD = dd
                        slot = s
                    }
                }
            }
            if (slot < 0) {
                for (s in 0..1) if (!used[s] && !prevValid[s]) { slot = s; break }
            }
            if (slot < 0) {
                for (s in 0..1) if (!used[s]) { slot = s; break }
            }
            if (slot < 0) continue
            used[slot] = true
            val fresh = !prevValid[slot]

            // ---- Алақан нормалі: (p5 − p0) × (p17 − p0). MediaPipe кадрды айна деп санайды,
            // сондықтан артқы камерада шын оң қол «Left» деп белгіленеді.
            val ax = (xs[5] - xs[0]) * aspect
            val ay = ys[5] - ys[0]
            val az = (zs[5] - zs[0]) * aspect
            val bx = (xs[17] - xs[0]) * aspect
            val by = ys[17] - ys[0]
            val bz = (zs[17] - zs[0]) * aspect
            var nx = ay * bz - az * by
            var ny = az * bx - ax * bz
            var nz = ax * by - ay * bx
            val nl = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(1e-6f)
            val sign = if (d.label == "Right") -1f else 1f
            nx = nx / nl * sign
            ny = ny / nl * sign
            nz = nz / nl * sign

            // ---- Жұдырық: саусақ ұштары білекке жақын
            val handLen = hypot((xs[0] - xs[9]) * aspect, ys[0] - ys[9]).coerceAtLeast(0.001f)
            var tipSum = 0f
            for (t in TIPS) tipSum += hypot((xs[t] - xs[0]) * aspect, ys[t] - ys[0])
            val ratio = tipSum / 4f / handLen
            val fistNow = if (fistState[slot] && !fresh) ratio < 1.4f else ratio < 1.15f
            fistState[slot] = fistNow

            val pinchDist = hypot((xs[8] - xs[4]) * aspect, ys[8] - ys[4]) / handLen
            // Гистерезис: басу мен жіберудің шегі әр түрлі, сонда дірілдемейді
            val pinchNow = if (!fresh && pinchState[slot]) pinchDist < 0.45f else pinchDist < 0.28f

            if (fresh) {
                smoothX[slot] = xs[8]
                smoothY[slot] = ys[8]
            } else {
                smoothX[slot] += (xs[8] - smoothX[slot]) * SMOOTH
                smoothY[slot] += (ys[8] - smoothY[slot]) * SMOOTH
            }

            prevWristX[slot] = wx
            prevWristY[slot] = wy
            newValid[slot] = true
            pinchState[slot] = pinchNow
            list.add(
                RawHand(
                    xs, ys, zs, smoothX[slot], smoothY[slot], pinchNow && !fistNow, slot,
                    fistNow, nx, ny, nz, aspect
                )
            )
        }

        for (s in 0..1) {
            prevValid[s] = newValid[s]
            if (!newValid[s]) {
                pinchState[s] = false
                fistState[s] = false
            }
        }
        state.hands = HandsFrame(list, SystemClock.uptimeMillis())
    }

    fun close() {
        remote.close()
        try {
            landmarker?.close()
        } catch (t: Throwable) {
            Log.w(TAG, "close", t)
        }
        landmarker = null
    }

    /**
     * YUV_420_888 → ARGB Bitmap, бір мезгілде ~320 px енге кішірейтеді.
     * Жазықтықтар бірден массивке көшіріледі (пиксельдеп оқудан әлдеқайда жылдам).
     */
    private fun toBitmap(img: Image): Bitmap {
        val step = (img.width / 320).coerceAtLeast(1)
        val w = img.width / step
        val h = img.height / step
        var out = bitmap
        if (out == null || out.width != w || out.height != h) {
            out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bitmap = out
            pixels = IntArray(w * h)
        }

        val planes = img.planes
        val yBuf = planes[0].buffer
        val uBuf = planes[1].buffer
        val vBuf = planes[2].buffer
        if (yArr.size < yBuf.remaining()) yArr = ByteArray(yBuf.remaining())
        if (uArr.size < uBuf.remaining()) uArr = ByteArray(uBuf.remaining())
        if (vArr.size < vBuf.remaining()) vArr = ByteArray(vBuf.remaining())
        val yLen = yBuf.remaining()
        val uLen = uBuf.remaining()
        val vLen = vBuf.remaining()
        yBuf.get(yArr, 0, yLen)
        uBuf.get(uArr, 0, uLen)
        vBuf.get(vArr, 0, vLen)
        val ya = yArr
        val ua = uArr
        val va = vArr
        val px = pixels

        val yRow = planes[0].rowStride
        val yPix = planes[0].pixelStride
        val uRow = planes[1].rowStride
        val uPix = planes[1].pixelStride
        val vRow = planes[2].rowStride
        val vPix = planes[2].pixelStride

        var i = 0
        for (oy in 0 until h) {
            val y = oy * step
            val yBase = y * yRow
            val uBase = (y shr 1) * uRow
            val vBase = (y shr 1) * vRow
            for (ox in 0 until w) {
                val x = ox * step
                val yi = yBase + x * yPix
                val ui = uBase + (x shr 1) * uPix
                val vi = vBase + (x shr 1) * vPix
                val yy = if (yi < yLen) ya[yi].toInt() and 0xff else 0
                val u = (if (ui < uLen) ua[ui].toInt() and 0xff else 128) - 128
                val v = (if (vi < vLen) va[vi].toInt() and 0xff else 128) - 128
                var r = yy + ((359 * v) shr 8)
                var g = yy - ((88 * u + 183 * v) shr 8)
                var b = yy + ((454 * u) shr 8)
                if (r < 0) r = 0 else if (r > 255) r = 255
                if (g < 0) g = 0 else if (g > 255) g = 255
                if (b < 0) b = 0 else if (b > 255) b = 255
                px[i++] = (0xff shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    companion object {
        private const val TAG = "HandTracker"
        private const val SMOOTH = 0.6f
        private const val REMOTE_FPS = 25L
        private val TIPS = intArrayOf(8, 12, 16, 20)
    }
}
