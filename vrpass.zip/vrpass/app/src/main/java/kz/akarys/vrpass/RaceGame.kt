package kz.akarys.vrpass

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.min
import kotlin.random.Random

/**
 * Жарыс: екі қолды рульді ұстағандай ұста да, бұр (қолдар арасындағы бұрыш = руль).
 * Бір қол болса — қолды оңға/солға жылжыт. Алдағы көліктерге соқтығыспа.
 */
class RaceGame(private val sfx: Sfx) : MiniGame {

    private class Car(val lane: Float, var z: Float, val color: Int)

    override val id = "race"
    override val title = "Жарыс"
    override var finished = false
        private set
    override val score: Int
        get() = (dist / 10f).toInt()

    private val cars = ArrayList<Car>()
    private var playerX = 0f
    private var steer = 0f
    private var speed = 0f
    private var dist = 0f
    private var lastT = 0L
    private var nextSpawn = 0f
    private var crashT = 0L
    private var handsSeen = 0

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private var skyShader: LinearGradient? = null
    private var skyH = 0
    private val carColors = intArrayOf(
        Color.rgb(230, 60, 60), Color.rgb(60, 140, 240), Color.rgb(250, 200, 40),
        Color.rgb(80, 200, 120), Color.rgb(200, 90, 220)
    )

    override fun start(now: Long) {
        cars.clear()
        playerX = 0f
        steer = 0f
        speed = 25f
        dist = 0f
        lastT = now
        nextSpawn = 20f
        finished = false
        crashT = 0L
    }

    override fun update(now: Long, hands: List<EyeHand>, aspect: Float) {
        val dt = min(0.05f, (now - lastT) / 1000f)
        lastT = now
        if (finished || crashT > 0L) {
            if (crashT > 0L && now - crashT > 900L) finished = true
            return
        }

        // ---- руль
        handsSeen = hands.size
        val target = when {
            hands.size >= 2 -> {
                val a = hands[0]
                val b = hands[1]
                val left = if (a.x(9) < b.x(9)) a else b
                val right = if (left === a) b else a
                val dx = (right.x(9) - left.x(9)) * aspect
                val dy = right.y(9) - left.y(9)
                (atan2(dy, dx) / 0.6f).coerceIn(-1f, 1f)
            }
            hands.size == 1 -> ((hands[0].x(9) - 0.5f) * 3f).coerceIn(-1f, 1f)
            else -> 0f
        }
        steer += (target - steer) * min(1f, dt * 8f)
        playerX = (playerX + steer * dt * 1.9f).coerceIn(-1.35f, 1.35f)

        // ---- жылдамдық
        speed = min(85f, speed + dt * 1.6f)
        if (abs(playerX) > 1f) speed = (speed * (1f - dt * 1.2f)).coerceAtLeast(15f)
        dist += speed * dt

        // ---- басқа көліктер
        if (dist >= nextSpawn) {
            val lane = floatArrayOf(-0.66f, 0f, 0.66f)[Random.nextInt(3)]
            cars.add(Car(lane, 120f, carColors[Random.nextInt(carColors.size)]))
            nextSpawn = dist + (60f - min(35f, dist / 60f)) + Random.nextFloat() * 25f
        }
        val it = cars.iterator()
        while (it.hasNext()) {
            val car = it.next()
            car.z -= (speed - 14f) * dt * 0.6f
            if (car.z < 0.8f) {
                it.remove()
                continue
            }
            if (car.z in 1.6f..3.6f && abs(car.lane - playerX) < 0.42f) {
                crashT = now
                sfx.play("crash")
                sfx.vibrate(400)
            }
        }
    }

    override fun draw(c: Canvas, w: Int, h: Int, now: Long) {
        val fw = w.toFloat()
        val fh = h.toFloat()
        val hor = fh * 0.42f

        // Аспан
        if (skyShader == null || skyH != h) {
            skyShader = LinearGradient(0f, 0f, 0f, hor, Color.rgb(20, 30, 80), Color.rgb(250, 140, 70), Shader.TileMode.CLAMP)
            skyH = h
        }
        fill.shader = skyShader
        c.drawRect(0f, 0f, fw, hor, fill)
        fill.shader = null
        // Жер
        fill.color = Color.rgb(40, 120, 50)
        c.drawRect(0f, hor, fw, fh, fill)

        // Жол (трапеция)
        val hwBottom = fw * 0.75f
        val cxBottom = fw * 0.5f - playerX * hwBottom
        path.reset()
        path.moveTo(fw * 0.5f - 2f, hor)
        path.lineTo(fw * 0.5f + 2f, hor)
        path.lineTo(cxBottom + hwBottom, fh)
        path.lineTo(cxBottom - hwBottom, fh)
        path.close()
        fill.color = Color.rgb(60, 60, 66)
        c.drawPath(path, fill)

        // Жолақтар
        fill.color = Color.rgb(240, 240, 240)
        val period = 8f
        for (i in 0 until 16) {
            val z1 = i * period - (dist % period) + 2.5f
            val z2 = z1 + 3f
            if (z1 <= 0.5f) continue
            val y1 = yAt(z1, hor, fh)
            val y2 = yAt(z2, hor, fh)
            val s1 = (y1 - hor) / (fh - hor)
            val s2 = (y2 - hor) / (fh - hor)
            for (lx in floatArrayOf(-0.33f, 0.33f)) {
                val x1 = roadX(lx, s1, fw)
                val x2 = roadX(lx, s2, fw)
                path.reset()
                path.moveTo(x1 - s1 * fw * 0.012f, y1)
                path.lineTo(x1 + s1 * fw * 0.012f, y1)
                path.lineTo(x2 + s2 * fw * 0.012f, y2)
                path.lineTo(x2 - s2 * fw * 0.012f, y2)
                path.close()
                c.drawPath(path, fill)
            }
        }

        // Алдағы көліктер (алыстан жақынға)
        cars.sortByDescending { it.z }
        for (car in cars) {
            val y = yAt(car.z, hor, fh)
            val s = (y - hor) / (fh - hor)
            val x = roadX(car.lane, s, fw)
            drawCar(c, x, y, s * fw * 0.30f, car.color, 0f)
        }

        // Өзіміздің көлік
        drawCar(c, fw * 0.5f, fh * 0.97f, fw * 0.30f, Color.rgb(240, 240, 250), steer * 6f)

        // Мәліметтер
        GameText.draw(c, "${(speed * 3).toInt()} км/сағ    ${score} м", fw * 0.5f, fh * 0.1f, fh * 0.045f, Color.WHITE)
        if (handsSeen == 0) {
            GameText.draw(c, "Екі қолды рульдей ұста да бұр", fw * 0.5f, fh * 0.3f, fh * 0.036f, Color.rgb(255, 230, 140))
        }
        if (crashT > 0L) {
            val a = (200 * (1f - (now - crashT) / 900f)).toInt().coerceIn(0, 200)
            fill.color = Color.argb(a, 255, 30, 30)
            c.drawRect(0f, 0f, fw, fh, fill)
            GameText.draw(c, "СОҚТЫҒЫСТЫҢ!", fw * 0.5f, fh * 0.5f, fh * 0.08f, Color.WHITE)
        }
    }

    /** Тереңдік z → экран y (перспектива). */
    private fun yAt(z: Float, hor: Float, fh: Float): Float = hor + (fh - hor) * (2.5f / z).coerceAtMost(1.2f)

    /** Жол координатасы lane (−1..1) → экран x, s — перспектива масштабы (0 көкжиек, 1 төмен). */
    private fun roadX(lane: Float, s: Float, fw: Float): Float = fw * 0.5f + (lane - playerX) * fw * 0.75f * s

    private fun drawCar(c: Canvas, x: Float, yBottom: Float, width: Float, color: Int, tilt: Float) {
        if (width < 2f) return
        val hgt = width * 0.55f
        c.save()
        c.rotate(tilt, x, yBottom)
        fill.color = Color.rgb(20, 20, 20)
        rect.set(x - width * 0.48f, yBottom - hgt * 0.35f, x - width * 0.30f, yBottom)
        c.drawRect(rect, fill)
        rect.set(x + width * 0.30f, yBottom - hgt * 0.35f, x + width * 0.48f, yBottom)
        c.drawRect(rect, fill)
        fill.color = color
        rect.set(x - width / 2f, yBottom - hgt * 0.75f, x + width / 2f, yBottom - hgt * 0.15f)
        c.drawRoundRect(rect, width * 0.08f, width * 0.08f, fill)
        rect.set(x - width * 0.33f, yBottom - hgt, x + width * 0.33f, yBottom - hgt * 0.6f)
        c.drawRoundRect(rect, width * 0.08f, width * 0.08f, fill)
        fill.color = Color.argb(220, 150, 200, 240)
        rect.set(x - width * 0.27f, yBottom - hgt * 0.95f, x + width * 0.27f, yBottom - hgt * 0.68f)
        c.drawRect(rect, fill)
        fill.color = Color.rgb(255, 60, 60)
        rect.set(x - width * 0.44f, yBottom - hgt * 0.55f, x - width * 0.30f, yBottom - hgt * 0.42f)
        c.drawRect(rect, fill)
        rect.set(x + width * 0.30f, yBottom - hgt * 0.55f, x + width * 0.44f, yBottom - hgt * 0.42f)
        c.drawRect(rect, fill)
        c.restore()
    }
}
