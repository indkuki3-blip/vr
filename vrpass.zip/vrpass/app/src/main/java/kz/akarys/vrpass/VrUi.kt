package kz.akarys.vrpass

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.math.tan

/** Қосымшаның сыртқы әрекеттері (MainActivity іске асырады). */
interface VrHost {
    fun requestGalleryPermission()
    fun exitApp()
    fun webOpen(url: String): Boolean
    fun webNavigate(text: String)
    fun webBack()
    fun webReload()
    fun webClose()
    fun webTouch(action: Int, nx: Float, ny: Float)
    fun webScroll(dir: Int)
    fun webInsert(text: String, submit: Boolean)
    fun webSetLandscape(on: Boolean)
    fun voiceStart()
    fun voiceStop()
    fun recordToggle()
    fun screenshot()
}

/**
 * VR интерфейсі.
 * Басқару (Quest / Vision Pro идеясы бойынша):
 *  - «Көзқарас» режимі: экран ортасындағы нүкте — көздеу (басыңды бұрасың), кез келген қолмен шымшу — басу;
 *  - «Саусақ» режимі: курсор = сұқ саусақ, бірақ күшейткішпен (қол камераның ортасында қалады);
 *  - мәзірлер кеңістікте бекітіледі (гироскоп), батырмалар «магнит» сияқты тартады;
 *  - шымшып ұстап тұрсаң — ▲▼ / +− қайталанады; шымшып тартсаң — веб-бетті айналдыру;
 *  - жұдырық 0.6 с — мәзір / артқа. Басу кезінде «шырт» + діріл.
 */
class VrUi(
    private val state: VrState,
    private val host: VrHost,
    private val gallery: Gallery,
    private val sfx: Sfx
) {
    enum class Screen { HOME, MENU, EFFECTS, POWERS, GAMES, GAME, SETTINGS, GALLERY, WEB }

    @Volatile
    var screen = Screen.HOME
        private set

    private class Btn(val id: String, val rect: RectF, val repeatMs: Long)

    private val events = ConcurrentLinkedQueue<Int>()
    private val buttons = ArrayList<Btn>()
    private val hovered = HashSet<String>()
    private val lastPinch = BooleanArray(2)
    private var toast = ""
    private var toastUntil = 0L
    private val startTime = SystemClock.uptimeMillis()
    private var lastFrame = 0L
    private var lastDraw = 0L
    private var lastYaw = 0f
    private var lastPitch = 0f
    private var lastHadHands = false
    /** Экран ауысқанда / басылғанда — келесі кадрды міндетті түрде салу. */
    @Volatile private var forceRedraw = true
    private var settingsPage = 0

    // ---- бас және кеңістік
    private var headOn = false
    private var gaze = false
    private var yaw = 0f
    private var pitch = 0f
    private var anchorYaw = 0f
    private var anchorPitch = 0f
    private var homeYaw = 0f
    private var homePitch = 0f
    private var homeInit = false
    private var kx = 1f
    private var ky = 1f
    private var ox = 0f
    private var oy = 0f

    // ---- көрсеткіштер (саусақ режимі)
    private val ptrX = FloatArray(2)
    private val ptrY = FloatArray(2)

    // ---- ұстап тұру (қайталау)
    private var holdId: String? = null
    private var holdSlot = -1
    private var holdNext = 0L
    private var holdRepeat = 0L

    // ---- жұдырық жесті
    private val fistStart = LongArray(2)
    private val fistDone = BooleanArray(2)

    // ---- веб: шымшып тарту
    private var webPointer = -1
    private var webStartX = 0f
    private var webStartY = 0f
    private var tipStartX = 0f
    private var tipStartY = 0f
    private var webLastX = 0f
    private var webLastY = 0f

    // ---- пернетақта
    private var kbOpen = false
    /** Пернетақта нысанасы: 0 — мекенжай жолы, 1 — беттегі өріс, 2 — ноут IP. */
    private var kbTarget = 0
    private val kbText = StringBuilder()
    private var kbEn = false

    // ---- ойындар мен қабілеттер
    private val games: List<MiniGame> = listOf(
        BubbleGame(sfx), PianoGame(sfx), RaceGame(sfx), ShooterGame(sfx), HorrorGame(sfx)
    )
    private var game: MiniGame? = null
    private var bestSaved = false
    private val powers = Powers(sfx)
    private var powerPicker = true

    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private var statusText = ""
    private var statusAt = 0L

    private var w = 1f
    private var h = 1f
    private var hands: List<EyeHand> = emptyList()

    private val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(215, 12, 16, 28) }
    private val btnPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val cursorPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val textC = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val textL = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.LEFT
        typeface = Typeface.DEFAULT
    }
    private val tmp = RectF()

    fun post(event: Int) {
        events.add(event)
    }

    // ================================================================ кадр
    /**
     * Интерфейсті салу. Қайтарады: сурет өзгерді ме (өзгермесе — GPU-ға қайта жүктелмейді).
     * Оптимизация: ештеңе қозғалмаса (бас, қол, анимация, хабарлама) — салу мүлде өткізіледі.
     */
    fun draw(c: Canvas, width: Int, height: Int): Boolean {
        val now = SystemClock.uptimeMillis()
        if (width.toFloat() == w && height.toFloat() == h && !needsRedraw(now)) return false
        lastDraw = now
        forceRedraw = false
        lastYaw = state.headYaw
        lastPitch = state.headPitch
        w = width.toFloat()
        h = height.toFloat()
        val dt = if (lastFrame == 0L) 0.033f else min(0.1f, (now - lastFrame) / 1000f)
        lastFrame = now
        c.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)

        while (true) {
            val ev = events.poll() ?: break
            handleEvent(ev, now)
        }

        hands = buildHands(now)
        updateHead(dt)
        consumeMessages(now)
        state.webOn = screen == Screen.WEB

        // Көрсеткіштер (саусақ режимі): күшейткішпен
        for (hd in hands) {
            ptrX[hd.slot] = (0.5f + (hd.cx - 0.5f) * GAIN).coerceIn(0f, 1f)
            ptrY[hd.slot] = (0.55f + (hd.cy - 0.55f) * GAIN).coerceIn(0f, 1f)
        }

        buttons.clear()
        when (screen) {
            Screen.HOME -> drawHome(c, now)
            Screen.MENU -> drawMenu(c)
            Screen.EFFECTS -> drawEffects(c)
            Screen.POWERS -> drawPowers(c, now)
            Screen.GAMES -> drawGames(c)
            Screen.GAME -> drawGame(c, now)
            Screen.SETTINGS -> drawSettings(c)
            Screen.GALLERY -> drawGallery(c)
            Screen.WEB -> drawWeb(c)
        }
        if (screen == Screen.HOME || screen == Screen.MENU) drawStatus(c, now)

        interact(now)
        gestures(now)

        if (state.showFps) drawFps(c)
        lastHadHands = hands.isNotEmpty()
        if (state.recording) drawRec(c, now)
        if (state.cameraStatus.isNotEmpty()) message(c, state.cameraStatus, 0.5f, Color.rgb(255, 120, 120))
        if (now < toastUntil) drawToast(c)
        drawPointers(c, now)
        return true
    }

    private fun needsRedraw(now: Long): Boolean {
        if (forceRedraw) return true
        if (events.isNotEmpty()) return true
        if (now - lastDraw > 500L) return true
        if (screen == Screen.GAME || (screen == Screen.POWERS && !powerPicker)) return true
        if (now < toastUntil + 50L) return true
        if (abs(state.headYaw - lastYaw) > 0.001f || abs(state.headPitch - lastPitch) > 0.001f) return true
        val f = state.hands
        val handsNow = f.hands.isNotEmpty() && now - f.time < HAND_TIMEOUT_MS
        if (handsNow || lastHadHands) return true
        if (state.recording || state.voiceListening || state.webInputFocused) return true
        if (state.notice.isNotEmpty() || state.voiceError.isNotEmpty() || state.voiceFinal != null) return true
        return false
    }

    private fun drawFps(c: Canvas) {
        val src = if (state.remoteOn) {
            if (state.remoteStatus.startsWith("Қосылды")) "қол: ноут" else "қол: телефон"
        } else "қол: телефон"
        val q = arrayOf("жоғары", "орта", "төмен")[state.qualityLevel.coerceIn(0, 2)]
        val txt = String.format(Locale.US, "%.0f FPS · %.1f мс · %s · %s", state.fps, state.frameMs, src, q)
        textL.textSize = h * 0.026f
        val tw = textL.measureText(txt)
        tmp.set(w * 0.98f - tw - h * 0.02f, h * 0.88f, w * 0.98f, h * 0.93f)
        c.drawRoundRect(tmp, h * 0.01f, h * 0.01f, panelPaint)
        textL.color = if (state.fps < 24f) Color.rgb(255, 140, 120) else Color.rgb(140, 255, 160)
        c.drawText(txt, w * 0.98f - tw - h * 0.01f, h * 0.915f, textL)
        textL.color = Color.WHITE
    }

    /** Камера координатасындағы қолдарды HUD координатасына айналдырады, шымшу сәттерін табады. */
    private fun buildHands(now: Long): List<EyeHand> {
        val frame = state.hands
        val result = ArrayList<EyeHand>(2)
        val seen = BooleanArray(2)
        if (state.trackerReady && now - frame.time < HAND_TIMEOUT_MS) {
            val inv = state.inverseTurns()
            val tmp2 = FloatArray(4)
            val asp = w / h
            for (rh in frame.hands) {
                val s = rh.slot
                if (s !in 0..1) continue
                val pts = FloatArray(42)
                for (i in 0 until 21) state.toEye(rh.xs[i], rh.ys[i], inv, pts, i * 2)
                state.toEye(rh.tipX, rh.tipY, inv, tmp2, 0)
                val cx = tmp2[0]
                val cy = tmp2[1]
                // Алақан ортасы
                var px = 0f
                var py = 0f
                for (i in intArrayOf(0, 5, 9, 13, 17)) {
                    px += pts[i * 2]
                    py += pts[i * 2 + 1]
                }
                px /= 5f
                py /= 5f
                val size = hypot((pts[18] - pts[0]) * asp, pts[19] - pts[1])
                val angle = atan2(pts[19] - pts[1], (pts[18] - pts[0]) * asp)
                // Алақан нормалінің экрандағы бағыты (бұру мен қырқуды ескеріп)
                val pcx = (rh.xs[0] + rh.xs[9]) / 2f
                val pcy = (rh.ys[0] + rh.ys[9]) / 2f
                state.toEye(pcx, pcy, inv, tmp2, 0)
                state.toEye(pcx + rh.normX / rh.imgAspect * 0.05f, pcy + rh.normY * 0.05f, inv, tmp2, 2)
                var dx = (tmp2[2] - tmp2[0]) * asp
                var dy = tmp2[3] - tmp2[1]
                val dl = sqrt(dx * dx + dy * dy)
                val nxy = sqrt(rh.normX * rh.normX + rh.normY * rh.normY)
                if (dl > 1e-6f) {
                    dx = dx / dl * nxy
                    dy = dy / dl * nxy
                } else {
                    dx = 0f
                    dy = 0f
                }
                val down = rh.pinch && !lastPinch[s]
                val up = !rh.pinch && lastPinch[s]
                lastPinch[s] = rh.pinch
                seen[s] = true
                result.add(EyeHand(s, pts, cx, cy, rh.pinch, down, up, rh.fist, px, py, size, angle, dx, dy, rh.normZ))
            }
        }
        for (s in 0..1) if (!seen[s]) lastPinch[s] = false
        return result
    }

    // ================================================================ бас және кеңістік
    private fun updateHead(dt: Float) {
        headOn = state.gyroOn && state.headValid
        gaze = state.controlGaze && headOn
        yaw = state.headYaw
        pitch = state.headPitch
        if (!homeInit && headOn) {
            homeInit = true
            homeYaw = yaw
            homePitch = pitch
            anchorYaw = yaw
            anchorPitch = pitch
        }
        // Басты бұрғанда «МӘЗІР» батырмасы ақырын соңыңнан ереді (Quest сияқты)
        val dyh = wrap(yaw - homeYaw)
        if (abs(dyh) > 0.4f) homeYaw += dyh * min(1f, dt * 2.5f)
        val dph = pitch - homePitch
        if (abs(dph) > 0.3f) homePitch += dph * min(1f, dt * 2.5f)

        val turns = state.camQuarterTurns()
        val tanX = if (turns % 2 == 0) state.camTanW else state.camTanH
        val tanY = if (turns % 2 == 0) state.camTanH else state.camTanW
        kx = state.zoom / state.cropU / (2f * tanX.coerceAtLeast(0.1f))
        ky = state.zoom / state.cropV / (2f * tanY.coerceAtLeast(0.1f))
    }

    private fun recenter() {
        anchorYaw = yaw
        anchorPitch = pitch
        homeYaw = yaw
        homePitch = pitch
    }

    /** Кеңістікке бекітілген салуды бастау: канвасты бас бұрылысына қарама-қарсы жылжытамыз. */
    private fun beginWorld(c: Canvas, aYaw: Float, aPitch: Float) {
        if (headOn) {
            val dy = wrap(yaw - aYaw).coerceIn(-1.2f, 1.2f)
            val dp = (pitch - aPitch).coerceIn(-1.2f, 1.2f)
            ox = -tan(dy) * kx * w
            oy = tan(dp) * ky * h
        } else {
            ox = 0f
            oy = 0f
        }
        c.save()
        c.translate(ox, oy)
    }

    private fun endWorld(c: Canvas) {
        c.restore()
        ox = 0f
        oy = 0f
    }

    private fun setScreen(s: Screen) {
        if (screen == Screen.POWERS && s != Screen.POWERS) powers.stopSounds()
        if (screen == Screen.SETTINGS && s != Screen.SETTINGS) kbOpen = false
        if (screen == Screen.WEB && s != Screen.WEB) {
            kbOpen = false
            if (state.voiceListening) host.voiceStop()
        }
        screen = s
        recenter()
        forceRedraw = true
    }

    private fun consumeMessages(now: Long) {
        val n = state.notice
        if (n.isNotEmpty()) {
            state.notice = ""
            showToast(n, now, 2500L)
        }
        val e = state.voiceError
        if (e.isNotEmpty()) {
            state.voiceError = ""
            showToast(e, now, 2500L)
        }
        val fin = state.voiceFinal
        if (fin != null) {
            state.voiceFinal = null
            if (kbOpen) {
                if (kbText.isNotEmpty() && !kbText.endsWith(" ")) kbText.append(' ')
                kbText.append(fin)
            }
        }
        if (state.webInputFocused) {
            state.webInputFocused = false
            if (screen == Screen.WEB && !kbOpen) openKeyboard(KB_PAGE)
        }
    }

    // ================================================================ өзара әрекет
    private fun target(hd: EyeHand): Pair<Float, Float> =
        if (gaze) Pair(0.5f, 0.5f) else Pair(ptrX[hd.slot], ptrY[hd.slot])

    /** Батырманы табу: «магнит» — шетінен сәл сыртта болса да ең жақынын алады. */
    private fun hit(x: Float, y: Float): Btn? {
        val m = h * 0.025f
        var best: Btn? = null
        var bestD = Float.MAX_VALUE
        for (b in buttons) {
            val r = b.rect
            if (x >= r.left - m && x <= r.right + m && y >= r.top - m && y <= r.bottom + m) {
                val inside = x >= r.left && x <= r.right && y >= r.top && y <= r.bottom
                val d = hypot(x - r.centerX(), y - r.centerY()) * (if (inside) 0.5f else 1f)
                if (d < bestD) {
                    bestD = d
                    best = b
                }
            }
        }
        return best
    }

    private fun interact(now: Long) {
        hovered.clear()
        if (gaze) {
            hit(w * 0.5f, h * 0.5f)?.let { hovered.add(it.id) }
        } else {
            for (hd in hands) hit(ptrX[hd.slot] * w, ptrY[hd.slot] * h)?.let { hovered.add(it.id) }
        }

        var clickId: String? = null
        for (hd in hands) {
            val (tx, ty) = target(hd)
            if (hd.pinchDown) {
                val b = hit(tx * w, ty * h)
                if (b != null) {
                    if (clickId == null) {
                        clickId = b.id
                        if (b.repeatMs > 0L) {
                            holdId = b.id
                            holdSlot = hd.slot
                            holdRepeat = b.repeatMs
                            holdNext = now + 450L
                        }
                    }
                } else if (screen == Screen.WEB && webPointer < 0) {
                    startWebDrag(hd, tx, ty)
                }
            }
        }

        // Ұстап тұру — қайталау
        val hs = holdSlot
        if (hs >= 0) {
            val hd = hands.firstOrNull { it.slot == hs }
            if (hd == null || !hd.pinch) {
                holdSlot = -1
                holdId = null
            } else if (now >= holdNext) {
                holdNext = now + holdRepeat
                holdId?.let { click(it, now, false) }
            }
        }

        if (screen == Screen.WEB) updateWebDrag()
        if (clickId != null) {
            sfx.click()
            click(clickId, now, true)
        }
    }

    private fun gestures(now: Long) {
        val allowed = screen != Screen.GAME && !(screen == Screen.POWERS && !powerPicker)
        for (s in 0..1) {
            val hd = hands.firstOrNull { it.slot == s }
            if (hd == null || !hd.fist || !allowed) {
                fistStart[s] = 0L
                fistDone[s] = false
                continue
            }
            if (fistStart[s] == 0L) fistStart[s] = now
            if (!fistDone[s] && now - fistStart[s] > FIST_MS) {
                fistDone[s] = true
                sfx.click()
                when (screen) {
                    Screen.HOME -> setScreen(Screen.MENU)
                    Screen.MENU -> setScreen(Screen.HOME)
                    Screen.WEB -> if (kbOpen) kbOpen = false else {
                        host.webClose()
                        setScreen(Screen.MENU)
                    }
                    Screen.POWERS -> setScreen(Screen.MENU)
                    Screen.SETTINGS -> if (kbOpen) kbOpen = false else setScreen(Screen.MENU)
                    else -> setScreen(Screen.MENU)
                }
            }
        }
    }

    // ================================================================ оқиғалар
    private fun handleEvent(ev: Int, now: Long) {
        when (ev) {
            EV_MENU -> {
                if (screen == Screen.WEB) host.webClose()
                setScreen(
                    when (screen) {
                        Screen.HOME -> Screen.MENU
                        Screen.MENU -> Screen.SETTINGS
                        else -> Screen.HOME
                    }
                )
            }
            EV_NEXT -> when (screen) {
                Screen.GALLERY -> gallery.step(1)
                // Қол істемесе де бұруға болсын: Баптауда дыбыс «+» камераны 90° бұрады
                Screen.SETTINGS -> {
                    state.rotUser = (state.rotUser + 1) % 4
                    showToast("Камера: ${state.camQuarterTurns() * 90}°", now, 1800L)
                }
                Screen.WEB -> host.webScroll(1)
                else -> nextEffect(now)
            }
            EV_BACK -> when (screen) {
                Screen.WEB -> if (kbOpen) kbOpen = false else host.webBack()
                Screen.SETTINGS, Screen.GAMES, Screen.EFFECTS, Screen.POWERS -> setScreen(Screen.MENU)
                Screen.GAME -> setScreen(Screen.GAMES)
                else -> setScreen(Screen.HOME)
            }
        }
    }

    private fun click(id: String, now: Long, first: Boolean) {
        forceRedraw = true
        when {
            id == "menu" -> setScreen(Screen.MENU)
            id == "close" -> setScreen(Screen.HOME)
            id == "tomenu" -> setScreen(Screen.MENU)
            id == "effects" -> setScreen(Screen.EFFECTS)
            id == "powers" -> {
                powerPicker = true
                setScreen(Screen.POWERS)
            }
            id == "gallery" -> openGallery()
            id == "games" -> setScreen(Screen.GAMES)
            id == "browser" -> openWeb("https://www.google.com/", true, now)
            id == "youtube" -> openWeb("https://m.youtube.com/", true, now)
            id == "tiktok" -> openWeb("https://www.tiktok.com/foryou", false, now)
            id == "record" -> {
                host.recordToggle()
                setScreen(Screen.HOME)
            }
            id == "shot" -> {
                setScreen(Screen.HOME)
                host.screenshot()
            }
            id == "settings" -> setScreen(Screen.SETTINGS)
            id == "recenter" -> {
                recenter()
                showToast("Ортаға қойылды", now, 1200L)
            }
            id == "exit" -> host.exitApp()
            id == "dist-" -> state.distortion = (state.distortion - 0.05f).coerceIn(0f, 0.6f)
            id == "dist+" -> state.distortion = (state.distortion + 0.05f).coerceIn(0f, 0.6f)
            id == "ipd-" -> state.ipdMm = (state.ipdMm - 1f).coerceIn(50f, 75f)
            id == "ipd+" -> state.ipdMm = (state.ipdMm + 1f).coerceIn(50f, 75f)
            id == "zoom-" -> state.zoom = (state.zoom - 0.05f).coerceIn(0.5f, 1.5f)
            id == "zoom+" -> state.zoom = (state.zoom + 0.05f).coerceIn(0.5f, 1.5f)
            id == "rot" -> state.rotUser = (state.rotUser + 1) % 4
            id == "ctl" -> state.controlGaze = !state.controlGaze
            id == "spage0" -> {
                settingsPage = 0
                kbOpen = false
            }
            id == "spage1" -> settingsPage = 1
            id == "remote" -> state.remoteOn = !state.remoteOn
            id == "ipedit" -> openKeyboard(KB_IP)
            id == "quality" -> state.quality = (state.quality + 1) % 4
            id == "fps" -> state.showFps = !state.showFps
            id == "gyro" -> {
                state.gyroOn = !state.gyroOn
                recenter()
            }
            id == "vlang" -> state.voiceLang = when (state.voiceLang) {
                "kk-KZ" -> "ru-RU"
                "ru-RU" -> "en-US"
                else -> "kk-KZ"
            }
            id == "prev" -> gallery.step(-1)
            id == "next" -> gallery.step(1)
            id == "gperm" -> host.requestGalleryPermission()
            id == "again" -> startGame(game, now)
            id == "gquit" -> setScreen(Screen.GAMES)
            // ---- веб
            id == "wback" -> host.webBack()
            id == "wreload" -> host.webReload()
            id == "wrot" -> host.webSetLandscape(!state.webLandscape)
            id == "wup" -> host.webScroll(-1)
            id == "wdown" -> host.webScroll(1)
            id == "wclose" -> {
                host.webClose()
                setScreen(Screen.MENU)
            }
            id == "addr" -> openKeyboard(KB_ADDR)
            id == "addrmic" -> {
                openKeyboard(KB_ADDR)
                host.voiceStart()
            }
            id.startsWith("bm:") -> host.webOpen(id.substring(3))
            // ---- пернетақта
            id.startsWith("k:") -> keyPress(id.substring(2), first)
            // ---- эффектілер, ойындар, қабілеттер
            id.startsWith("fx:") -> {
                state.effect = id.substring(3).toIntOrNull()?.coerceIn(0, state.effectNames.size - 1) ?: 0
            }
            id.startsWith("g:") -> startGame(games.firstOrNull { it.id == id.substring(2) }, now)
            id.startsWith("p:") -> {
                val k = Powers.Kind.values().firstOrNull { it.name == id.substring(2) }
                if (k != null) {
                    powers.select(k)
                    powerPicker = false
                }
            }
            id == "ppick" -> {
                powers.stopSounds()
                powerPicker = true
                recenter()
            }
        }
    }

    private fun startGame(g: MiniGame?, now: Long) {
        if (g == null) return
        game = g
        bestSaved = false
        g.start(now)
        setScreen(Screen.GAME)
    }

    private fun nextEffect(now: Long) {
        state.effect = (state.effect + 1) % state.effectNames.size
        showToast("Эффект: " + state.effectNames[state.effect], now, 1500L)
    }

    private fun openGallery() {
        if (gallery.permitted && !gallery.loaded) gallery.load()
        setScreen(Screen.GALLERY)
    }

    private fun openWeb(url: String, landscape: Boolean, now: Long) {
        host.webSetLandscape(landscape)
        if (host.webOpen(url)) {
            webPointer = -1
            kbOpen = false
            setScreen(Screen.WEB)
        } else {
            showToast("Веб-панель ашылмады", now, 2000L)
        }
    }

    private fun showToast(s: String, now: Long, ms: Long) {
        toast = s
        toastUntil = now + ms
    }

    // ================================================================ веб-панель
    private fun panelRectWorld(): FloatArray {
        val l: Float
        val t = 0.14f
        val r: Float
        val b: Float
        if (state.webLandscape) {
            val pw = 0.66f
            val ph = pw * w / h * (WebPanel.SHORT.toFloat() / WebPanel.LONG)
            l = 0.5f - pw / 2f
            r = 0.5f + pw / 2f
            b = t + ph
        } else {
            val ph = 0.70f
            val pw = ph * h * (WebPanel.SHORT.toFloat() / WebPanel.LONG) / w
            l = 0.5f - pw / 2f
            r = 0.5f + pw / 2f
            b = t + ph
        }
        return floatArrayOf(l, t, r, b)
    }

    private fun drawWeb(c: Canvas) {
        val p = panelRectWorld()
        beginWorld(c, anchorYaw, anchorPitch)
        // Панельдің экрандағы орны (шейдер үшін)
        state.panelL = p[0] + ox / w
        state.panelT = p[1] + oy / h
        state.panelR = p[2] + ox / w
        state.panelB = p[3] + oy / h

        tmp.set(p[0] * w - 3f, p[1] * h - 3f, p[2] * w + 3f, p[3] * h + 3f)
        linePaint.color = Color.argb(160, 120, 170, 255)
        linePaint.strokeWidth = h * 0.005f
        c.drawRoundRect(tmp, h * 0.01f, h * 0.01f, linePaint)

        // Мекенжай жолы + микрофон
        val url = state.webUrl.removePrefix("https://").removePrefix("http://").removePrefix("www.")
        val shown = if (url.length > 34) url.substring(0, 33) + "…" else url
        button(c, "addr", "🔍  " + (if (shown.isEmpty()) "Іздеу немесе сайт адресі" else shown), 0.18f, 0.03f, 0.73f, 0.115f)
        button(c, "addrmic", "🎤", 0.745f, 0.03f, 0.83f, 0.115f, true)

        // Сол бағана
        val lc = p[0] - 0.135f
        button(c, "wback", "←\nАртқа", lc, 0.16f, p[0] - 0.02f, 0.29f, true)
        button(c, "wreload", "⟳\nЖаңарту", lc, 0.31f, p[0] - 0.02f, 0.44f)
        button(c, "wrot", "⇄\n" + (if (state.webLandscape) "Тік" else "Көлденең"), lc, 0.46f, p[0] - 0.02f, 0.59f)
        // Оң бағана
        val rc = p[2] + 0.02f
        button(c, "wup", "▲", rc, 0.16f, rc + 0.115f, 0.31f, true, 420L)
        button(c, "wdown", "▼", rc, 0.33f, rc + 0.115f, 0.48f, true, 420L)
        button(c, "wclose", "✕\nЖабу", rc, 0.50f, rc + 0.115f, 0.62f)

        // Бетбелгілер
        val bmY = p[3] + 0.02f
        val marks = listOf(
            "Google" to "https://www.google.com/", "YouTube" to "https://m.youtube.com/",
            "TikTok" to "https://www.tiktok.com/foryou", "Wiki" to "https://kk.wikipedia.org/"
        )
        val bw = 0.15f
        val startX = 0.5f - (marks.size * bw + (marks.size - 1) * 0.015f) / 2f
        for ((i, m) in marks.withIndex()) {
            val l = startX + i * (bw + 0.015f)
            button(c, "bm:" + m.second, m.first, l, bmY, l + bw, bmY + 0.07f)
        }

        if (kbOpen) drawKeyboard(c)
        endWorld(c)
    }

    private fun startWebDrag(hd: EyeHand, tx: Float, ty: Float) {
        if (kbOpen) return
        val nx = (tx - state.panelL) / (state.panelR - state.panelL)
        val ny = (ty - state.panelT) / (state.panelB - state.panelT)
        if (nx !in 0f..1f || ny !in 0f..1f) return
        webPointer = hd.slot
        webStartX = nx
        webStartY = ny
        webLastX = nx
        webLastY = ny
        tipStartX = hd.cx
        tipStartY = hd.cy
        host.webTouch(MotionEvent.ACTION_DOWN, nx, ny)
    }

    /** Шымшып тұрып қолды жылжытсаң — бетті сүйрейсің (айналдыру, свайп). */
    private fun updateWebDrag() {
        val wp = webPointer
        if (wp < 0) return
        val hd = hands.firstOrNull { it.slot == wp }
        if (hd == null || !hd.pinch) {
            host.webTouch(MotionEvent.ACTION_UP, webLastX, webLastY)
            webPointer = -1
            return
        }
        val pw = state.panelR - state.panelL
        val ph = state.panelB - state.panelT
        val nx = (webStartX + (hd.cx - tipStartX) * DRAG_GAIN / pw).coerceIn(0f, 1f)
        val ny = (webStartY + (hd.cy - tipStartY) * DRAG_GAIN / ph).coerceIn(0f, 1f)
        if (abs(nx - webLastX) > 0.003f || abs(ny - webLastY) > 0.003f) {
            webLastX = nx
            webLastY = ny
            host.webTouch(MotionEvent.ACTION_MOVE, nx, ny)
        }
    }

    // ================================================================ пернетақта
    private fun openKeyboard(target: Int) {
        kbOpen = true
        kbTarget = target
        kbText.setLength(0)
        if (target == KB_IP) {
            kbText.append(state.remoteIp)
            kbEn = true
        }
    }

    private fun keyPress(k: String, first: Boolean) {
        when (k) {
            "back" -> if (kbText.isNotEmpty()) kbText.setLength(kbText.length - 1)
            "space" -> kbText.append(' ')
            "lang" -> kbEn = !kbEn
            "close" -> {
                kbOpen = false
                if (state.voiceListening) host.voiceStop()
            }
            "mic" -> if (first) {
                if (state.voiceListening) host.voiceStop() else host.voiceStart()
            }
            "ok", "enter" -> {
                val text = kbText.toString()
                when (kbTarget) {
                    KB_PAGE -> host.webInsert(text, k == "enter")
                    KB_IP -> state.remoteIp = text.trim()
                    else -> host.webNavigate(text)
                }
                kbOpen = false
                if (state.voiceListening) host.voiceStop()
            }
            else -> if (kbText.length < 200) kbText.append(k)
        }
    }

    private fun drawKeyboard(c: Canvas) {
        tmp.set(0.04f * w, 0.30f * h, 0.96f * w, 0.985f * h)
        c.drawRoundRect(tmp, h * 0.025f, h * 0.025f, panelPaint)
        linePaint.color = Color.argb(140, 120, 170, 255)
        linePaint.strokeWidth = h * 0.004f
        c.drawRoundRect(tmp, h * 0.025f, h * 0.025f, linePaint)

        // Мәтін өрісі
        tmp.set(0.07f * w, 0.32f * h, 0.80f * w, 0.405f * h)
        btnPaint.color = Color.argb(240, 245, 245, 250)
        c.drawRoundRect(tmp, h * 0.012f, h * 0.012f, btnPaint)
        val typed = kbText.toString()
        val partial = if (state.voiceListening) state.voicePartial else ""
        textL.textSize = h * 0.038f
        textL.color = Color.rgb(20, 24, 32)
        var shown = typed + (if (partial.isNotEmpty()) " $partial" else "") + "|"
        while (textL.measureText(shown) > 0.71f * w && shown.length > 2) shown = shown.substring(1)
        if (typed.isEmpty() && partial.isEmpty()) {
            textL.color = Color.rgb(130, 135, 150)
            shown = when (kbTarget) {
                KB_PAGE -> "Бетке жазу…"
                KB_IP -> "Бос қалдырсаң — өзі іздейді"
                else -> "Іздеу немесе сайт адресі…"
            }
        }
        c.drawText(shown, 0.085f * w, 0.375f * h, textL)
        textL.color = Color.WHITE

        val micLabel = if (state.voiceListening) "● Тыңдап тұр" else "🎤 Айту"
        button(c, "k:mic", micLabel, 0.815f, 0.32f, 0.94f, 0.405f, true)
        if (state.voiceListening) {
            tmp.set(0.815f * w, 0.41f * h, (0.815f + 0.125f * state.voiceLevel) * w, 0.418f * h)
            btnPaint.color = Color.rgb(90, 220, 140)
            c.drawRect(tmp, btnPaint)
        }

        val rows = if (kbEn) {
            listOf("1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm.,", "@-_/:?!")
        } else {
            listOf("1234567890", "йцукенгшщзхъ", "әғқңөұүһі", "фывапролджэ", "ячсмитьбю.,")
        }
        val rowH = 0.075f
        for ((ri, row) in rows.withIndex()) {
            val n = row.length
            val kw = min(0.072f, 0.88f / n - 0.006f)
            val total = n * kw + (n - 1) * 0.006f
            val sx = 0.5f - total / 2f
            val top = 0.43f + ri * (rowH + 0.008f)
            for (i in 0 until n) {
                val ch = row[i].toString()
                val l = sx + i * (kw + 0.006f)
                button(c, "k:$ch", ch, l, top, l + kw, top + rowH)
            }
        }
        val by = 0.43f + rows.size * (rowH + 0.008f)
        button(c, "k:lang", if (kbEn) "ҚАЗ" else "EN", 0.06f, by, 0.17f, by + rowH)
        button(c, "k:space", "␣ бос орын", 0.18f, by, 0.50f, by + rowH)
        button(c, "k:back", "⌫", 0.51f, by, 0.60f, by + rowH, false, 120L)
        button(c, "k:ok", "✓", 0.61f, by, 0.69f, by + rowH, true)
        button(c, "k:enter", "⏎ Іздеу", 0.70f, by, 0.85f, by + rowH, true)
        button(c, "k:close", "✕", 0.86f, by, 0.94f, by + rowH)
    }

    // ================================================================ экрандар
    private fun drawHome(c: Canvas, now: Long) {
        beginWorld(c, homeYaw, homePitch)
        button(c, "menu", "☰  МӘЗІР", 0.36f, 0.70f, 0.64f, 0.81f, true)
        endWorld(c)
        if (now - startTime < 12_000L) {
            panel(c, 0.06f, 0.40f, 0.94f, 0.64f)
            val lines = if (gaze) listOf(
                "Батырмаға басыңды бұрып қара (ортадағы нүкте)",
                "Бас бармақ + сұқ саусақты түйістір — басу",
                "Жұдырық 1 сек — мәзір  ·  Дыбыс − — мәзір"
            ) else listOf(
                "Сұқ саусақ — курсор (екі қол да)",
                "Бас бармақ + сұқ саусақты түйістір — басу",
                "Жұдырық 1 сек — мәзір  ·  Дыбыс − — мәзір"
            )
            textC.textSize = h * 0.029f
            for ((i, s) in lines.withIndex()) c.drawText(s, w * 0.5f, h * (0.47f + i * 0.055f), textC)
        }
    }

    private fun drawMenu(c: Canvas) {
        beginWorld(c, anchorYaw, anchorPitch)
        panel(c, 0.07f, 0.08f, 0.93f, 0.95f)
        title(c, "VR МӘЗІР", 0.155f)
        button(c, "close", "✕", 0.84f, 0.10f, 0.91f, 0.17f)
        cellButton(c, "effects", "Эффекттер\n" + state.effectNames[state.effect], 0, 0, true)
        cellButton(c, "powers", "Қабілеттер\n🌀⚡🔥", 1, 0, true)
        cellButton(c, "games", "Ойындар", 2, 0, true)
        cellButton(c, "browser", "Браузер", 0, 1)
        cellButton(c, "youtube", "YouTube", 1, 1)
        cellButton(c, "tiktok", "TikTok", 2, 1)
        cellButton(c, "gallery", "Галерея", 0, 2)
        cellButton(c, "record", if (state.recording) "⏹ Тоқтату" else "📹 Видео жазу", 1, 2)
        cellButton(c, "shot", "📸 Сурет", 2, 2)
        cellButton(c, "settings", "Баптау", 0, 3)
        cellButton(c, "recenter", "⊙ Ортаға", 1, 3)
        cellButton(c, "exit", "Шығу", 2, 3)
        endWorld(c)
    }

    private fun cellButton(c: Canvas, id: String, label: String, col: Int, row: Int, accent: Boolean = false) {
        val left = 0.11f + col * 0.265f
        val top = 0.20f + row * 0.18f
        button(c, id, label, left, top, left + 0.25f, top + 0.155f, accent)
    }

    private fun drawEffects(c: Canvas) {
        beginWorld(c, anchorYaw, anchorPitch)
        panel(c, 0.05f, 0.05f, 0.95f, 0.97f)
        title(c, "ЭФФЕКТТЕР", 0.115f)
        button(c, "tomenu", "←", 0.07f, 0.065f, 0.15f, 0.135f)
        for ((i, name) in state.effectNames.withIndex()) {
            val col = i % 3
            val row = i / 3
            val l = 0.08f + col * 0.285f
            val t = 0.16f + row * 0.135f
            button(c, "fx:$i", name, l, t, l + 0.27f, t + 0.12f, i == state.effect)
        }
        endWorld(c)
    }

    private fun drawPowers(c: Canvas, now: Long) {
        if (powerPicker) {
            beginWorld(c, anchorYaw, anchorPitch)
            panel(c, 0.10f, 0.10f, 0.90f, 0.92f)
            title(c, "СУПЕРҚАБІЛЕТТЕР", 0.18f)
            button(c, "tomenu", "←", 0.12f, 0.12f, 0.20f, 0.19f)
            val kinds = Powers.Kind.values()
            val icons = arrayOf("🌀", "⚡", "💠", "🔥")
            for ((i, k) in kinds.withIndex()) {
                val col = i % 2
                val row = i / 2
                val l = 0.15f + col * 0.36f
                val t = 0.25f + row * 0.25f
                button(c, "p:" + k.name, icons[i] + "\n" + k.title, l, t, l + 0.34f, t + 0.22f, true)
            }
            textC.textSize = h * 0.028f
            textC.color = Color.rgb(170, 200, 240)
            c.drawText("Алақан аш — жанады · Жұдырық — сөнеді", w * 0.5f, h * 0.81f, textC)
            c.drawText("Қолды тез сілте — лақтыру (От шары, Сюрикен)", w * 0.5f, h * 0.86f, textC)
            textC.color = Color.WHITE
            endWorld(c)
            return
        }
        powers.update(now, hands, w / h)
        powers.draw(c, w.toInt(), h.toInt(), now)
        // Жоғарғы жолақ: қабілетті ауыстыру
        beginWorld(c, anchorYaw, anchorPitch)
        val kinds = Powers.Kind.values()
        val icons = arrayOf("🌀", "⚡", "💠", "🔥")
        for ((i, k) in kinds.withIndex()) {
            val l = 0.12f + i * 0.165f
            button(c, "p:" + k.name, icons[i] + " " + k.title, l, 0.03f, l + 0.155f, 0.10f, k == powers.kind)
        }
        button(c, "tomenu", "✕", 0.79f, 0.03f, 0.88f, 0.10f)
        endWorld(c)
        if (hands.isEmpty()) message(c, "Алақаныңды камераға көрсет", 0.9f, Color.rgb(200, 220, 255))
    }

    private fun drawGames(c: Canvas) {
        beginWorld(c, anchorYaw, anchorPitch)
        panel(c, 0.08f, 0.12f, 0.92f, 0.86f)
        title(c, "ОЙЫНДАР", 0.2f)
        button(c, "tomenu", "←", 0.10f, 0.14f, 0.18f, 0.21f)
        for ((i, g) in games.withIndex()) {
            val best = state.best(g.id)
            val label = if (g.id == "piano") g.title else g.title + "\nрекорд: $best"
            val col = i % 3
            val row = i / 3
            val l = 0.11f + col * 0.265f
            val t = 0.26f + row * 0.21f
            button(c, "g:" + g.id, label, l, t, l + 0.25f, t + 0.18f, true)
        }
        textC.textSize = h * 0.03f
        textC.color = Color.rgb(170, 200, 240)
        c.drawText("Екі қол да ойнайды", w * 0.5f, h * 0.81f, textC)
        textC.color = Color.WHITE
        endWorld(c)
    }

    private fun drawSettings(c: Canvas) {
        beginWorld(c, anchorYaw, anchorPitch)
        panel(c, 0.08f, 0.04f, 0.92f, 0.97f)
        // Беттер: Экран / Жылдамдық
        button(c, "spage0", "Экран", 0.12f, 0.06f, 0.42f, 0.13f, settingsPage == 0)
        button(c, "spage1", "⚡ Жылдамдық", 0.44f, 0.06f, 0.80f, 0.13f, settingsPage == 1)
        button(c, "tomenu", "✕", 0.82f, 0.06f, 0.89f, 0.13f)
        if (settingsPage == 0) {
            val ctl = if (state.controlGaze) "Көзқарас + шымшу" else "Саусақ курсоры"
            rowButton(c, 0, "ctl", "Басқару: $ctl")
            rowButton(c, 1, "gyro", "Мәзір кеңістікте бекітілген: " + (if (state.gyroOn) "ИӘ" else "ЖОҚ"))
            settingRow(c, 2, "Көз аралығы", "${state.ipdMm.toInt()} мм", "ipd")
            settingRow(c, 3, "Линза иілуі", String.format(Locale.US, "%.2f", state.distortion), "dist")
            settingRow(c, 4, "Масштаб", String.format(Locale.US, "%.2f", state.zoom), "zoom")
            rowButton(c, 5, "rot", "Камераны бұру (+90°): қазір ${state.camQuarterTurns() * 90}°")
            val lang = when (state.voiceLang) {
                "kk-KZ" -> "Қазақша"
                "ru-RU" -> "Русский"
                else -> "English"
            }
            rowButton(c, 6, "vlang", "Дауыспен жазу тілі: $lang")
        } else {
            rowButton(c, 0, "remote", "💻 Ноутпен есептеу: " + (if (state.remoteOn) "ҚОСУЛЫ" else "ӨШІК"), state.remoteOn)
            val st = if (state.remoteOn) state.remoteStatus.ifEmpty { "…" } else "Қол трекингі телефонда"
            textC.textSize = h * 0.03f
            textC.color = if (st.startsWith("Қосылды")) Color.rgb(120, 230, 150) else Color.rgb(255, 210, 130)
            c.drawText(st, w * 0.5f, h * (rowTop(1) + 0.055f), textC)
            textC.color = Color.WHITE
            val ip = state.remoteIp.ifEmpty { "автоматты" }
            rowButton(c, 2, "ipedit", "Ноут IP: $ip   (өзгерту)")
            val q = arrayOf("Авто", "Жоғары", "Орта", "Төмен")[state.quality]
            val applied = arrayOf("жоғары", "орта", "төмен")[state.qualityLevel.coerceIn(0, 2)]
            rowButton(c, 3, "quality", "Сапа: $q" + (if (state.quality == 0) "  (қазір: $applied)" else ""))
            rowButton(c, 4, "fps", "FPS көрсету: " + (if (state.showFps) "ИӘ" else "ЖОҚ"))
            textC.textSize = h * 0.028f
            textC.color = Color.rgb(170, 200, 240)
            c.drawText(String.format(Locale.US, "Қазір: %.0f FPS · кадрға %.1f мс", state.fps, state.frameMs), w * 0.5f, h * (rowTop(5) + 0.05f), textC)
            if (state.hot) c.drawText("🌡 Телефон қызып тұр — сапа азайтылды", w * 0.5f, h * (rowTop(6) + 0.02f), textC)
            textC.color = Color.WHITE
            if (kbOpen) drawKeyboard(c)
        }
        val t = rowTop(7)
        if (!kbOpen) button(c, "tomenu", "← Артқа", 0.38f, t, 0.62f, t + 0.08f, true)
        endWorld(c)
    }

    private fun rowTop(row: Int) = 0.16f + row * 0.097f

    private fun rowButton(c: Canvas, row: Int, id: String, label: String, accent: Boolean = false) {
        val t = rowTop(row)
        button(c, id, label, 0.13f, t, 0.87f, t + 0.085f, accent)
    }

    private fun settingRow(c: Canvas, row: Int, label: String, value: String, id: String) {
        val top = rowTop(row)
        val bottom = top + 0.085f
        val mid = (top + bottom) / 2f * h
        textL.textSize = h * 0.038f
        textL.color = Color.WHITE
        c.drawText(label, w * 0.14f, mid + h * 0.013f, textL)
        textL.color = Color.rgb(140, 200, 255)
        c.drawText(value, w * 0.46f, mid + h * 0.013f, textL)
        textL.color = Color.WHITE
        button(c, "$id-", "−", 0.62f, top, 0.73f, bottom, false, 220L)
        button(c, "$id+", "+", 0.76f, top, 0.87f, bottom, false, 220L)
    }

    private fun drawGallery(c: Canvas) {
        beginWorld(c, anchorYaw, anchorPitch)
        panel(c, 0.10f, 0.12f, 0.90f, 0.90f)
        if (!gallery.permitted) {
            message(c, "Суреттерді көру үшін рұқсат керек", 0.38f, Color.WHITE)
            button(c, "gperm", "Рұқсат беру", 0.30f, 0.48f, 0.70f, 0.60f, true)
            button(c, "tomenu", "Жабу", 0.38f, 0.70f, 0.62f, 0.80f)
            endWorld(c)
            return
        }
        if (!gallery.loaded) {
            if (!gallery.loading) gallery.load()
            message(c, "Жүктелуде…", 0.45f, Color.WHITE)
        } else if (gallery.uris.isEmpty()) {
            message(c, "Сурет табылмады", 0.45f, Color.WHITE)
        } else {
            val bmp: Bitmap? = gallery.current
            if (bmp != null) {
                val areaL = 0.13f * w
                val areaT = 0.15f * h
                val areaW = 0.74f * w
                val areaH = 0.59f * h
                val s = minOf(areaW / bmp.width, areaH / bmp.height)
                val dw = bmp.width * s
                val dh = bmp.height * s
                tmp.set(
                    areaL + (areaW - dw) / 2f, areaT + (areaH - dh) / 2f,
                    areaL + (areaW + dw) / 2f, areaT + (areaH + dh) / 2f
                )
                c.drawBitmap(bmp, null, tmp, bmpPaint)
            } else {
                message(c, "Жүктелуде…", 0.45f, Color.WHITE)
            }
            textC.textSize = h * 0.035f
            c.drawText("${gallery.index + 1} / ${gallery.uris.size}", w * 0.5f, h * 0.785f, textC)
        }
        button(c, "prev", "◀", 0.14f, 0.77f, 0.30f, 0.87f, true)
        button(c, "tomenu", "✕ Жабу", 0.39f, 0.80f, 0.61f, 0.88f)
        button(c, "next", "▶", 0.70f, 0.77f, 0.86f, 0.87f, true)
        endWorld(c)
    }

    private fun drawGame(c: Canvas, now: Long) {
        val g = game
        if (g == null) {
            setScreen(Screen.GAMES)
            return
        }
        g.update(now, hands, w / h)
        g.draw(c, w.toInt(), h.toInt(), now)
        if (g.finished) {
            if (!bestSaved) {
                bestSaved = true
                recenter()
                if (g.score > state.best(g.id)) state.setBest(g.id, g.score)
            }
            beginWorld(c, anchorYaw, anchorPitch)
            panel(c, 0.22f, 0.25f, 0.78f, 0.78f)
            title(c, "ОЙЫН БІТТІ!", 0.34f)
            textC.textSize = h * 0.05f
            c.drawText("Ұпай: ${g.score}", w * 0.5f, h * 0.45f, textC)
            textC.textSize = h * 0.036f
            c.drawText("Рекорд: ${state.best(g.id)}", w * 0.5f, h * 0.52f, textC)
            button(c, "again", "Қайта", 0.27f, 0.61f, 0.49f, 0.72f, true)
            button(c, "gquit", "Шығу", 0.51f, 0.61f, 0.73f, 0.72f)
            endWorld(c)
        } else {
            beginWorld(c, anchorYaw, anchorPitch)
            button(c, "gquit", "✕", 0.84f, 0.04f, 0.93f, 0.12f)
            endWorld(c)
        }
    }

    // ================================================================ сурет салу көмекшілері
    private fun drawStatus(c: Canvas, now: Long) {
        if (now - statusAt > 1000L) {
            statusAt = now
            val parts = ArrayList<String>()
            parts.add(timeFmt.format(Date()))
            if (state.battery >= 0) parts.add("${state.battery}%")
            parts.add(state.effectNames[state.effect])
            statusText = parts.joinToString("   ·   ")
        }
        val handsMark = when (hands.size) {
            0 -> "–"
            1 -> "✋"
            else -> "✋✋"
        }
        textC.textSize = h * 0.032f
        textC.color = Color.argb(230, 255, 255, 255)
        c.drawText("$statusText   ·   $handsMark", w * 0.5f, h * 0.06f, textC)
        textC.color = Color.WHITE
        if (state.remoteOn && screen == Screen.HOME) {
            textC.textSize = h * 0.026f
            textC.color = if (state.remoteStatus.startsWith("Қосылды")) Color.rgb(120, 230, 150) else Color.rgb(255, 210, 130)
            c.drawText("💻 " + state.remoteStatus, w * 0.5f, h * 0.15f, textC)
            textC.color = Color.WHITE
        }
        if (state.trackerStatus.isNotEmpty() && screen == Screen.HOME && !state.remoteOn) {
            textC.textSize = h * 0.028f
            textC.color = Color.rgb(255, 210, 120)
            c.drawText(state.trackerStatus, w * 0.5f, h * 0.105f, textC)
            textC.color = Color.WHITE
        }
    }

    private fun drawRec(c: Canvas, now: Long) {
        val sec = ((now - state.recordStart) / 1000L).toInt()
        val blink = (now / 500L) % 2L == 0L
        cursorPaint.style = Paint.Style.FILL
        cursorPaint.color = if (blink) Color.rgb(255, 50, 50) else Color.rgb(120, 20, 20)
        c.drawCircle(w * 0.2f, h * 0.15f, h * 0.014f, cursorPaint)
        textL.textSize = h * 0.03f
        textL.color = Color.rgb(255, 110, 110)
        c.drawText(String.format(Locale.US, "REC %02d:%02d", sec / 60, sec % 60), w * 0.22f, h * 0.162f, textL)
        textL.color = Color.WHITE
    }

    private fun panel(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        tmp.set(l * w, t * h, r * w, b * h)
        val rad = h * 0.03f
        c.drawRoundRect(tmp, rad, rad, panelPaint)
        linePaint.color = Color.argb(130, 120, 170, 255)
        linePaint.strokeWidth = h * 0.004f
        c.drawRoundRect(tmp, rad, rad, linePaint)
    }

    private fun title(c: Canvas, s: String, y: Float) {
        textC.textSize = h * 0.048f
        textC.color = Color.rgb(140, 200, 255)
        c.drawText(s, w * 0.5f, h * y, textC)
        textC.color = Color.WHITE
    }

    private fun message(c: Canvas, s: String, y: Float, color: Int) {
        textC.textSize = h * 0.036f
        textC.color = color
        c.drawText(s, w * 0.5f, h * y, textC)
        textC.color = Color.WHITE
    }

    private fun button(
        c: Canvas, id: String, label: String,
        l: Float, t: Float, r: Float, b: Float,
        accent: Boolean = false, repeatMs: Long = 0L
    ) {
        val rect = RectF(l * w, t * h, r * w, b * h)
        // Басу аймағы — экрандағы нақты орны (кеңістік жылжуымен)
        buttons.add(Btn(id, RectF(rect.left + ox, rect.top + oy, rect.right + ox, rect.bottom + oy), repeatMs))
        val hover = hovered.contains(id)
        btnPaint.color = when {
            hover -> Color.argb(245, 64, 156, 255)
            accent -> Color.argb(220, 36, 84, 160)
            else -> Color.argb(210, 40, 48, 66)
        }
        val rad = h * 0.02f
        if (hover) {
            // Үстінде тұрғанда сәл үлкейеді
            val g = h * 0.006f
            rect.set(rect.left - g, rect.top - g, rect.right + g, rect.bottom + g)
        }
        c.drawRoundRect(rect, rad, rad, btnPaint)
        if (hover) {
            linePaint.color = Color.WHITE
            linePaint.strokeWidth = h * 0.005f
            c.drawRoundRect(rect, rad, rad, linePaint)
        }
        drawLabel(c, label, rect)
    }

    /** Көп жолды мәтінді батырма ішіне сыйғызып ортасына жазу. */
    private fun drawLabel(c: Canvas, label: String, rect: RectF) {
        val lines = label.split("\n")
        var size = h * 0.04f
        textC.textSize = size
        val maxW = rect.width() * 0.88f
        for (s in lines) {
            val tw = textC.measureText(s)
            if (tw > maxW) size = minOf(size, size * maxW / tw)
        }
        val maxH = rect.height() * 0.8f / lines.size
        if (size > maxH) size = maxH
        textC.textSize = size
        val fm = textC.fontMetrics
        val lineH = size * 1.15f
        val firstY = rect.centerY() - lineH * (lines.size - 1) / 2f - (fm.ascent + fm.descent) / 2f
        for ((i, s) in lines.withIndex()) {
            textC.color = if (i == 0) Color.WHITE else Color.rgb(170, 215, 255)
            c.drawText(s, rect.centerX(), firstY + i * lineH, textC)
        }
        textC.color = Color.WHITE
    }

    private fun drawToast(c: Canvas) {
        textC.textSize = h * 0.038f
        val tw = textC.measureText(toast)
        val pad = h * 0.03f
        tmp.set(w * 0.5f - tw / 2f - pad, h * 0.62f, w * 0.5f + tw / 2f + pad, h * 0.705f)
        c.drawRoundRect(tmp, h * 0.02f, h * 0.02f, panelPaint)
        c.drawText(toast, w * 0.5f, h * 0.676f, textC)
    }

    /** Көздеу нүктесі (көзқарас режимі), саусақ курсорлары, жұдырық прогресі. */
    private fun drawPointers(c: Canvas, now: Long) {
        val anyPinch = hands.any { it.pinch }
        if (gaze) {
            val x = w * 0.5f
            val y = h * 0.5f
            val r = h * 0.018f
            val over = hovered.isNotEmpty()
            cursorPaint.style = Paint.Style.FILL
            cursorPaint.color = when {
                anyPinch -> Color.rgb(255, 210, 60)
                over -> Color.rgb(90, 170, 255)
                else -> Color.argb(220, 255, 255, 255)
            }
            c.drawCircle(x, y, if (over || anyPinch) r * 0.55f else r * 0.3f, cursorPaint)
            cursorPaint.style = Paint.Style.STROKE
            cursorPaint.strokeWidth = h * 0.005f
            c.drawCircle(x, y, if (over) r * 1.25f else r, cursorPaint)
            // Қол көрініп тұр ма — кішкене нүктелер
            for (hd in hands) {
                cursorPaint.style = Paint.Style.FILL
                cursorPaint.color = if (hd.pinch) Color.argb(220, 255, 210, 60) else Color.argb(150, 255, 255, 255)
                c.drawCircle(hd.cx * w, hd.cy * h, h * 0.008f, cursorPaint)
            }
        } else if (screen != Screen.GAME && !(screen == Screen.POWERS && !powerPicker)) {
            for (hd in hands) {
                val x = ptrX[hd.slot] * w
                val y = ptrY[hd.slot] * h
                val r = h * 0.022f
                cursorPaint.style = Paint.Style.FILL
                cursorPaint.color = if (hd.pinch) Color.rgb(255, 210, 60) else Color.argb(210, 255, 255, 255)
                c.drawCircle(x, y, if (hd.pinch) r * 0.7f else r * 0.35f, cursorPaint)
                cursorPaint.style = Paint.Style.STROKE
                cursorPaint.strokeWidth = h * 0.006f
                c.drawCircle(x, y, r, cursorPaint)
            }
        }
        // Жұдырық прогресі
        for (hd in hands) {
            val st = fistStart[hd.slot]
            if (st == 0L || fistDone[hd.slot]) continue
            val k = ((now - st) / FIST_MS.toFloat()).coerceIn(0f, 1f)
            if (k < 0.15f) continue
            val r = h * 0.04f
            tmp.set(hd.palmX * w - r, hd.palmY * h - r, hd.palmX * w + r, hd.palmY * h + r)
            cursorPaint.style = Paint.Style.STROKE
            cursorPaint.strokeWidth = h * 0.008f
            cursorPaint.color = Color.rgb(90, 170, 255)
            c.drawArc(tmp, -90f, 360f * k, false, cursorPaint)
        }
    }

    private fun wrap(a: Float): Float {
        var v = a
        while (v > 3.14159f) v -= 6.28318f
        while (v < -3.14159f) v += 6.28318f
        return v
    }

    companion object {
        const val EV_MENU = 1
        const val EV_NEXT = 2
        const val EV_BACK = 3
        private const val HAND_TIMEOUT_MS = 350L
        private const val GAIN = 1.7f
        private const val DRAG_GAIN = 1.6f
        private const val FIST_MS = 650L
        private const val KB_ADDR = 0
        private const val KB_PAGE = 1
        private const val KB_IP = 2
    }
}
