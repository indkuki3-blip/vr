package kz.akarys.vrpass

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue

/** Қосымшаның сыртқы әрекеттері (MainActivity іске асырады). */
interface VrHost {
    /** Тізімдегі алғашқы орнатылған қосымшаны ашады. Табылмаса — false. */
    fun launchApp(packages: List<String>): Boolean
    fun requestGalleryPermission()
    fun exitApp()
}

/**
 * VR интерфейсі: мәзір, баптау, галерея, ойын, курсор.
 * Бір көзге арналған мөлдір суретке (HUD) салынады, оны рендер екі көзге қояды.
 * Басу: сұқ саусақ пен бас бармақты түйістіру (шымшу) немесе батырманың үстінде 1.2 с ұстау.
 */
class VrUi(
    private val state: VrState,
    private val host: VrHost,
    private val gallery: Gallery
) {
    enum class Screen { HOME, MENU, SETTINGS, GALLERY, GAME }

    @Volatile
    var screen = Screen.HOME
        private set

    private class Btn(val id: String, val rect: RectF)

    private val events = ConcurrentLinkedQueue<Int>()
    private val buttons = ArrayList<Btn>()
    private var hoverId: String? = null
    private var hoverStart = 0L
    private var dwellArmed = true
    private var lastPinch = false
    private var toast = ""
    private var toastUntil = 0L
    private val startTime = SystemClock.uptimeMillis()
    private val game = BubbleGame()
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    private var w = 1f
    private var h = 1f

    private val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(205, 12, 16, 28) }
    private val btnPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val cursorPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val textC = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val textL = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.LEFT
        typeface = Typeface.DEFAULT
    }
    private val tmp = RectF()

    fun post(event: Int) {
        events.add(event)
    }

    // ================================================================ кадр
    fun draw(c: Canvas, width: Int, height: Int) {
        w = width.toFloat()
        h = height.toFloat()
        val now = SystemClock.uptimeMillis()
        c.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)

        while (true) {
            val ev = events.poll() ?: break
            handleEvent(ev, now)
        }

        val handOn = state.trackerReady && now - state.handTime < HAND_TIMEOUT_MS
        var cx = -1f
        var cy = -1f
        if (handOn) {
            val p = state.eyePoint()
            cx = p[0]
            cy = p[1]
        }

        buttons.clear()
        when (screen) {
            Screen.HOME -> drawHome(c, now)
            Screen.MENU -> drawMenu(c)
            Screen.SETTINGS -> drawSettings(c)
            Screen.GALLERY -> drawGallery(c)
            Screen.GAME -> drawGame(c, now, handOn, cx, cy)
        }
        if (screen == Screen.HOME || screen == Screen.MENU) drawStatus(c, handOn)

        // ---- курсор, үстінде тұру (dwell), шымшу
        val hovered = if (handOn) buttons.firstOrNull { it.rect.contains(cx * w, cy * h) } else null
        val hid = hovered?.id
        if (hid != hoverId) {
            hoverId = hid
            hoverStart = now
            dwellArmed = true
        }
        val pinch = handOn && state.pinch
        var clickId: String? = null
        if (pinch && !lastPinch && hid != null) clickId = hid
        lastPinch = pinch

        var dwell = 0f
        if (hid != null && dwellArmed && clickId == null) {
            dwell = (now - hoverStart).toFloat() / DWELL_MS
            if (dwell >= 1f) {
                clickId = hid
                dwell = 0f
                if (hid.endsWith("+") || hid.endsWith("-")) {
                    hoverStart = now // +/− батырмалары ұстап тұрса қайталанады
                } else {
                    dwellArmed = false
                }
            }
        }

        if (state.cameraStatus.isNotEmpty()) message(c, state.cameraStatus, 0.5f, Color.rgb(255, 120, 120))
        if (now < toastUntil) drawToast(c)
        if (handOn) drawCursor(c, cx * w, cy * h, pinch, dwell)

        if (clickId != null) click(clickId, now)
    }

    // ================================================================ оқиғалар
    private fun handleEvent(ev: Int, now: Long) {
        when (ev) {
            EV_MENU -> screen = when (screen) {
                Screen.HOME -> Screen.MENU
                Screen.MENU -> Screen.SETTINGS
                else -> Screen.HOME
            }
            EV_NEXT -> when (screen) {
                Screen.GALLERY -> gallery.step(1)
                // Қол істемесе де бұруға болсын: Баптауда дыбыс «+» камераны 90° бұрады
                Screen.SETTINGS -> {
                    state.rotUser = (state.rotUser + 1) % 4
                    showToast("Камера: ${state.camQuarterTurns() * 90}°", now)
                }
                else -> nextEffect(now)
            }
            EV_BACK -> screen = if (screen == Screen.SETTINGS) Screen.MENU else Screen.HOME
        }
    }

    private fun click(id: String, now: Long) {
        when (id) {
            "menu" -> screen = Screen.MENU
            "close" -> screen = Screen.HOME
            "effect" -> nextEffect(now)
            "gallery" -> openGallery()
            "game" -> {
                game.start(now)
                screen = Screen.GAME
            }
            "youtube" -> launch("YouTube", listOf("com.google.android.youtube"), now)
            "tiktok" -> launch(
                "TikTok",
                listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.ss.android.ugc.aweme"),
                now
            )
            "whatsapp" -> launch("WhatsApp", listOf("com.whatsapp", "com.whatsapp.w4b"), now)
            "settings" -> screen = Screen.SETTINGS
            "exit" -> host.exitApp()
            "back" -> screen = Screen.MENU
            "dist-" -> state.distortion = (state.distortion - 0.05f).coerceIn(0f, 0.6f)
            "dist+" -> state.distortion = (state.distortion + 0.05f).coerceIn(0f, 0.6f)
            "ipd-" -> state.ipdMm = (state.ipdMm - 1f).coerceIn(50f, 75f)
            "ipd+" -> state.ipdMm = (state.ipdMm + 1f).coerceIn(50f, 75f)
            "zoom-" -> state.zoom = (state.zoom - 0.05f).coerceIn(0.5f, 1.5f)
            "zoom+" -> state.zoom = (state.zoom + 0.05f).coerceIn(0.5f, 1.5f)
            "rot" -> state.rotUser = (state.rotUser + 1) % 4
            "prev" -> gallery.step(-1)
            "next" -> gallery.step(1)
            "gperm" -> host.requestGalleryPermission()
            "again" -> game.start(now)
            "gquit" -> screen = Screen.MENU
        }
    }

    private fun nextEffect(now: Long) {
        state.effect = (state.effect + 1) % state.effectNames.size
        showToast("Эффект: " + state.effectNames[state.effect], now)
    }

    private fun openGallery() {
        if (gallery.permitted && !gallery.loaded) gallery.load()
        screen = Screen.GALLERY
    }

    private fun launch(name: String, packages: List<String>, now: Long) {
        if (host.launchApp(packages)) {
            screen = Screen.HOME
        } else {
            showToast("$name табылмады", now)
        }
    }

    private fun showToast(s: String, now: Long) {
        toast = s
        toastUntil = now + 1800L
    }

    // ================================================================ экрандар
    private fun drawHome(c: Canvas, now: Long) {
        button(c, "menu", "☰  МЕНЮ", 0.38f, 0.79f, 0.62f, 0.89f)
        if (now - startTime < 10_000L) {
            panel(c, 0.18f, 0.52f, 0.82f, 0.75f)
            val lines = listOf(
                "Сұқ саусақты көрсет — курсор",
                "Шымшу немесе 1 сек ұстау — басу",
                "Дыбыс −: мәзір   ·   Дыбыс +: эффект"
            )
            textC.textSize = h * 0.036f
            for ((i, s) in lines.withIndex()) {
                c.drawText(s, w * 0.5f, h * (0.585f + i * 0.06f), textC)
            }
        }
    }

    private fun drawMenu(c: Canvas) {
        panel(c, 0.12f, 0.15f, 0.88f, 0.87f)
        title(c, "VR МӘЗІР", 0.225f)
        button(c, "effect", "Эффект\n" + state.effectNames[state.effect], cell(0, 0), cell(0, 1), cell(0, 2), cell(0, 3), true)
        button(c, "gallery", "Галерея", cell(1, 0), cell(0, 1), cell(1, 2), cell(0, 3), true)
        button(c, "game", "Ойын", cell(2, 0), cell(0, 1), cell(2, 2), cell(0, 3), true)
        button(c, "youtube", "YouTube", cell(0, 0), cell(1, 1), cell(0, 2), cell(1, 3))
        button(c, "tiktok", "TikTok", cell(1, 0), cell(1, 1), cell(1, 2), cell(1, 3))
        button(c, "whatsapp", "WhatsApp", cell(2, 0), cell(1, 1), cell(2, 2), cell(1, 3))
        button(c, "settings", "Баптау", cell(0, 0), cell(2, 1), cell(0, 2), cell(2, 3))
        button(c, "close", "Жабу", cell(1, 0), cell(2, 1), cell(1, 2), cell(2, 3))
        button(c, "exit", "Шығу", cell(2, 0), cell(2, 1), cell(2, 2), cell(2, 3))
    }

    /**
     * Мәзір торы: 3 баған × 3 жол. part: 0 = сол, 1 = жоғары, 2 = оң, 3 = төмен.
     * index — part 0/2 үшін баған, part 1/3 үшін жол.
     */
    private fun cell(index: Int, part: Int): Float {
        val left = 0.15f
        val colW = 0.22f
        val gap = 0.02f
        val top = 0.28f
        val rowH = 0.165f
        val rowGap = 0.025f
        return when (part) {
            0 -> left + index * (colW + gap)
            2 -> left + index * (colW + gap) + colW
            1 -> top + index * (rowH + rowGap)
            else -> top + index * (rowH + rowGap) + rowH
        }
    }

    private fun drawSettings(c: Canvas) {
        panel(c, 0.12f, 0.15f, 0.88f, 0.87f)
        title(c, "БАПТАУ", 0.225f)
        settingRow(c, 0, "Линза иілуі", String.format(Locale.US, "%.2f", state.distortion), "dist")
        settingRow(c, 1, "Көз аралығы", "${state.ipdMm.toInt()} мм", "ipd")
        settingRow(c, 2, "Масштаб", String.format(Locale.US, "%.2f", state.zoom), "zoom")
        button(
            c, "rot", "Камераны бұру (+90°): қазір ${state.camQuarterTurns() * 90}°",
            0.17f, 0.635f, 0.83f, 0.725f
        )
        button(c, "back", "← Артқа", 0.38f, 0.755f, 0.62f, 0.845f, true)
    }

    private fun settingRow(c: Canvas, row: Int, label: String, value: String, id: String) {
        val top = 0.28f + row * 0.115f
        val bottom = top + 0.09f
        val mid = (top + bottom) / 2f * h
        textL.textSize = h * 0.04f
        textL.color = Color.WHITE
        c.drawText(label, w * 0.17f, mid + h * 0.014f, textL)
        textL.color = Color.rgb(140, 200, 255)
        c.drawText(value, w * 0.47f, mid + h * 0.014f, textL)
        textL.color = Color.WHITE
        button(c, "$id-", "−", 0.62f, top, 0.71f, bottom)
        button(c, "$id+", "+", 0.74f, top, 0.83f, bottom)
    }

    private fun drawGallery(c: Canvas) {
        panel(c, 0.10f, 0.12f, 0.90f, 0.90f)
        if (!gallery.permitted) {
            message(c, "Суреттерді көру үшін рұқсат керек", 0.38f, Color.WHITE)
            button(c, "gperm", "Рұқсат беру", 0.30f, 0.48f, 0.70f, 0.60f, true)
            button(c, "close", "Жабу", 0.38f, 0.70f, 0.62f, 0.80f)
            return
        }
        if (!gallery.loaded) {
            if (!gallery.loading) gallery.load()
            message(c, "Жүктелуде…", 0.45f, Color.WHITE)
        } else if (gallery.uris.isEmpty()) {
            message(c, "Сурет табылмады", 0.45f, Color.WHITE)
        } else {
            val bmp: Bitmap? = gallery.current
            if (bmp != null) {
                val areaL = 0.13f * w
                val areaT = 0.15f * h
                val areaW = 0.74f * w
                val areaH = 0.59f * h
                val s = minOf(areaW / bmp.width, areaH / bmp.height)
                val dw = bmp.width * s
                val dh = bmp.height * s
                tmp.set(
                    areaL + (areaW - dw) / 2f, areaT + (areaH - dh) / 2f,
                    areaL + (areaW + dw) / 2f, areaT + (areaH + dh) / 2f
                )
                c.drawBitmap(bmp, null, tmp, bmpPaint)
            } else {
                message(c, "Жүктелуде…", 0.45f, Color.WHITE)
            }
            textC.textSize = h * 0.035f
            c.drawText("${gallery.index + 1} / ${gallery.uris.size}", w * 0.5f, h * 0.785f, textC)
        }
        button(c, "prev", "◀", 0.14f, 0.77f, 0.30f, 0.87f, true)
        button(c, "close", "✕ Жабу", 0.39f, 0.80f, 0.61f, 0.88f)
        button(c, "next", "▶", 0.70f, 0.77f, 0.86f, 0.87f, true)
    }

    private fun drawGame(c: Canvas, now: Long, handOn: Boolean, cx: Float, cy: Float) {
        game.update(now, cx, cy, handOn, w / h)
        game.draw(c, w.toInt(), h.toInt(), now)
        if (game.finished) {
            if (game.score > state.best) state.best = game.score
            panel(c, 0.22f, 0.25f, 0.78f, 0.78f)
            title(c, "ОЙЫН БІТТІ!", 0.34f)
            textC.textSize = h * 0.05f
            c.drawText("Ұпай: ${game.score}", w * 0.5f, h * 0.45f, textC)
            textC.textSize = h * 0.036f
            c.drawText("Рекорд: ${state.best}", w * 0.5f, h * 0.52f, textC)
            button(c, "again", "Қайта", 0.27f, 0.61f, 0.49f, 0.72f, true)
            button(c, "gquit", "Шығу", 0.51f, 0.61f, 0.73f, 0.72f)
        } else {
            textC.textSize = h * 0.045f
            c.drawText(
                "Ұпай: ${game.score}     ⏱ ${game.timeLeftSec(now)}",
                w * 0.5f, h * 0.18f, textC
            )
            button(c, "gquit", "✕", 0.79f, 0.12f, 0.88f, 0.21f)
            if (!handOn) message(c, "Қолыңды камераға көрсет", 0.5f, Color.rgb(255, 220, 120))
        }
    }

    // ================================================================ сурет салу көмекшілері
    private fun drawStatus(c: Canvas, handOn: Boolean) {
        val parts = ArrayList<String>()
        parts.add(timeFmt.format(Date()))
        if (state.battery >= 0) parts.add("${state.battery}%")
        parts.add(state.effectNames[state.effect])
        parts.add(if (handOn) "✋" else "–")
        textC.textSize = h * 0.034f
        textC.color = Color.argb(230, 255, 255, 255)
        val y = if (screen == Screen.MENU) 0.12f else 0.16f
        c.drawText(parts.joinToString("   ·   "), w * 0.5f, h * y, textC)
        textC.color = Color.WHITE
        if (state.trackerStatus.isNotEmpty() && screen == Screen.HOME) {
            textC.textSize = h * 0.03f
            textC.color = Color.rgb(255, 210, 120)
            c.drawText(state.trackerStatus, w * 0.5f, h * 0.21f, textC)
            textC.color = Color.WHITE
        }
    }

    private fun panel(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        tmp.set(l * w, t * h, r * w, b * h)
        val rad = h * 0.03f
        c.drawRoundRect(tmp, rad, rad, panelPaint)
        linePaint.color = Color.argb(130, 120, 170, 255)
        linePaint.strokeWidth = h * 0.004f
        c.drawRoundRect(tmp, rad, rad, linePaint)
    }

    private fun title(c: Canvas, s: String, y: Float) {
        textC.textSize = h * 0.05f
        textC.color = Color.rgb(140, 200, 255)
        c.drawText(s, w * 0.5f, h * y, textC)
        textC.color = Color.WHITE
    }

    private fun message(c: Canvas, s: String, y: Float, color: Int) {
        textC.textSize = h * 0.038f
        textC.color = color
        c.drawText(s, w * 0.5f, h * y, textC)
        textC.color = Color.WHITE
    }

    private fun button(
        c: Canvas, id: String, label: String,
        l: Float, t: Float, r: Float, b: Float,
        accent: Boolean = false
    ) {
        val rect = RectF(l * w, t * h, r * w, b * h)
        buttons.add(Btn(id, rect))
        val hover = id == hoverId
        btnPaint.color = when {
            hover -> Color.argb(240, 64, 156, 255)
            accent -> Color.argb(215, 36, 84, 160)
            else -> Color.argb(205, 40, 48, 66)
        }
        val rad = h * 0.02f
        c.drawRoundRect(rect, rad, rad, btnPaint)
        if (hover) {
            linePaint.color = Color.WHITE
            linePaint.strokeWidth = h * 0.005f
            c.drawRoundRect(rect, rad, rad, linePaint)
        }
        drawLabel(c, label, rect)
    }

    /** Көп жолды мәтінді батырма ішіне сыйғызып ортасына жазу. */
    private fun drawLabel(c: Canvas, label: String, rect: RectF) {
        val lines = label.split("\n")
        var size = h * 0.042f
        textC.textSize = size
        val maxW = rect.width() * 0.88f
        for (s in lines) {
            val tw = textC.measureText(s)
            if (tw > maxW) size = minOf(size, size * maxW / tw)
        }
        val maxH = rect.height() * 0.8f / lines.size
        if (size > maxH) size = maxH
        textC.textSize = size
        val fm = textC.fontMetrics
        val lineH = size * 1.15f
        val firstY = rect.centerY() - lineH * (lines.size - 1) / 2f - (fm.ascent + fm.descent) / 2f
        for ((i, s) in lines.withIndex()) {
            textC.color = if (i == 0) Color.WHITE else Color.rgb(170, 215, 255)
            c.drawText(s, rect.centerX(), firstY + i * lineH, textC)
        }
        textC.color = Color.WHITE
    }

    private fun drawToast(c: Canvas) {
        textC.textSize = h * 0.04f
        val tw = textC.measureText(toast)
        val pad = h * 0.03f
        tmp.set(w * 0.5f - tw / 2f - pad, h * 0.40f, w * 0.5f + tw / 2f + pad, h * 0.49f)
        c.drawRoundRect(tmp, h * 0.02f, h * 0.02f, panelPaint)
        c.drawText(toast, w * 0.5f, h * 0.459f, textC)
    }

    private fun drawCursor(c: Canvas, x: Float, y: Float, pinch: Boolean, dwell: Float) {
        val r = h * 0.022f
        cursorPaint.style = Paint.Style.FILL
        cursorPaint.color = if (pinch) Color.rgb(255, 210, 60) else Color.argb(200, 255, 255, 255)
        c.drawCircle(x, y, r * 0.35f, cursorPaint)
        cursorPaint.style = Paint.Style.STROKE
        cursorPaint.strokeWidth = h * 0.006f
        c.drawCircle(x, y, r, cursorPaint)
        if (dwell > 0f) {
            cursorPaint.color = Color.rgb(64, 156, 255)
            cursorPaint.strokeWidth = h * 0.009f
            val rr = r * 1.6f
            tmp.set(x - rr, y - rr, x + rr, y + rr)
            c.drawArc(tmp, -90f, 360f * dwell, false, cursorPaint)
        }
    }

    companion object {
        const val EV_MENU = 1
        const val EV_NEXT = 2
        const val EV_BACK = 3
        private const val DWELL_MS = 1200L
        private const val HAND_TIMEOUT_MS = 350L
    }
}
