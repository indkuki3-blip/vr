package kz.akarys.vrpass

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.abs

/** Қосымшаның сыртқы әрекеттері (MainActivity іске асырады). */
interface VrHost {
    /** Тізімдегі алғашқы орнатылған қосымшаны ашады. Табылмаса — false. */
    fun launchApp(packages: List<String>): Boolean
    fun requestGalleryPermission()
    fun exitApp()
    fun webOpen(url: String): Boolean
    fun webBack()
    fun webReload()
    fun webClose()
    fun webTouch(action: Int, nx: Float, ny: Float)
}

/**
 * VR интерфейсі: мәзір, ойындар, баптау, галерея, веб-панель, курсорлар.
 * Бір көзге арналған мөлдір суретке (HUD) салынады, оны рендер екі көзге қояды.
 * Басу — ТЕК шымшу (бас бармақ + сұқ саусақ түйіседі). Екі қол да жұмыс істейді.
 */
class VrUi(
    private val state: VrState,
    private val host: VrHost,
    private val gallery: Gallery,
    sfx: Sfx
) {
    enum class Screen { HOME, MENU, GAMES, SETTINGS, GALLERY, GAME, WEB }

    @Volatile
    var screen = Screen.HOME
        private set

    private class Btn(val id: String, val rect: RectF)

    private val events = ConcurrentLinkedQueue<Int>()
    private val buttons = ArrayList<Btn>()
    private val hovered = HashSet<String>()
    private val lastPinch = BooleanArray(2)
    private var toast = ""
    private var toastUntil = 0L
    private val startTime = SystemClock.uptimeMillis()

    private val games: List<MiniGame> = listOf(
        BubbleGame(sfx), PianoGame(sfx), RaceGame(sfx), ShooterGame(sfx), HorrorGame(sfx)
    )
    private var game: MiniGame? = null
    private var bestSaved = false

    // Веб-панель: қай қол «саусақпен басып» тұр
    private var webPointer = -1
    private var webLastX = 0f
    private var webLastY = 0f

    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private var statusText = ""
    private var statusAt = 0L

    private var w = 1f
    private var h = 1f
    private var hands: List<EyeHand> = emptyList()

    private val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(205, 12, 16, 28) }
    private val btnPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val cursorPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val textC = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val textL = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.LEFT
        typeface = Typeface.DEFAULT
    }
    private val tmp = RectF()

    fun post(event: Int) {
        events.add(event)
    }

    // ================================================================ кадр
    fun draw(c: Canvas, width: Int, height: Int) {
        w = width.toFloat()
        h = height.toFloat()
        val now = SystemClock.uptimeMillis()
        c.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)

        while (true) {
            val ev = events.poll() ?: break
            handleEvent(ev, now)
        }

        hands = buildHands(now)
        state.webOn = screen == Screen.WEB

        buttons.clear()
        when (screen) {
            Screen.HOME -> drawHome(c, now)
            Screen.MENU -> drawMenu(c)
            Screen.GAMES -> drawGames(c)
            Screen.SETTINGS -> drawSettings(c)
            Screen.GALLERY -> drawGallery(c)
            Screen.GAME -> drawGame(c, now)
            Screen.WEB -> drawWeb(c)
        }
        if (screen == Screen.HOME || screen == Screen.MENU) drawStatus(c, now)

        // ---- басу: тек шымшу басталған сәтте
        hovered.clear()
        var clickId: String? = null
        for (hd in hands) {
            val b = buttons.firstOrNull { it.rect.contains(hd.cx * w, hd.cy * h) } ?: continue
            hovered.add(b.id)
            if (hd.pinchDown && clickId == null) clickId = b.id
        }
        if (screen == Screen.WEB) handleWebInput()

        if (state.cameraStatus.isNotEmpty()) message(c, state.cameraStatus, 0.5f, Color.rgb(255, 120, 120))
        if (now < toastUntil) drawToast(c)
        for (hd in hands) drawCursor(c, hd.cx * w, hd.cy * h, hd.pinch)

        if (clickId != null) click(clickId, now)
    }

    /** Камера координатасындағы қолдарды HUD координатасына айналдырады, шымшу сәттерін табады. */
    private fun buildHands(now: Long): List<EyeHand> {
        val frame = state.hands
        val result = ArrayList<EyeHand>(2)
        val seen = BooleanArray(2)
        if (state.trackerReady && now - frame.time < HAND_TIMEOUT_MS) {
            val inv = state.inverseTurns()
            val cur = FloatArray(2)
            for (rh in frame.hands) {
                val s = rh.slot
                if (s !in 0..1) continue
                val pts = FloatArray(42)
                for (i in 0 until 21) state.toEye(rh.xs[i], rh.ys[i], inv, pts, i * 2)
                state.toEye(rh.tipX, rh.tipY, inv, cur, 0)
                val down = rh.pinch && !lastPinch[s]
                val up = !rh.pinch && lastPinch[s]
                lastPinch[s] = rh.pinch
                seen[s] = true
                result.add(EyeHand(s, pts, cur[0], cur[1], rh.pinch, down, up))
            }
        }
        for (s in 0..1) if (!seen[s]) lastPinch[s] = false
        return result
    }

    // ================================================================ оқиғалар
    private fun handleEvent(ev: Int, now: Long) {
        when (ev) {
            EV_MENU -> {
                if (screen == Screen.WEB) host.webClose()
                screen = when (screen) {
                    Screen.HOME -> Screen.MENU
                    Screen.MENU -> Screen.SETTINGS
                    else -> Screen.HOME
                }
            }
            EV_NEXT -> when (screen) {
                Screen.GALLERY -> gallery.step(1)
                // Қол істемесе де бұруға болсын: Баптауда дыбыс «+» камераны 90° бұрады
                Screen.SETTINGS -> {
                    state.rotUser = (state.rotUser + 1) % 4
                    showToast("Камера: ${state.camQuarterTurns() * 90}°", now)
                }
                Screen.WEB -> host.webBack()
                else -> nextEffect(now)
            }
            EV_BACK -> when (screen) {
                Screen.WEB -> host.webBack()
                Screen.SETTINGS, Screen.GAMES -> screen = Screen.MENU
                Screen.GAME -> screen = Screen.GAMES
                else -> screen = Screen.HOME
            }
        }
    }

    private fun click(id: String, now: Long) {
        when (id) {
            "menu" -> screen = Screen.MENU
            "close" -> screen = Screen.HOME
            "effect" -> nextEffect(now)
            "gallery" -> openGallery()
            "games" -> screen = Screen.GAMES
            "youtube" -> openWeb("https://m.youtube.com/", now)
            "tiktok" -> openWeb("https://www.tiktok.com/foryou", now)
            "whatsapp" -> launch("WhatsApp", listOf("com.whatsapp", "com.whatsapp.w4b"), now)
            "settings" -> screen = Screen.SETTINGS
            "exit" -> host.exitApp()
            "back" -> screen = Screen.MENU
            "dist-" -> state.distortion = (state.distortion - 0.05f).coerceIn(0f, 0.6f)
            "dist+" -> state.distortion = (state.distortion + 0.05f).coerceIn(0f, 0.6f)
            "ipd-" -> state.ipdMm = (state.ipdMm - 1f).coerceIn(50f, 75f)
            "ipd+" -> state.ipdMm = (state.ipdMm + 1f).coerceIn(50f, 75f)
            "zoom-" -> state.zoom = (state.zoom - 0.05f).coerceIn(0.5f, 1.5f)
            "zoom+" -> state.zoom = (state.zoom + 0.05f).coerceIn(0.5f, 1.5f)
            "rot" -> state.rotUser = (state.rotUser + 1) % 4
            "prev" -> gallery.step(-1)
            "next" -> gallery.step(1)
            "gperm" -> host.requestGalleryPermission()
            "again" -> startGame(game, now)
            "gquit" -> screen = Screen.GAMES
            "wback" -> host.webBack()
            "wreload" -> host.webReload()
            "wclose" -> {
                host.webClose()
                screen = Screen.MENU
            }
            else -> if (id.startsWith("g:")) {
                startGame(games.firstOrNull { it.id == id.substring(2) }, now)
            }
        }
    }

    private fun startGame(g: MiniGame?, now: Long) {
        if (g == null) return
        game = g
        bestSaved = false
        g.start(now)
        screen = Screen.GAME
    }

    private fun nextEffect(now: Long) {
        state.effect = (state.effect + 1) % state.effectNames.size
        showToast("Эффект: " + state.effectNames[state.effect], now)
    }

    private fun openGallery() {
        if (gallery.permitted && !gallery.loaded) gallery.load()
        screen = Screen.GALLERY
    }

    private fun openWeb(url: String, now: Long) {
        if (host.webOpen(url)) {
            webPointer = -1
            screen = Screen.WEB
        } else {
            showToast("Веб-панель ашылмады", now)
        }
    }

    private fun launch(name: String, packages: List<String>, now: Long) {
        if (host.launchApp(packages)) {
            screen = Screen.HOME
        } else {
            showToast("$name табылмады", now)
        }
    }

    private fun showToast(s: String, now: Long) {
        toast = s
        toastUntil = now + 1800L
    }

    // ================================================================ веб-панель
    private fun panelRect() {
        // 9:16 тік панель, биіктігі көздің 78%-ы
        val ph = 0.78f
        val pw = ph * h * (WebPanel.W.toFloat() / WebPanel.H) / w
        state.panelL = 0.5f - pw / 2f
        state.panelR = 0.5f + pw / 2f
        state.panelT = 0.11f
        state.panelB = 0.11f + ph
    }

    private fun drawWeb(c: Canvas) {
        panelRect()
        val l = state.panelL
        val r = state.panelR
        tmp.set(l * w - 3f, state.panelT * h - 3f, r * w + 3f, state.panelB * h + 3f)
        linePaint.color = Color.argb(160, 120, 170, 255)
        linePaint.strokeWidth = h * 0.005f
        c.drawRoundRect(tmp, h * 0.01f, h * 0.01f, linePaint)
        val bw = 0.11f
        button(c, "wback", "←\nАртқа", l - bw - 0.02f, 0.30f, l - 0.02f, 0.44f, true)
        button(c, "wreload", "⟳\nЖаңарту", l - bw - 0.02f, 0.48f, l - 0.02f, 0.62f)
        button(c, "wclose", "✕\nЖабу", r + 0.02f, 0.30f, r + 0.02f + bw, 0.44f)
    }

    /** Шымшу = басу, шымшып жүргізу = айналдыру/свайп. */
    private fun handleWebInput() {
        val l = state.panelL
        val t = state.panelT
        val pw = state.panelR - l
        val ph = state.panelB - t
        var pointerAlive = false
        for (hd in hands) {
            val nx = (hd.cx - l) / pw
            val ny = (hd.cy - t) / ph
            val inside = nx in 0f..1f && ny in 0f..1f
            if (webPointer < 0 && hd.pinchDown && inside) {
                webPointer = hd.slot
                webLastX = nx
                webLastY = ny
                host.webTouch(MotionEvent.ACTION_DOWN, nx, ny)
                pointerAlive = true
            } else if (hd.slot == webPointer) {
                pointerAlive = true
                val cx = nx.coerceIn(0f, 1f)
                val cy = ny.coerceIn(0f, 1f)
                if (hd.pinch) {
                    if (abs(cx - webLastX) > 0.003f || abs(cy - webLastY) > 0.003f) {
                        webLastX = cx
                        webLastY = cy
                        host.webTouch(MotionEvent.ACTION_MOVE, cx, cy)
                    }
                } else {
                    host.webTouch(MotionEvent.ACTION_UP, webLastX, webLastY)
                    webPointer = -1
                }
            }
        }
        if (webPointer >= 0 && !pointerAlive) {
            host.webTouch(MotionEvent.ACTION_UP, webLastX, webLastY)
            webPointer = -1
        }
    }

    // ================================================================ экрандар
    private fun drawHome(c: Canvas, now: Long) {
        button(c, "menu", "☰  МӘЗІР", 0.38f, 0.79f, 0.62f, 0.89f)
        if (now - startTime < 10_000L) {
            panel(c, 0.16f, 0.50f, 0.84f, 0.75f)
            val lines = listOf(
                "Сұқ саусақ — курсор (екі қол да)",
                "Бас бармақ + сұқ саусақты түйістір — басу",
                "Дыбыс −: мәзір   ·   Дыбыс +: эффект"
            )
            textC.textSize = h * 0.034f
            for ((i, s) in lines.withIndex()) {
                c.drawText(s, w * 0.5f, h * (0.57f + i * 0.06f), textC)
            }
        }
    }

    private fun drawMenu(c: Canvas) {
        panel(c, 0.12f, 0.15f, 0.88f, 0.87f)
        title(c, "VR МӘЗІР", 0.225f)
        gridButton(c, "effect", "Эффект\n" + state.effectNames[state.effect], 0, 0, true)
        gridButton(c, "gallery", "Галерея", 1, 0, true)
        gridButton(c, "games", "Ойындар", 2, 0, true)
        gridButton(c, "youtube", "YouTube", 0, 1)
        gridButton(c, "tiktok", "TikTok", 1, 1)
        gridButton(c, "whatsapp", "WhatsApp\n(сыртта)", 2, 1)
        gridButton(c, "settings", "Баптау", 0, 2)
        gridButton(c, "close", "Жабу", 1, 2)
        gridButton(c, "exit", "Шығу", 2, 2)
    }

    private fun drawGames(c: Canvas) {
        panel(c, 0.12f, 0.15f, 0.88f, 0.87f)
        title(c, "ОЙЫНДАР", 0.225f)
        for ((i, g) in games.withIndex()) {
            val best = state.best(g.id)
            val label = if (g.id == "piano") g.title else g.title + "\nрекорд: $best"
            gridButton(c, "g:" + g.id, label, i % 3, i / 3, true)
        }
        gridButton(c, "back", "← Артқа", 2, 1)
        textC.textSize = h * 0.03f
        textC.color = Color.rgb(170, 200, 240)
        c.drawText("Екі қол да ойнайды", w * 0.5f, h * 0.8f, textC)
        textC.color = Color.WHITE
    }

    private fun gridButton(c: Canvas, id: String, label: String, col: Int, row: Int, accent: Boolean = false) {
        val left = 0.15f + col * 0.24f
        val top = 0.28f + row * 0.19f
        button(c, id, label, left, top, left + 0.22f, top + 0.165f, accent)
    }

    private fun drawSettings(c: Canvas) {
        panel(c, 0.12f, 0.15f, 0.88f, 0.87f)
        title(c, "БАПТАУ", 0.225f)
        settingRow(c, 0, "Линза иілуі", String.format(Locale.US, "%.2f", state.distortion), "dist")
        settingRow(c, 1, "Көз аралығы", "${state.ipdMm.toInt()} мм", "ipd")
        settingRow(c, 2, "Масштаб", String.format(Locale.US, "%.2f", state.zoom), "zoom")
        button(c, "rot", "Камераны бұру (+90°): қазір ${state.camQuarterTurns() * 90}°", 0.17f, 0.635f, 0.83f, 0.725f)
        button(c, "back", "← Артқа", 0.38f, 0.755f, 0.62f, 0.845f, true)
    }

    private fun settingRow(c: Canvas, row: Int, label: String, value: String, id: String) {
        val top = 0.28f + row * 0.115f
        val bottom = top + 0.09f
        val mid = (top + bottom) / 2f * h
        textL.textSize = h * 0.04f
        textL.color = Color.WHITE
        c.drawText(label, w * 0.17f, mid + h * 0.014f, textL)
        textL.color = Color.rgb(140, 200, 255)
        c.drawText(value, w * 0.47f, mid + h * 0.014f, textL)
        textL.color = Color.WHITE
        button(c, "$id-", "−", 0.62f, top, 0.71f, bottom)
        button(c, "$id+", "+", 0.74f, top, 0.83f, bottom)
    }

    private fun drawGallery(c: Canvas) {
        panel(c, 0.10f, 0.12f, 0.90f, 0.90f)
        if (!gallery.permitted) {
            message(c, "Суреттерді көру үшін рұқсат керек", 0.38f, Color.WHITE)
            button(c, "gperm", "Рұқсат беру", 0.30f, 0.48f, 0.70f, 0.60f, true)
            button(c, "close", "Жабу", 0.38f, 0.70f, 0.62f, 0.80f)
            return
        }
        if (!gallery.loaded) {
            if (!gallery.loading) gallery.load()
            message(c, "Жүктелуде…", 0.45f, Color.WHITE)
        } else if (gallery.uris.isEmpty()) {
            message(c, "Сурет табылмады", 0.45f, Color.WHITE)
        } else {
            val bmp: Bitmap? = gallery.current
            if (bmp != null) {
                val areaL = 0.13f * w
                val areaT = 0.15f * h
                val areaW = 0.74f * w
                val areaH = 0.59f * h
                val s = minOf(areaW / bmp.width, areaH / bmp.height)
                val dw = bmp.width * s
                val dh = bmp.height * s
                tmp.set(
                    areaL + (areaW - dw) / 2f, areaT + (areaH - dh) / 2f,
                    areaL + (areaW + dw) / 2f, areaT + (areaH + dh) / 2f
                )
                c.drawBitmap(bmp, null, tmp, bmpPaint)
            } else {
                message(c, "Жүктелуде…", 0.45f, Color.WHITE)
            }
            textC.textSize = h * 0.035f
            c.drawText("${gallery.index + 1} / ${gallery.uris.size}", w * 0.5f, h * 0.785f, textC)
        }
        button(c, "prev", "◀", 0.14f, 0.77f, 0.30f, 0.87f, true)
        button(c, "close", "✕ Жабу", 0.39f, 0.80f, 0.61f, 0.88f)
        button(c, "next", "▶", 0.70f, 0.77f, 0.86f, 0.87f, true)
    }

    private fun drawGame(c: Canvas, now: Long) {
        val g = game
        if (g == null) {
            screen = Screen.GAMES
            return
        }
        g.update(now, hands, w / h)
        g.draw(c, w.toInt(), h.toInt(), now)
        if (g.finished) {
            if (!bestSaved) {
                bestSaved = true
                if (g.score > state.best(g.id)) state.setBest(g.id, g.score)
            }
            panel(c, 0.22f, 0.25f, 0.78f, 0.78f)
            title(c, "ОЙЫН БІТТІ!", 0.34f)
            textC.textSize = h * 0.05f
            c.drawText("Ұпай: ${g.score}", w * 0.5f, h * 0.45f, textC)
            textC.textSize = h * 0.036f
            c.drawText("Рекорд: ${state.best(g.id)}", w * 0.5f, h * 0.52f, textC)
            button(c, "again", "Қайта", 0.27f, 0.61f, 0.49f, 0.72f, true)
            button(c, "gquit", "Шығу", 0.51f, 0.61f, 0.73f, 0.72f)
        } else {
            button(c, "gquit", "✕", 0.80f, 0.13f, 0.88f, 0.22f)
        }
    }

    // ================================================================ сурет салу көмекшілері
    private fun drawStatus(c: Canvas, now: Long) {
        if (now - statusAt > 1000L) {
            statusAt = now
            val parts = ArrayList<String>()
            parts.add(timeFmt.format(Date()))
            if (state.battery >= 0) parts.add("${state.battery}%")
            parts.add(state.effectNames[state.effect])
            statusText = parts.joinToString("   ·   ")
        }
        val handsMark = when (hands.size) {
            0 -> "–"
            1 -> "✋"
            else -> "✋✋"
        }
        textC.textSize = h * 0.034f
        textC.color = Color.argb(230, 255, 255, 255)
        val y = if (screen == Screen.MENU) 0.12f else 0.16f
        c.drawText("$statusText   ·   $handsMark", w * 0.5f, h * y, textC)
        textC.color = Color.WHITE
        if (state.trackerStatus.isNotEmpty() && screen == Screen.HOME) {
            textC.textSize = h * 0.03f
            textC.color = Color.rgb(255, 210, 120)
            c.drawText(state.trackerStatus, w * 0.5f, h * 0.21f, textC)
            textC.color = Color.WHITE
        }
    }

    private fun panel(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        tmp.set(l * w, t * h, r * w, b * h)
        val rad = h * 0.03f
        c.drawRoundRect(tmp, rad, rad, panelPaint)
        linePaint.color = Color.argb(130, 120, 170, 255)
        linePaint.strokeWidth = h * 0.004f
        c.drawRoundRect(tmp, rad, rad, linePaint)
    }

    private fun title(c: Canvas, s: String, y: Float) {
        textC.textSize = h * 0.05f
        textC.color = Color.rgb(140, 200, 255)
        c.drawText(s, w * 0.5f, h * y, textC)
        textC.color = Color.WHITE
    }

    private fun message(c: Canvas, s: String, y: Float, color: Int) {
        textC.textSize = h * 0.038f
        textC.color = color
        c.drawText(s, w * 0.5f, h * y, textC)
        textC.color = Color.WHITE
    }

    private fun button(
        c: Canvas, id: String, label: String,
        l: Float, t: Float, r: Float, b: Float,
        accent: Boolean = false
    ) {
        val rect = RectF(l * w, t * h, r * w, b * h)
        buttons.add(Btn(id, rect))
        val hover = hovered.contains(id)
        btnPaint.color = when {
            hover -> Color.argb(240, 64, 156, 255)
            accent -> Color.argb(215, 36, 84, 160)
            else -> Color.argb(205, 40, 48, 66)
        }
        val rad = h * 0.02f
        c.drawRoundRect(rect, rad, rad, btnPaint)
        if (hover) {
            linePaint.color = Color.WHITE
            linePaint.strokeWidth = h * 0.005f
            c.drawRoundRect(rect, rad, rad, linePaint)
        }
        drawLabel(c, label, rect)
    }

    /** Көп жолды мәтінді батырма ішіне сыйғызып ортасына жазу. */
    private fun drawLabel(c: Canvas, label: String, rect: RectF) {
        val lines = label.split("\n")
        var size = h * 0.042f
        textC.textSize = size
        val maxW = rect.width() * 0.88f
        for (s in lines) {
            val tw = textC.measureText(s)
            if (tw > maxW) size = minOf(size, size * maxW / tw)
        }
        val maxH = rect.height() * 0.8f / lines.size
        if (size > maxH) size = maxH
        textC.textSize = size
        val fm = textC.fontMetrics
        val lineH = size * 1.15f
        val firstY = rect.centerY() - lineH * (lines.size - 1) / 2f - (fm.ascent + fm.descent) / 2f
        for ((i, s) in lines.withIndex()) {
            textC.color = if (i == 0) Color.WHITE else Color.rgb(170, 215, 255)
            c.drawText(s, rect.centerX(), firstY + i * lineH, textC)
        }
        textC.color = Color.WHITE
    }

    private fun drawToast(c: Canvas) {
        textC.textSize = h * 0.04f
        val tw = textC.measureText(toast)
        val pad = h * 0.03f
        tmp.set(w * 0.5f - tw / 2f - pad, h * 0.40f, w * 0.5f + tw / 2f + pad, h * 0.49f)
        c.drawRoundRect(tmp, h * 0.02f, h * 0.02f, panelPaint)
        c.drawText(toast, w * 0.5f, h * 0.459f, textC)
    }

    private fun drawCursor(c: Canvas, x: Float, y: Float, pinch: Boolean) {
        val r = h * 0.022f
        cursorPaint.style = Paint.Style.FILL
        cursorPaint.color = if (pinch) Color.rgb(255, 210, 60) else Color.argb(200, 255, 255, 255)
        c.drawCircle(x, y, if (pinch) r * 0.7f else r * 0.35f, cursorPaint)
        cursorPaint.style = Paint.Style.STROKE
        cursorPaint.strokeWidth = h * 0.006f
        c.drawCircle(x, y, r, cursorPaint)
    }

    companion object {
        const val EV_MENU = 1
        const val EV_NEXT = 2
        const val EV_BACK = 3
        private const val HAND_TIMEOUT_MS = 350L
    }
}
