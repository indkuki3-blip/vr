package kz.akarys.vrpass

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Атыс (AR): бөлмеңе жау дрондар ұшып келеді. Әр қол — жеке тапанша:
 * сұқ саусақпен көздейсің, бас бармақты түсірсең (шымшу) — атыс.
 * Дрон тым жақындап кетсе — жан азаяды. 5 жан.
 */
class ShooterGame(private val sfx: Sfx) : MiniGame {

    private class Drone(var x: Float, var y: Float, var size: Float, var vx: Float, var vy: Float, val growth: Float, val phase: Float)
    private class Blast(val x: Float, val y: Float, val r: Float, val t0: Long)

    override val id = "shooter"
    override val title = "Атыс"
    override var score = 0
        private set
    override var finished = false
        private set

    private val drones = ArrayList<Drone>()
    private val blasts = ArrayList<Blast>()
    private var health = 5
    private var startT = 0L
    private var lastT = 0L
    private var nextSpawn = 0L
    private var hitT = 0L
    private val muzzle = LongArray(2)
    private val aims = ArrayList<FloatArray>()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    override fun start(now: Long) {
        drones.clear()
        blasts.clear()
        score = 0
        health = 5
        finished = false
        startT = now
        lastT = now
        nextSpawn = now + 800L
        hitT = 0L
    }

    override fun update(now: Long, hands: List<EyeHand>, aspect: Float) {
        val dt = min(0.05f, (now - lastT) / 1000f)
        lastT = now
        if (finished) return
        val elapsed = (now - startT) / 1000f

        if (now >= nextSpawn) {
            drones.add(
                Drone(
                    0.2f + Random.nextFloat() * 0.6f, 0.2f + Random.nextFloat() * 0.45f, 0.03f,
                    (Random.nextFloat() - 0.5f) * 0.12f, (Random.nextFloat() - 0.5f) * 0.08f,
                    0.010f + Random.nextFloat() * 0.008f + elapsed * 0.0002f, Random.nextFloat() * 6.28f
                )
            )
            nextSpawn = now + max(550L, 1700L - (elapsed * 18f).toLong())
        }

        val it = drones.iterator()
        while (it.hasNext()) {
            val d = it.next()
            d.x += (d.vx + sin(elapsed * 1.7f + d.phase) * 0.05f) * dt
            d.y += (d.vy + cos(elapsed * 1.3f + d.phase) * 0.03f) * dt
            if (d.x < 0.12f || d.x > 0.88f) d.vx = -d.vx
            if (d.y < 0.15f || d.y > 0.8f) d.vy = -d.vy
            d.x = d.x.coerceIn(0.1f, 0.9f)
            d.y = d.y.coerceIn(0.12f, 0.82f)
            d.size += d.growth * dt
            if (d.size > 0.21f) {
                it.remove()
                health--
                hitT = now
                sfx.play("boom", 0.8f)
                sfx.vibrate(250)
                if (health <= 0) {
                    finished = true
                    return
                }
            }
        }

        aims.clear()
        for (hd in hands) {
            aims.add(floatArrayOf(hd.cx, hd.cy, hd.slot.toFloat()))
            if (hd.pinchDown) {
                sfx.play("shot", 0.8f)
                if (hd.slot in 0..1) muzzle[hd.slot] = now
                var target: Drone? = null
                for (d in drones) {
                    if (hypot((d.x - hd.cx) * aspect, d.y - hd.cy) < d.size + 0.025f) {
                        if (target == null || d.size > target.size) target = d
                    }
                }
                if (target != null) {
                    drones.remove(target)
                    blasts.add(Blast(target.x, target.y, target.size, now))
                    score += 1 + (target.size * 10f).toInt()
                    sfx.play("boom", 0.6f, 1.3f)
                }
            }
        }
        blasts.removeAll { now - it.t0 > 500L }
    }

    override fun draw(c: Canvas, w: Int, h: Int, now: Long) {
        val fw = w.toFloat()
        val fh = h.toFloat()
        val t = (now - startT) / 1000f

        for (d in drones) {
            val x = d.x * fw
            val y = d.y * fh
            val r = d.size * fh
            // Пропеллерлер
            line.color = Color.argb(200, 200, 200, 210)
            line.strokeWidth = r * 0.12f
            for (k in 0 until 4) {
                val ang = k * 1.5708f + 0.785f
                val ax = x + cos(ang) * r * 1.25f
                val ay = y + sin(ang) * r * 0.8f
                c.drawLine(x, y, ax, ay, line)
                val spin = t * 40f + k
                c.drawLine(ax - cos(spin) * r * 0.45f, ay - sin(spin) * r * 0.15f,
                    ax + cos(spin) * r * 0.45f, ay + sin(spin) * r * 0.15f, line)
            }
            // Корпус
            fill.color = Color.rgb(45, 48, 58)
            c.drawCircle(x, y, r * 0.75f, fill)
            fill.color = Color.rgb(80, 85, 100)
            c.drawCircle(x, y - r * 0.1f, r * 0.55f, fill)
            // Қызыл көз (жыпылықтайды)
            val glow = 0.6f + 0.4f * sin(t * 8f + d.phase)
            fill.color = Color.argb((255 * glow).toInt(), 255, 40, 40)
            c.drawCircle(x, y, r * 0.28f, fill)
            fill.color = Color.WHITE
            c.drawCircle(x - r * 0.08f, y - r * 0.08f, r * 0.07f, fill)
        }

        for (b in blasts) {
            val k = ((now - b.t0) / 500f).coerceIn(0f, 1f)
            fill.color = Color.argb(((1f - k) * 230).toInt(), 255, (180 - 120 * k).toInt(), 40)
            c.drawCircle(b.x * fw, b.y * fh, b.r * fh * (0.8f + k * 1.6f), fill)
        }

        // Көздеу белгілері
        for (a in aims) {
            val x = a[0] * fw
            val y = a[1] * fh
            val slot = a[2].toInt()
            val fired = slot in 0..1 && now - muzzle[slot] < 90L
            line.color = if (fired) Color.rgb(255, 230, 80) else Color.rgb(80, 255, 120)
            line.strokeWidth = fh * 0.005f
            val r = fh * 0.035f
            c.drawCircle(x, y, r, line)
            c.drawLine(x - r * 1.6f, y, x - r * 0.5f, y, line)
            c.drawLine(x + r * 0.5f, y, x + r * 1.6f, y, line)
            c.drawLine(x, y - r * 1.6f, x, y - r * 0.5f, line)
            c.drawLine(x, y + r * 0.5f, x, y + r * 1.6f, line)
            if (fired) {
                fill.color = Color.argb(160, 255, 220, 80)
                c.drawCircle(x, y, r * 0.8f, fill)
            }
        }

        val hearts = "❤".repeat(health.coerceAtLeast(0))
        GameText.draw(c, "Ұпай: $score    $hearts", fw * 0.5f, fh * 0.12f, fh * 0.045f, Color.WHITE)
        if (aims.isEmpty()) {
            GameText.draw(c, "Сұқ саусақпен көзде, бас бармақты түсір — атыс", fw * 0.5f, fh * 0.92f, fh * 0.032f, Color.rgb(255, 230, 140))
        }
        if (hitT > 0L && now - hitT < 400L) {
            fill.color = Color.argb((160 * (1f - (now - hitT) / 400f)).toInt(), 255, 0, 0)
            c.drawRect(0f, 0f, fw, fh, fill)
        }
    }
}
