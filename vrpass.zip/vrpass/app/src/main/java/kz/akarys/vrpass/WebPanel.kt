package kz.akarys.vrpass

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Presentation
import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.InputDevice
import android.view.MotionEvent
import android.view.Surface
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * YouTube / TikTok сайттарын VR ішінде көрсету.
 * WebView жеке виртуалды дисплейде (VirtualDisplay) салынады, ал оның суреті
 * OpenGL текстурасына түседі — сол арқылы екі көзге шығарамыз.
 * Саусақпен шымшу = экранды басу, шымшып тартып жүргізу = айналдыру (scroll/свайп).
 */
class WebPanel(private val activity: Activity, private val state: VrState) {

    private val main = Handler(Looper.getMainLooper())
    private var display: VirtualDisplay? = null
    private var presentation: Presentation? = null
    private var webView: WebView? = null
    private var surface: Surface? = null
    private var downTime = 0L

    /** GL ағыны жаңа текстура жасағанда шақырылады (негізгі ағында). */
    fun setSurfaceTexture(st: SurfaceTexture?) {
        val old = surface
        surface = null
        if (st != null) {
            st.setDefaultBufferSize(W, H)
            surface = Surface(st)
        }
        try {
            display?.surface = surface
        } catch (e: Exception) {
            Log.w(TAG, "setSurface", e)
        }
        old?.release()
    }

    /** Сайтты ашу. Сәтсіз болса — false. */
    fun open(url: String): Boolean {
        if (!ensure()) return false
        webView?.loadUrl(url)
        webView?.onResume()
        return true
    }

    fun back() {
        val wv = webView ?: return
        if (wv.canGoBack()) wv.goBack()
    }

    fun reload() {
        webView?.reload()
    }

    fun close() {
        webView?.let {
            it.loadUrl("about:blank")
            it.onPause()
        }
    }

    /** Саусақ оқиғасы: nx, ny — панель ішіндегі орны (0..1). */
    fun touch(action: Int, nx: Float, ny: Float) {
        main.post {
            val wv = webView ?: return@post
            val now = SystemClock.uptimeMillis()
            if (action == MotionEvent.ACTION_DOWN) downTime = now
            val ev = MotionEvent.obtain(downTime, now, action, nx * W, ny * H, 0)
            ev.source = InputDevice.SOURCE_TOUCHSCREEN
            try {
                wv.dispatchTouchEvent(ev)
            } catch (e: Exception) {
                Log.w(TAG, "touch", e)
            }
            ev.recycle()
        }
    }

    fun onResume() {
        if (state.webOn) webView?.onResume()
    }

    fun onPause() {
        webView?.onPause()
    }

    fun destroy() {
        try {
            presentation?.dismiss()
        } catch (e: Exception) {
            Log.w(TAG, "dismiss", e)
        }
        webView?.destroy()
        display?.release()
        surface?.release()
        presentation = null
        webView = null
        display = null
        surface = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun ensure(): Boolean {
        if (webView != null) return true
        return try {
            val dm = activity.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val vd = dm.createVirtualDisplay(
                "vr-web", W, H, DPI, surface,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
            )
            display = vd
            val p = Presentation(activity, vd.display)
            val wv = WebView(p.context)
            val s = wv.settings
            s.javaScriptEnabled = true
            s.domStorageEnabled = true
            s.mediaPlaybackRequiresUserGesture = false
            s.loadWithOverviewMode = true
            s.useWideViewPort = true
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
            wv.webChromeClient = WebChromeClient()
            wv.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    // «Қосымшада ашу» сілтемелерін (intent://, snssdk:// …) бұғаттаймыз — VR ішінде қаламыз
                    val scheme = request.url.scheme ?: return true
                    return !(scheme == "http" || scheme == "https")
                }
            }
            p.setContentView(wv)
            p.show()
            presentation = p
            webView = wv
            true
        } catch (t: Throwable) {
            Log.e(TAG, "ensure", t)
            false
        }
    }

    companion object {
        private const val TAG = "WebPanel"
        const val W = 540
        const val H = 960
        private const val DPI = 240
    }
}
