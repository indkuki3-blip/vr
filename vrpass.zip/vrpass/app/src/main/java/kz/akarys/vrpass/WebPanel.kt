package kz.akarys.vrpass

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Presentation
import android.content.Context
import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.InputDevice
import android.view.MotionEvent
import android.view.Surface
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.net.URLEncoder

/** Жүйенің пернетақтасын шақырмайтын WebView (ол VR экранын жауып қалады). Мәтінді өзіміз енгіземіз. */
class VrWebView(ctx: Context) : WebView(ctx) {
    override fun onCheckIsTextEditor(): Boolean = false
    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? = null
}

/**
 * Браузер / YouTube / TikTok — VR ішінде.
 * WebView жеке виртуалды дисплейде (VirtualDisplay) салынады, суреті OpenGL текстурасына түседі.
 * Тік (9:16) және көлденең (16:9) режимдер. Айналдыру — саусақпен свайпты қайталау.
 */
class WebPanel(private val activity: Activity, private val state: VrState) {

    private val main = Handler(Looper.getMainLooper())
    private var display: VirtualDisplay? = null
    private var presentation: Presentation? = null
    private var webView: VrWebView? = null
    private var surface: Surface? = null
    private var texture: SurfaceTexture? = null
    private var downTime = 0L
    private var swiping = false

    val width: Int get() = if (state.webLandscape) LONG else SHORT
    val height: Int get() = if (state.webLandscape) SHORT else LONG

    /** GL ағыны жаңа текстура жасағанда шақырылады (негізгі ағында). */
    fun setSurfaceTexture(st: SurfaceTexture?) {
        val old = surface
        surface = null
        texture = st
        if (st != null) {
            st.setDefaultBufferSize(width, height)
            surface = Surface(st)
        }
        try {
            display?.surface = surface
        } catch (e: Exception) {
            Log.w(TAG, "setSurface", e)
        }
        old?.release()
    }

    /** Тік ↔ көлденең. */
    fun setLandscape(on: Boolean) {
        state.webLandscape = on
        texture?.setDefaultBufferSize(width, height)
        try {
            display?.resize(width, height, DPI)
        } catch (e: Exception) {
            Log.w(TAG, "resize", e)
        }
    }

    /** Сайтты ашу. Сәтсіз болса — false. */
    fun open(url: String): Boolean {
        if (!ensure()) return false
        webView?.onResume()
        webView?.loadUrl(url)
        return true
    }

    /** Мекенжай жолынан: сайт адресі болса — ашады, болмаса — Google-да іздейді. */
    fun navigate(text: String) {
        val s = text.trim()
        if (s.isEmpty()) return
        val url = when {
            s.startsWith("http://") || s.startsWith("https://") -> s
            !s.contains(' ') && s.contains('.') -> "https://$s"
            else -> "https://www.google.com/search?q=" + URLEncoder.encode(s, "UTF-8")
        }
        open(url)
    }

    fun back() {
        val wv = webView ?: return
        if (wv.canGoBack()) wv.goBack()
    }

    fun reload() {
        webView?.reload()
    }

    fun close() {
        webView?.let {
            it.loadUrl("about:blank")
            it.onPause()
        }
        state.webUrl = ""
    }

    /** Саусақ оқиғасы: nx, ny — панель ішіндегі орны (0..1). */
    fun touch(action: Int, nx: Float, ny: Float) {
        main.post { dispatch(action, nx, ny) }
        if (action == MotionEvent.ACTION_UP) {
            // Мәтін өрісі басылды ма? Басылса — VR пернетақтасын ашамыз
            main.postDelayed({ checkFocus() }, 350L)
        }
    }

    private fun dispatch(action: Int, nx: Float, ny: Float) {
        val wv = webView ?: return
        val now = SystemClock.uptimeMillis()
        if (action == MotionEvent.ACTION_DOWN) downTime = now
        val ev = MotionEvent.obtain(downTime, now, action, nx * width, ny * height, 0)
        ev.source = InputDevice.SOURCE_TOUCHSCREEN
        try {
            wv.dispatchTouchEvent(ev)
        } catch (e: Exception) {
            Log.w(TAG, "touch", e)
        }
        ev.recycle()
    }

    /** Айналдыру: dir = +1 төмен (келесі), −1 жоғары. Саусақ свайпын қайталайды (TikTok-та да істейді). */
    fun scroll(dir: Int) {
        if (swiping) return
        swiping = true
        val from = if (dir > 0) 0.72f else 0.28f
        val to = if (dir > 0) 0.28f else 0.72f
        val steps = 8
        main.post { dispatch(MotionEvent.ACTION_DOWN, 0.5f, from) }
        for (i in 1..steps) {
            val y = from + (to - from) * i / steps
            main.postDelayed({ dispatch(MotionEvent.ACTION_MOVE, 0.5f, y) }, i * 18L)
        }
        main.postDelayed({
            dispatch(MotionEvent.ACTION_UP, 0.5f, to)
            swiping = false
        }, (steps + 1) * 18L)
    }

    /** Беттегі белсенді өріске мәтін қосу (Enter басу керек болса — submit = true). */
    fun insertText(text: String, submit: Boolean) {
        val wv = webView ?: return
        val js = """
            (function(t, go){
              var e = document.activeElement;
              if (!e) return 'none';
              if (t.length > 0) {
                var ok = false;
                try { ok = document.execCommand('insertText', false, t); } catch (x) {}
                if (!ok) {
                  var d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(e), 'value');
                  var v = (e.value || '') + t;
                  if (d && d.set) d.set.call(e, v); else e.value = v;
                  e.dispatchEvent(new Event('input', {bubbles: true}));
                }
              }
              if (go) {
                ['keydown','keypress','keyup'].forEach(function(k){
                  e.dispatchEvent(new KeyboardEvent(k, {key:'Enter', code:'Enter', keyCode:13, which:13, bubbles:true}));
                });
                if (e.form) { try { e.form.requestSubmit ? e.form.requestSubmit() : e.form.submit(); } catch (x) {} }
              }
              return 'ok';
            })(${JSONObject.quote(text)}, $submit)
        """.trimIndent()
        main.post { wv.evaluateJavascript(js, null) }
    }

    /** Беттегі белсенді өрістен соңғы әріпті өшіру. */
    fun deleteChar() {
        val wv = webView ?: return
        main.post { wv.evaluateJavascript("document.execCommand('delete', false)", null) }
    }

    private fun checkFocus() {
        val wv = webView ?: return
        wv.evaluateJavascript(
            "(function(){var e=document.activeElement;return !!e&&(e.tagName=='INPUT'||e.tagName=='TEXTAREA'||e.isContentEditable);})()"
        ) { r -> if (r == "true") state.webInputFocused = true }
    }

    fun onResume() {
        if (state.webOn) webView?.onResume()
    }

    fun onPause() {
        webView?.onPause()
    }

    fun destroy() {
        try {
            presentation?.dismiss()
        } catch (e: Exception) {
            Log.w(TAG, "dismiss", e)
        }
        webView?.destroy()
        display?.release()
        surface?.release()
        presentation = null
        webView = null
        display = null
        surface = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun ensure(): Boolean {
        if (webView != null) return true
        return try {
            val dm = activity.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val vd = dm.createVirtualDisplay(
                "vr-web", width, height, DPI, surface,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
            )
            display = vd
            val p = Presentation(activity, vd.display)
            val wv = VrWebView(p.context)
            val s = wv.settings
            s.javaScriptEnabled = true
            s.domStorageEnabled = true
            s.mediaPlaybackRequiresUserGesture = false
            s.loadWithOverviewMode = true
            s.useWideViewPort = true
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
            wv.webChromeClient = WebChromeClient()
            wv.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    // «Қосымшада ашу» сілтемелерін (intent://, snssdk:// …) бұғаттаймыз — VR ішінде қаламыз
                    val scheme = request.url.scheme ?: return true
                    return !(scheme == "http" || scheme == "https")
                }

                override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                    state.webUrl = url ?: ""
                }

                override fun onPageFinished(view: WebView, url: String?) {
                    state.webUrl = url ?: ""
                }
            }
            p.setContentView(wv)
            p.show()
            presentation = p
            webView = wv
            true
        } catch (t: Throwable) {
            Log.e(TAG, "ensure", t)
            false
        }
    }

    companion object {
        private const val TAG = "WebPanel"
        const val SHORT = 540
        const val LONG = 960
        private const val DPI = 240
    }
}
