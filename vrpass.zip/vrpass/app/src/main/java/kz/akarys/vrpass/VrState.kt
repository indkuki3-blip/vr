package kz.akarys.vrpass

import android.content.Context
import android.content.SharedPreferences

/** Бір қолдың камера кадрындағы 21 нүктесі (0..1, сол-жоғарыдан) және есептелген белгілері. */
class RawHand(
    val xs: FloatArray,
    val ys: FloatArray,
    val zs: FloatArray,
    /** Тегістелген сұқ саусақ ұшы (курсор). */
    val tipX: Float,
    val tipY: Float,
    val pinch: Boolean,
    /** Тұрақты нөмір (0 немесе 1): қол кадрдан кадрға ауыспасын. */
    val slot: Int,
    val fist: Boolean,
    /** Алақан қарап тұрған бағыт (бірлік вектор, кадр координатасында, x ені бойынша изотропты). */
    val normX: Float,
    val normY: Float,
    val normZ: Float,
    /** Кадрдың ені / биіктігі. */
    val imgAspect: Float
)

class HandsFrame(val hands: List<RawHand>, val time: Long) {
    companion object {
        val EMPTY = HandsFrame(emptyList(), 0L)
    }
}

/** Көз экранындағы (HUD) қол: координаталар 0..1, сол-жоғарыдан. Басымен бірге қозғалады. */
class EyeHand(
    val slot: Int,
    /** 21 нүкте: x0, y0, x1, y1, … */
    val pts: FloatArray,
    val cx: Float,
    val cy: Float,
    val pinch: Boolean,
    /** Осы кадрда шымшу басталды. */
    val pinchDown: Boolean,
    /** Осы кадрда шымшу аяқталды. */
    val pinchUp: Boolean,
    val fist: Boolean = false,
    /** Алақан ортасы. */
    val palmX: Float = cx,
    val palmY: Float = cy,
    /** Қол өлшемі (білек → ортаңғы саусақ түбі), биіктік үлесімен. */
    val size: Float = 0.1f,
    /** Қолдың бұрышы (білектен саусаққа), радиан, изотропты экран координатасында. */
    val angle: Float = 0f,
    /** Алақан нормалінің экрандағы проекциясы (изотропты, ұзындығы ≤ 1) және тереңдік бөлігі. */
    val nx: Float = 0f,
    val ny: Float = 0f,
    val nz: Float = 1f
) {
    fun x(i: Int) = pts[i * 2]
    fun y(i: Int) = pts[i * 2 + 1]
}

/**
 * Барлық бөлімдерге ортақ күй: баптаулар (сақталады) және ағымдағы мәндер
 * (камера, қол, бас, веб, дауыс, жазу). Әр түрлі ағындардан оқылады, сондықтан @Volatile.
 */
class VrState(ctx: Context) {

    private val prefs: SharedPreferences = ctx.getSharedPreferences("vr", Context.MODE_PRIVATE)

    val effectNames = arrayOf(
        "Қалыпты", "Ақ-қара", "Түнгі көру", "Термо", "Неон контур", "Комикс",
        "Матрица", "Пиксель", "VHS", "Калейдоскоп", "Рентген", "Эскиз",
        "Кемпірқосақ", "Сепия", "Айна", "Балық көзі", "Ыстық толқын", "Жұлдызды түн"
    )

    // ---------------------------------------------------------- баптаулар
    @Volatile
    var effect: Int = prefs.getInt("effect", 0).coerceIn(0, effectNames.size - 1)
        set(v) {
            field = v
            prefs.edit().putInt("effect", v).apply()
        }

    /** Линза бұрмалауының күші (0 = жоқ). */
    @Volatile
    var distortion: Float = prefs.getFloat("dist", 0.20f)
        set(v) {
            field = v
            prefs.edit().putFloat("dist", v).apply()
        }

    /** Көз аралығы, мм (линза центрлері арасы). */
    @Volatile
    var ipdMm: Float = prefs.getFloat("ipd", 62f)
        set(v) {
            field = v
            prefs.edit().putFloat("ipd", v).apply()
        }

    /** Масштаб: < 1 — сурет кішірейеді (шынайырақ көлем), > 1 — үлкейеді. */
    @Volatile
    var zoom: Float = prefs.getFloat("zoom", 0.90f)
        set(v) {
            field = v
            prefs.edit().putFloat("zoom", v).apply()
        }

    /** Пайдаланушы қосатын қосымша бұру (0..3, әрқайсысы 90°). */
    @Volatile
    var rotUser: Int = prefs.getInt("rotUser", 0).coerceIn(0, 3)
        set(v) {
            field = v
            prefs.edit().putInt("rotUser", v).apply()
        }

    /** true — көзқарас (бас) + шымшу; false — саусақ курсоры (күшейткішпен). */
    @Volatile
    var controlGaze: Boolean = prefs.getBoolean("gaze", true)
        set(v) {
            field = v
            prefs.edit().putBoolean("gaze", v).apply()
        }

    /** Гироскоп: мәзір кеңістікте бекітіліп тұрады. */
    @Volatile
    var gyroOn: Boolean = prefs.getBoolean("gyro", true)
        set(v) {
            field = v
            prefs.edit().putBoolean("gyro", v).apply()
        }

    /** Дауыспен жазу тілі: kk-KZ, ru-RU, en-US. */
    @Volatile
    var voiceLang: String = prefs.getString("vlang", "kk-KZ") ?: "kk-KZ"
        set(v) {
            field = v
            prefs.edit().putString("vlang", v).apply()
        }

    /** Ноутпен есептеу (қол трекингі Wi-Fi арқылы ноутта). */
    @Volatile
    var remoteOn: Boolean = prefs.getBoolean("remote", false)
        set(v) {
            field = v
            prefs.edit().putBoolean("remote", v).apply()
        }

    /** Ноуттың IP адресі (бос — автоматты іздеу). */
    @Volatile
    var remoteIp: String = prefs.getString("remoteIp", "") ?: ""
        set(v) {
            field = v
            prefs.edit().putString("remoteIp", v).apply()
        }

    /** Сапа: 0 — Авто, 1 — Жоғары, 2 — Орта, 3 — Төмен. */
    @Volatile
    var quality: Int = prefs.getInt("quality", 0).coerceIn(0, 3)
        set(v) {
            field = v
            prefs.edit().putInt("quality", v).apply()
        }

    @Volatile
    var showFps: Boolean = prefs.getBoolean("showFps", false)
        set(v) {
            field = v
            prefs.edit().putBoolean("showFps", v).apply()
        }

    fun best(gameId: String): Int = prefs.getInt("best_$gameId", 0)

    fun setBest(gameId: String, v: Int) {
        prefs.edit().putInt("best_$gameId", v).apply()
    }

    /** Камера сенсорының бағыты (CameraCharacteristics.SENSOR_ORIENTATION). */
    @Volatile var sensorOrientation = 90

    /** Экранның бұрылысы, градус (көлденең режимде әдетте 90). */
    @Volatile var displayRotation = 90

    /**
     * Сенсор кадрын экранға шығарғанда қанша рет 90°-қа бұру керек (0..3).
     * Автоматты есеп + пайдаланушы баптауы. Шейдер мен курсор бірдей мәнді қолданады.
     */
    fun camQuarterTurns(): Int {
        val q = (((sensorOrientation - displayRotation) / 90) % 4 + 4) % 4
        val auto = (4 - q) % 4
        return (auto + rotUser) % 4
    }

    /** Экранның физикалық тығыздығы (пиксель/дюйм), көз аралығын есептеуге. */
    val xdpi: Float = ctx.resources.displayMetrics.xdpi.let { if (it < 100f || it > 1000f) 400f else it }

    /** Экранның нақты (физикалық) ені, пиксель (көлденең). */
    @Volatile var screenW = 0

    // ---------------------------------------------------------- камера / рендер
    @Volatile var camW = 1280
    @Volatile var camH = 720
    /** Камера көру бұрышының жартысының тангенсі (сенсордың ұзын/қысқа жағы бойынша). */
    @Volatile var camTanW = 0.62f
    @Volatile var camTanH = 0.35f
    @Volatile var cropU = 1f
    @Volatile var cropV = 1f
    @Volatile var cameraStatus = ""

    // ---------------------------------------------------------- жылдамдық
    @Volatile var fps = 0f
    @Volatile var frameMs = 0f
    /** Нақты қолданылып тұрған деңгей: 0 жоғары, 1 орта, 2 төмен. */
    @Volatile var qualityLevel = 1
    /** Телефондағы қол трекингінің шегі (кадр/с). */
    @Volatile var trackFps = 15
    @Volatile var remoteStatus = ""
    @Volatile var hot = false

    // ---------------------------------------------------------- бас (гироскоп)
    /** Бастың бұрылысы, радиан: оңға бұрылу оң, жоғары қарау оң. */
    @Volatile var headYaw = 0f
    @Volatile var headPitch = 0f
    @Volatile var headValid = false

    // ---------------------------------------------------------- веб-панель
    @Volatile var webOn = false
    @Volatile var panelL = 0.3f
    @Volatile var panelT = 0.1f
    @Volatile var panelR = 0.7f
    @Volatile var panelB = 0.9f
    @Volatile var webLandscape = false
    @Volatile var webUrl = ""
    /** Беттегі мәтін өрісі басылды — пернетақтаны ашу керек. */
    @Volatile var webInputFocused = false

    // ---------------------------------------------------------- дауыс
    @Volatile var voiceListening = false
    @Volatile var voicePartial = ""
    @Volatile var voiceFinal: String? = null
    @Volatile var voiceError = ""
    @Volatile var voiceLevel = 0f

    // ---------------------------------------------------------- жазу
    @Volatile var recording = false
    @Volatile var recordStart = 0L
    @Volatile var notice = ""

    // ---------------------------------------------------------- қол трекингі
    @Volatile var hands: HandsFrame = HandsFrame.EMPTY
    @Volatile var trackerReady = false
    @Volatile var trackerStatus = "Қол трекингі жүктелуде…"

    @Volatile var battery = -1

    /**
     * Камера кадрындағы нүктені (0..1, сол-жоғарыдан) көз экранының (HUD) координатасына айналдыру.
     * Шейдердегі формуланың кері түрі. Нәтиже out[off], out[off + 1].
     */
    fun toEye(ix: Float, iy: Float, turnsInv: Int, out: FloatArray, off: Int) {
        val sx = ix - 0.5f
        val sy = 0.5f - iy
        val dx: Float
        val dy: Float
        when (turnsInv) {
            1 -> { dx = sy; dy = -sx }
            2 -> { dx = -sx; dy = -sy }
            3 -> { dx = -sy; dy = sx }
            else -> { dx = sx; dy = sy }
        }
        out[off] = 0.5f + dx * zoom / cropU
        out[off + 1] = 0.5f - dy * zoom / cropV
    }

    /** Шейдер: S = R_k(D), сондықтан кері бұру: D = R_(4-k)(S). */
    fun inverseTurns(): Int = (4 - camQuarterTurns()) % 4
}
