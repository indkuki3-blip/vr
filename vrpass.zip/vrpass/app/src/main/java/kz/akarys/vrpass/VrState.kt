package kz.akarys.vrpass

import android.content.Context
import android.content.SharedPreferences

/**
 * Барлық бөлімдерге ортақ күй: баптаулар (сақталады) және ағымдағы мәндер
 * (камера, қол трекингі, рендер). Әр түрлі ағындардан оқылады, сондықтан @Volatile.
 */
class VrState(ctx: Context) {

    private val prefs: SharedPreferences = ctx.getSharedPreferences("vr", Context.MODE_PRIVATE)

    val effectNames = arrayOf("Қалыпты", "Ақ-қара", "Түнгі көру", "Термо", "Неон контур", "Комикс")

    // ---------------------------------------------------------- баптаулар
    @Volatile
    var effect: Int = prefs.getInt("effect", 0).coerceIn(0, effectNames.size - 1)
        set(v) {
            field = v
            prefs.edit().putInt("effect", v).apply()
        }

    /** Линза бұрмалауының күші (0 = жоқ). */
    @Volatile
    var distortion: Float = prefs.getFloat("dist", 0.20f)
        set(v) {
            field = v
            prefs.edit().putFloat("dist", v).apply()
        }

    /** Көз аралығы, мм (линза центрлері арасы). */
    @Volatile
    var ipdMm: Float = prefs.getFloat("ipd", 62f)
        set(v) {
            field = v
            prefs.edit().putFloat("ipd", v).apply()
        }

    /** Масштаб: < 1 — сурет кішірейеді (шынайырақ көлем), > 1 — үлкейеді. */
    @Volatile
    var zoom: Float = prefs.getFloat("zoom", 0.90f)
        set(v) {
            field = v
            prefs.edit().putFloat("zoom", v).apply()
        }

    /** Пайдаланушы қосатын қосымша бұру (0..3, әрқайсысы 90°). */
    @Volatile
    var rotUser: Int = prefs.getInt("rotUser", 0).coerceIn(0, 3)
        set(v) {
            field = v
            prefs.edit().putInt("rotUser", v).apply()
        }

    /** Камера сенсорының бағыты (CameraCharacteristics.SENSOR_ORIENTATION). */
    @Volatile var sensorOrientation = 90

    /** Экранның бұрылысы, градус (көлденең режимде әдетте 90). */
    @Volatile var displayRotation = 90

    /**
     * Сенсор кадрын экранға шығарғанда қанша рет 90°-қа бұру керек (0..3).
     * Автоматты есеп + пайдаланушы баптауы. Шейдер мен курсор бірдей мәнді қолданады.
     */
    fun camQuarterTurns(): Int {
        val q = (((sensorOrientation - displayRotation) / 90) % 4 + 4) % 4
        val auto = (4 - q) % 4
        return (auto + rotUser) % 4
    }

    @Volatile
    var best: Int = prefs.getInt("best", 0)
        set(v) {
            field = v
            prefs.edit().putInt("best", v).apply()
        }

    /** Экранның физикалық тығыздығы (пиксель/дюйм), көз аралығын есептеуге. */
    val xdpi: Float = ctx.resources.displayMetrics.xdpi.let { if (it < 100f || it > 1000f) 400f else it }

    // ---------------------------------------------------------- камера / рендер
    @Volatile var camW = 1280
    @Volatile var camH = 720
    @Volatile var cropU = 1f
    @Volatile var cropV = 1f
    @Volatile var cameraStatus = ""

    // ---------------------------------------------------------- қол трекингі
    /** Сұқ саусақ ұшы, камера кадрындағы координата (0..1, сол-жоғарыдан). */
    @Volatile var handX = 0.5f
    @Volatile var handY = 0.5f
    @Volatile var pinch = false
    @Volatile var handTime = 0L
    @Volatile var trackerReady = false
    @Volatile var trackerStatus = "Қол трекингі жүктелуде…"

    @Volatile var battery = -1

    /**
     * Саусақтың камерадағы орнын көз экранының (HUD) координатасына айналдыру.
     * Шейдердегі формуланың кері түрі: img = 0.5 + (eye - 0.5) * crop / zoom.
     */
    fun eyePoint(): FloatArray {
        // Сенсор координатасы, ортасы 0, y жоғары қарай (шейдердегідей)
        val sx = handX - 0.5f
        val sy = 0.5f - handY
        // Шейдер: S = R_k(D). Мұнда кері түрі: D = R_(4-k)(S)
        val k = (4 - camQuarterTurns()) % 4
        val dx: Float
        val dy: Float
        when (k) {
            1 -> { dx = sy; dy = -sx }
            2 -> { dx = -sx; dy = -sy }
            3 -> { dx = -sy; dy = sx }
            else -> { dx = sx; dy = sy }
        }
        val eyeX = 0.5f + dx * zoom / cropU
        val eyeYUp = 0.5f + dy * zoom / cropV
        return floatArrayOf(eyeX, 1f - eyeYUp)
    }
}
