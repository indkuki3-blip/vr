package kz.akarys.vrpass

import android.content.Context
import android.content.SharedPreferences

/** Бір қолдың камера кадрындағы 21 нүктесі (0..1, сол-жоғарыдан). */
class RawHand(
    val xs: FloatArray,
    val ys: FloatArray,
    /** Тегістелген сұқ саусақ ұшы (курсор). */
    val tipX: Float,
    val tipY: Float,
    val pinch: Boolean,
    /** Тұрақты нөмір (0 немесе 1): қол кадрдан кадрға ауыспасын. */
    val slot: Int
)

class HandsFrame(val hands: List<RawHand>, val time: Long) {
    companion object {
        val EMPTY = HandsFrame(emptyList(), 0L)
    }
}

/** Көз экранындағы (HUD) қол: координаталар 0..1, сол-жоғарыдан. */
class EyeHand(
    val slot: Int,
    /** 21 нүкте: x0, y0, x1, y1, … */
    val pts: FloatArray,
    val cx: Float,
    val cy: Float,
    val pinch: Boolean,
    /** Осы кадрда шымшу басталды. */
    val pinchDown: Boolean,
    /** Осы кадрда шымшу аяқталды. */
    val pinchUp: Boolean
) {
    fun x(i: Int) = pts[i * 2]
    fun y(i: Int) = pts[i * 2 + 1]
}

/**
 * Барлық бөлімдерге ортақ күй: баптаулар (сақталады) және ағымдағы мәндер
 * (камера, қол трекингі, рендер). Әр түрлі ағындардан оқылады, сондықтан @Volatile.
 */
class VrState(ctx: Context) {

    private val prefs: SharedPreferences = ctx.getSharedPreferences("vr", Context.MODE_PRIVATE)

    val effectNames = arrayOf("Қалыпты", "Ақ-қара", "Түнгі көру", "Термо", "Неон контур", "Комикс")

    // ---------------------------------------------------------- баптаулар
    @Volatile
    var effect: Int = prefs.getInt("effect", 0).coerceIn(0, effectNames.size - 1)
        set(v) {
            field = v
            prefs.edit().putInt("effect", v).apply()
        }

    /** Линза бұрмалауының күші (0 = жоқ). */
    @Volatile
    var distortion: Float = prefs.getFloat("dist", 0.20f)
        set(v) {
            field = v
            prefs.edit().putFloat("dist", v).apply()
        }

    /** Көз аралығы, мм (линза центрлері арасы). */
    @Volatile
    var ipdMm: Float = prefs.getFloat("ipd", 62f)
        set(v) {
            field = v
            prefs.edit().putFloat("ipd", v).apply()
        }

    /** Масштаб: < 1 — сурет кішірейеді (шынайырақ көлем), > 1 — үлкейеді. */
    @Volatile
    var zoom: Float = prefs.getFloat("zoom", 0.90f)
        set(v) {
            field = v
            prefs.edit().putFloat("zoom", v).apply()
        }

    /** Пайдаланушы қосатын қосымша бұру (0..3, әрқайсысы 90°). */
    @Volatile
    var rotUser: Int = prefs.getInt("rotUser", 0).coerceIn(0, 3)
        set(v) {
            field = v
            prefs.edit().putInt("rotUser", v).apply()
        }

    fun best(gameId: String): Int = prefs.getInt("best_$gameId", 0)

    fun setBest(gameId: String, v: Int) {
        prefs.edit().putInt("best_$gameId", v).apply()
    }

    /** Камера сенсорының бағыты (CameraCharacteristics.SENSOR_ORIENTATION). */
    @Volatile var sensorOrientation = 90

    /** Экранның бұрылысы, градус (көлденең режимде әдетте 90). */
    @Volatile var displayRotation = 90

    /**
     * Сенсор кадрын экранға шығарғанда қанша рет 90°-қа бұру керек (0..3).
     * Автоматты есеп + пайдаланушы баптауы. Шейдер мен курсор бірдей мәнді қолданады.
     */
    fun camQuarterTurns(): Int {
        val q = (((sensorOrientation - displayRotation) / 90) % 4 + 4) % 4
        val auto = (4 - q) % 4
        return (auto + rotUser) % 4
    }

    /** Экранның физикалық тығыздығы (пиксель/дюйм), көз аралығын есептеуге. */
    val xdpi: Float = ctx.resources.displayMetrics.xdpi.let { if (it < 100f || it > 1000f) 400f else it }

    /** Экранның нақты (физикалық) ені, пиксель (көлденең). */
    @Volatile var screenW = 0

    // ---------------------------------------------------------- камера / рендер
    @Volatile var camW = 1280
    @Volatile var camH = 720
    @Volatile var cropU = 1f
    @Volatile var cropV = 1f
    @Volatile var cameraStatus = ""

    // ---------------------------------------------------------- веб-панель (YouTube, TikTok)
    @Volatile var webOn = false
    @Volatile var panelL = 0.3f
    @Volatile var panelT = 0.1f
    @Volatile var panelR = 0.7f
    @Volatile var panelB = 0.9f

    // ---------------------------------------------------------- қол трекингі
    @Volatile var hands: HandsFrame = HandsFrame.EMPTY
    @Volatile var trackerReady = false
    @Volatile var trackerStatus = "Қол трекингі жүктелуде…"

    @Volatile var battery = -1

    /**
     * Камера кадрындағы нүктені (0..1, сол-жоғарыдан) көз экранының (HUD) координатасына айналдыру.
     * Шейдердегі формуланың кері түрі. Нәтиже out[off], out[off + 1].
     */
    fun toEye(ix: Float, iy: Float, turnsInv: Int, out: FloatArray, off: Int) {
        val sx = ix - 0.5f
        val sy = 0.5f - iy
        val dx: Float
        val dy: Float
        when (turnsInv) {
            1 -> { dx = sy; dy = -sx }
            2 -> { dx = -sx; dy = -sy }
            3 -> { dx = -sy; dy = sx }
            else -> { dx = sx; dy = sy }
        }
        out[off] = 0.5f + dx * zoom / cropU
        out[off + 1] = 0.5f - dy * zoom / cropV
    }

    /** Шейдер: S = R_k(D), сондықтан кері бұру: D = R_(4-k)(S). */
    fun inverseTurns(): Int = (4 - camQuarterTurns()) % 4
}
