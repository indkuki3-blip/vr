plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "kz.akarys.vrpass"
    compileSdk = 34

    defaultConfig {
        applicationId = "kz.akarys.vrpass"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "3.0"
        ndk {
            abiFilters.addAll(listOf("arm64-v8a", "armeabi-v7a"))
        }
    }

    // Тұрақты кілт: жаңа нұсқа ескісінің үстінен орнатыла береді
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    androidResources {
        noCompress.add("task")
    }
}

dependencies {
    // Қол трекингі (Google MediaPipe)
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
}

// Қол трекингінің моделін жинау кезінде автоматты түрде жүктеу
val handModel = file("src/main/assets/hand_landmarker.task")
val downloadHandModel by tasks.registering {
    outputs.file(handModel)
    doLast {
        if (!handModel.exists() || handModel.length() < 100_000L) {
            handModel.parentFile.mkdirs()
            val url = uri(
                "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task"
            ).toURL()
            val input = url.openStream()
            input.use { inp ->
                handModel.outputStream().use { out -> inp.copyTo(out) }
            }
        }
    }
}
tasks.named("preBuild") { dependsOn(downloadHandModel) }
